"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDisplayItems = exports.Product = exports.Price = exports.StoreInventory = exports.Shipping = exports.Inventory = exports.Size = exports.Color = exports.Flags = exports.Designer = exports.Taxonomy = exports.DigitalAsset = void 0;
const dynamodb_data_mapper_annotations_1 = require("@aws/dynamodb-data-mapper-annotations");
const dynamodb_data_mapper_1 = require("@aws/dynamodb-data-mapper");
const aws_sdk_1 = require("aws-sdk");
const config_1 = require("../utils/config");
const mapper = new dynamodb_data_mapper_1.DataMapper({ client: new aws_sdk_1.DynamoDB() });
const productsTableName = config_1.property('PRODUCTS_TABLE');
class DigitalAsset {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "mediaTag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "mediaVersion", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "url", void 0);
exports.DigitalAsset = DigitalAsset;
class Taxonomy {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Taxonomy.prototype, "code", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Taxonomy.prototype, "name", void 0);
exports.Taxonomy = Taxonomy;
class Designer {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "descriptionTitle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "description", void 0);
exports.Designer = Designer;
class Flags {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isGroup", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "belongsToGroup", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "preOrder", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "allowBackOrders", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "blockOrders", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "dynamicImageSkuColor", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isEditorial", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isEvening", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "showMonogramLabel", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "previewSupported", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "storeOnly", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "exclusive", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "inStock", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "useSkuAsset", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "giftWrappableFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "perishableFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "dropshipFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "fedexEligibleFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "parenthetical", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Flags.prototype, "isOnlyAtNM", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Flags.prototype, "hasMoreColors", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "onSale", void 0);
exports.Flags = Flags;
class Color {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "key", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "pimKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "pimCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "facet", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Color.prototype, "default", void 0);
exports.Color = Color;
class Size {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "pimKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "pimCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "key", void 0);
exports.Size = Size;
class Inventory {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Inventory.prototype, "status", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "qty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "purchaseOrderQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "bossTotalQty", void 0);
exports.Inventory = Inventory;
class Shipping {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedDepthInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedHeightInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedWidthInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "deliveryDays", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Shipping.prototype, "shipFromStore", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Shipping.prototype, "expectedShipDate", void 0);
exports.Shipping = Shipping;
class StoreInventory {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "storeId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "storeNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "locationNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "quantity", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "bopsQuantity", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "invLevel", void 0);
exports.StoreInventory = StoreInventory;
class Price {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Price.prototype, "retail", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Price.prototype, "original", void 0);
exports.Price = Price;
let Product = class Product {
};
__decorate([
    dynamodb_data_mapper_annotations_1.hashKey({ type: 'String' }),
    __metadata("design:type", String)
], Product.prototype, "PartitionKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.rangeKey(),
    __metadata("design:type", String)
], Product.prototype, "SortKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "skuNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "skuSequenceNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayItem", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayItemType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "variationId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "productId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Price) }),
    __metadata("design:type", Price)
], Product.prototype, "price", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Color) }),
    __metadata("design:type", Color)
], Product.prototype, "color", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Size) }),
    __metadata("design:type", Size)
], Product.prototype, "size", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Inventory) }),
    __metadata("design:type", Inventory)
], Product.prototype, "inventory", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(DigitalAsset) }),
    __metadata("design:type", Array)
], Product.prototype, "digitalAssets", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "hexValue", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "merchandiseType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "swatchPath", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Shipping) }),
    __metadata("design:type", Object)
], Product.prototype, "shipping", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "suggestedInterval", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayName", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "department", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "class", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "subclass", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Designer) }),
    __metadata("design:type", Object)
], Product.prototype, "designer", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "serviceLevelCodes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sellableDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "adornDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "launchDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "commodeCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "genderCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Flags) }),
    __metadata("design:type", Object)
], Product.prototype, "flags", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "shortDescription", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "longDescription", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "notes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosCatalogId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosItem", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "catalogType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "pimStyle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "parentheticalCharge", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "intlParentheticalAmount", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "displayable", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "canonicalUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "designerBoutiqueUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "hideInternationally", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "suppressCheckout", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sizeLabels", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "offline", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "liveTreeDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "restrictedStates", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosSkuId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "codeUpc", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "discontinuedCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "vendorId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "iceFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(StoreInventory) }),
    __metadata("design:type", Array)
], Product.prototype, "storeInventories", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "onHandQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "onOrderQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "displayGroups", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "webProductIDs", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Object)
], Product.prototype, "attributes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Object)
], Product.prototype, "psAttributes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "componentsOf", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "displayAsGroupEligible", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sizeGuide", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "webSkuId", void 0);
Product = __decorate([
    dynamodb_data_mapper_annotations_1.table(productsTableName)
], Product);
exports.Product = Product;
exports.getDisplayItems = async (product) => {
    const products = [];
    const iterator = mapper.query(Product, { displayItem: `${product.displayItem}` }, { indexName: 'DisplayItemIndex' });
    for await (const record of iterator) {
        products.push(record);
    }
    return Promise.all(products);
};
//# sourceMappingURL=dynamoMessages.js.map