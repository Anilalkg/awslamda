import { IDesigner, IFlags, IProduct, IShipping, ITaxonomy } from '../models/product';
export declare class DigitalAsset {
    mediaTag: string;
    mediaVersion: string;
    url: string;
}
export declare class Taxonomy {
    code: string;
    name: string;
}
export declare class Designer {
    name: string;
    descriptionTitle: string;
    description: string;
}
export declare class Flags {
    isGroup: boolean;
    belongsToGroup: boolean;
    preOrder: boolean;
    allowBackOrders: boolean;
    blockOrders: boolean;
    dynamicImageSkuColor: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
    storeOnly: boolean;
    exclusive: boolean;
    inStock: boolean;
    useSkuAsset: boolean;
    giftWrappableFlag: boolean;
    perishableFlag: boolean;
    dropshipFlag: boolean;
    fedexEligibleFlag: boolean;
    parenthetical: boolean;
    isOnlyAtNM: string;
    hasMoreColors: string;
    onSale: boolean;
}
export declare class Color {
    key: string;
    name: string;
    pimKey: string;
    pimCode: string;
    facet: string;
    default: boolean;
}
export declare class Size {
    name: string;
    pimKey: string;
    pimCode: string;
    key: string;
}
export declare class Inventory {
    status: string;
    qty: number;
    purchaseOrderQty: number;
    bossTotalQty: number;
}
export declare class Shipping {
    boxedDepthInches: number;
    boxedHeightInches: number;
    boxedWidthInches: number;
    deliveryDays: number;
    shipFromStore?: string;
    expectedShipDate?: string;
}
export declare class StoreInventory {
    storeId: string;
    storeNumber: string;
    locationNumber: string;
    quantity: bigint;
    bopsQuantity: bigint;
    invLevel: bigint;
}
export declare class Price {
    retail: number;
    original: number;
}
export declare class Product {
    PartitionKey: string;
    SortKey: string;
    skuNumber: string;
    skuSequenceNumber: number;
    displayItem: string;
    displayItemType: string;
    variationId: string;
    productId: string;
    price: Price;
    color: Color;
    size: Size;
    inventory: Inventory;
    digitalAssets: DigitalAsset[];
    hexValue: string;
    merchandiseType: string;
    swatchPath: string;
    shipping: IShipping;
    suggestedInterval: string;
    displayName: string;
    department: ITaxonomy;
    class: ITaxonomy;
    subclass?: ITaxonomy;
    designer: IDesigner;
    serviceLevelCodes: string[];
    sellableDate: string;
    adornDate: string;
    launchDate: string;
    commodeCode: string;
    genderCode: string;
    flags: IFlags;
    shortDescription: string;
    longDescription: string;
    notes: string;
    cmosCatalogId: string;
    cmosItem: string;
    catalogType?: string;
    pimStyle: string;
    parentheticalCharge: string;
    intlParentheticalAmount: string;
    displayable?: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl?: string;
    hideInternationally: boolean;
    suppressCheckout?: string;
    sizeLabels?: string;
    offline?: string;
    liveTreeDate?: string;
    restrictedStates: string;
    cmosSkuId?: string;
    codeUpc: string;
    discontinuedCode?: string;
    vendorId: string;
    iceFlag?: string;
    storeInventories: StoreInventory[];
    onHandQty?: number;
    onOrderQty?: number;
    displayGroups?: string[];
    webProductIDs?: string[];
    attributes: any;
    psAttributes: any;
    componentsOf?: string[];
    displayAsGroupEligible?: boolean;
    sizeGuide?: string;
    webSkuId: string;
}
export declare const getDisplayItems: (product: IProduct) => Promise<Product[]>;
