"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapDataPointsStoreSkuListData = exports.mapSkuStores = exports.mapStoreInventoryUpdateData = exports.mapStoreInventoryUpdates = void 0;
const aws_sdk_1 = require("aws-sdk");
function mapStoreInventoryUpdates(event, config) {
    return event.Records.filter((record) => record.eventName === 'INSERT' || record.eventName === 'MODIFY').map((record) => mapStoreInventoryUpdateData(record, config));
}
exports.mapStoreInventoryUpdates = mapStoreInventoryUpdates;
function mapStoreInventoryUpdateData(record, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
    const approximateCreationDateTime = new Date(record.dynamodb.ApproximateCreationDateTime * 1000).toISOString().replace('Z', '');
    return {
        eventType: 'SKU_STORES_INVENTORY_UPDATED',
        batchId: config.batchId,
        id: productDoc.productId,
        skuStores: exports.mapSkuStores(productDoc.storeInventories, productDoc.webSkuId),
        originTimestampInfo: {
            SKU_STORES_INVENTORY_UPDATED: approximateCreationDateTime,
        },
        dataPoints: {
            StoreSkuListData: exports.mapDataPointsStoreSkuListData(productDoc.webSkuId),
            ProductId: productDoc.productId,
        },
    };
}
exports.mapStoreInventoryUpdateData = mapStoreInventoryUpdateData;
exports.mapSkuStores = (sourceStoreInvList, skuNumber) => {
    const locationList = [];
    if (sourceStoreInvList && sourceStoreInvList.length) {
        const location = {};
        location.skuId = skuNumber;
        const storeInventories = [];
        for (const sourceStoreInv of sourceStoreInvList) {
            const destStoreInv = {};
            destStoreInv.bopsQty = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.bopsQuantity;
            destStoreInv.locationNumber = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.locationNumber;
            destStoreInv.qty = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.quantity;
            destStoreInv.storeId = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.storeId;
            destStoreInv.storeNo = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.storeNumber;
            destStoreInv.invLevel = sourceStoreInv === null || sourceStoreInv === void 0 ? void 0 : sourceStoreInv.invLevel;
            storeInventories.push(destStoreInv);
        }
        location.storeInventories = storeInventories;
        locationList.push(location);
    }
    return locationList;
};
exports.mapDataPointsStoreSkuListData = (skuNumber) => {
    const storeSkuListData = [];
    const storeSkuData = {};
    storeSkuData.SkuId = skuNumber;
    storeSkuListData.push(storeSkuData);
    return storeSkuListData;
};
//# sourceMappingURL=mapStoreInventoryUpdates.js.map