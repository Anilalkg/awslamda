import { DynamoDBStreamEvent } from 'aws-lambda';
import { ISkuUpdated } from '../../models/skuUpdatedMessage';
import { ISkuInventoryUpdated } from '../../models/skuInventoryUpdatedMessage';
import { MessageMapperConfig } from '../../types';
export declare function mapSkuUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): ISkuUpdated[];
export declare function mapSkuInventoryUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): ISkuInventoryUpdated[];
