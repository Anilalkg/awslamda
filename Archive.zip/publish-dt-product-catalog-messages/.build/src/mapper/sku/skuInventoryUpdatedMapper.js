"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapSkuInventoryUpdateSkuList = exports.mapSkuInventoryUpdateData = void 0;
const aws_sdk_1 = require("aws-sdk");
const skuUpdatedMapper_1 = require("./skuUpdatedMapper");
function mapSkuInventoryUpdateData(streamRecord, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    return {
        eventType: 'SkuInventoryUpdated',
        batchId: config.batchId,
        id: productDoc.productId,
        exclusive: productDoc.flags.exclusive,
        skuList: mapSkuInventoryUpdateSkuList(productDoc, config),
        originTimestampInfo: {
            SkuUpdated: config.approximateCreationDateTime,
        },
        dataPoints: skuUpdatedMapper_1.mapDataPoints(productDoc),
    };
}
exports.mapSkuInventoryUpdateData = mapSkuInventoryUpdateData;
function mapSkuInventoryUpdateSkuList(productDoc, config) {
    return [
        {
            id: skuUpdatedMapper_1.mapSkuListId(productDoc),
            batchId: skuUpdatedMapper_1.mapSkuListBatchId(),
            productId: productDoc.productId,
            stockLevel: productDoc.inventory.qty,
            inStock: productDoc.inventory.status === 'AVAILABLE' && productDoc.inventory.qty > 0,
            bossTotal: productDoc.inventory.bossTotalQty,
            purchaseOrderQuantity: productDoc.inventory.purchaseOrderQty,
            discontinuedCode: productDoc.discontinuedCode,
            expectedShipDate: productDoc.shipping.expectedShipDate,
            deliveryDays: productDoc.shipping.deliveryDays,
            useSkuAsset: productDoc.flags.useSkuAsset,
            exclusive: productDoc.flags.exclusive,
            isPerishable: productDoc.flags.perishableFlag,
            media: null,
        },
    ];
}
exports.mapSkuInventoryUpdateSkuList = mapSkuInventoryUpdateSkuList;
//# sourceMappingURL=skuInventoryUpdatedMapper.js.map