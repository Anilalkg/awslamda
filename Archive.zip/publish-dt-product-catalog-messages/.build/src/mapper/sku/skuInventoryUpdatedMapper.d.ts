import { ISkuInventoryUpdated, ISkuInventoryUpdatedSkuList } from '../../models/skuInventoryUpdatedMessage';
import { IProduct } from '../../models/product';
import { RecordMapperConfig, StreamRecord } from '../../types';
export declare function mapSkuInventoryUpdateData(streamRecord: StreamRecord, config: RecordMapperConfig): ISkuInventoryUpdated;
export declare function mapSkuInventoryUpdateSkuList(productDoc: IProduct, config: RecordMapperConfig): ISkuInventoryUpdatedSkuList[];
