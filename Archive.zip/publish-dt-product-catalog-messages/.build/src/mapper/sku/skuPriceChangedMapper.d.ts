import { ISkuUpdatedSkuList, ISkuUpdated, ISkuUpdatedSkuListDataPoints, ISkuUpdatedDataPoints } from '../../models/skuUpdatedMessage';
export declare function mapPriceChangedSkuUpdate(skuUpdatedMessage: ISkuUpdated): ISkuUpdated;
export declare function mapPriceChangedSkuUpdateSkuList(skuList: ISkuUpdatedSkuList[]): ISkuUpdatedSkuList[];
export declare function mapPriceChangedSkuUpdateListDataPoints(dataPoints: ISkuUpdatedSkuListDataPoints): ISkuUpdatedSkuListDataPoints;
export declare function mapPriceChangeSkuUpdateDataPoints(dataPoints: ISkuUpdatedDataPoints): ISkuUpdatedDataPoints;
