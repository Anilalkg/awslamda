"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPriceChangeSkuUpdateDataPoints = exports.mapPriceChangedSkuUpdateListDataPoints = exports.mapPriceChangedSkuUpdateSkuList = exports.mapPriceChangedSkuUpdate = void 0;
function mapPriceChangedSkuUpdate(skuUpdatedMessage) {
    return {
        ...skuUpdatedMessage,
        skuList: mapPriceChangedSkuUpdateSkuList(skuUpdatedMessage.skuList),
        dataPoints: mapPriceChangeSkuUpdateDataPoints(skuUpdatedMessage.dataPoints),
    };
}
exports.mapPriceChangedSkuUpdate = mapPriceChangedSkuUpdate;
function mapPriceChangedSkuUpdateSkuList(skuList) {
    return skuList.map((skuItem) => ({
        ...skuItem,
        dataPoints: mapPriceChangedSkuUpdateListDataPoints(skuItem.dataPoints),
    }));
}
exports.mapPriceChangedSkuUpdateSkuList = mapPriceChangedSkuUpdateSkuList;
function mapPriceChangedSkuUpdateListDataPoints(dataPoints) {
    return {
        ...dataPoints,
        DiscontinuedCode: 'V',
    };
}
exports.mapPriceChangedSkuUpdateListDataPoints = mapPriceChangedSkuUpdateListDataPoints;
function mapPriceChangeSkuUpdateDataPoints(dataPoints) {
    return {
        ...dataPoints,
        SkuListData: dataPoints.SkuListData.map((skuListItem) => mapPriceChangedSkuUpdateListDataPoints(skuListItem)),
    };
}
exports.mapPriceChangeSkuUpdateDataPoints = mapPriceChangeSkuUpdateDataPoints;
//# sourceMappingURL=skuPriceChangedMapper.js.map