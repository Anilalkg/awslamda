"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapSkuInventoryUpdates = exports.mapSkuUpdates = void 0;
const mapHelpers_1 = require("../../utils/mapHelpers");
const skuUpdatedMapper_1 = require("./skuUpdatedMapper");
const skuInventoryUpdatedMapper_1 = require("./skuInventoryUpdatedMapper");
const skuPriceChangedMapper_1 = require("./skuPriceChangedMapper");
function mapSkuUpdates(event, config) {
    return event.Records.reduce((mappedRecords, record) => {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(skuUpdatedMapper_1.mapSkuUpdateData(record.dynamodb.NewImage, recordConfig));
        }
        if (mapHelpers_1.isPriceChanged(record)) {
            const mappedOldSkuUpdate = skuUpdatedMapper_1.mapSkuUpdateData(record.dynamodb.OldImage, recordConfig);
            mappedRecords.push(skuPriceChangedMapper_1.mapPriceChangedSkuUpdate(mappedOldSkuUpdate));
        }
        return mappedRecords;
    }, []);
}
exports.mapSkuUpdates = mapSkuUpdates;
function mapSkuInventoryUpdates(event, config) {
    return event.Records.reduce((mappedRecords, record) => {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(skuInventoryUpdatedMapper_1.mapSkuInventoryUpdateData(record.dynamodb.NewImage, recordConfig));
        }
        return mappedRecords;
    }, []);
}
exports.mapSkuInventoryUpdates = mapSkuInventoryUpdates;
//# sourceMappingURL=index.js.map