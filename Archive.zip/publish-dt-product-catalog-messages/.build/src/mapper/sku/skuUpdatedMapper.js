"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapDataPoints = exports.mapSkuListDataPoints = exports.mapSkuListStyleId = exports.mapSkuListIsNewColor = exports.mapSkuListMedia = exports.mapSkuListDiscontinuedCode = exports.mapSkuListCmosSkuId = exports.mapSkuListBatchId = exports.mapSkuListId = exports.mapSkuUpdateSkuList = exports.mapSkuUpdateData = void 0;
const aws_sdk_1 = require("aws-sdk");
function mapSkuUpdateData(streamRecord, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    return {
        eventType: 'SkuUpdated',
        batchId: config.batchId,
        id: productDoc.productId,
        exclusive: productDoc.flags.exclusive,
        skuList: mapSkuUpdateSkuList(productDoc, config),
        originTimestampInfo: {
            SkuUpdated: config.approximateCreationDateTime,
        },
        dataPoints: exports.mapDataPoints(productDoc),
    };
}
exports.mapSkuUpdateData = mapSkuUpdateData;
function mapSkuUpdateSkuList(productDoc, config) {
    return [
        {
            id: exports.mapSkuListId(productDoc),
            batchId: exports.mapSkuListBatchId(),
            sequenceNumber: productDoc.skuSequenceNumber,
            productId: productDoc.productId,
            cmosSkuId: productDoc.cmosSkuId,
            pimSkuId: productDoc.skuNumber,
            codeUpc: productDoc.codeUpc,
            colorName: productDoc.color.name,
            sizeName: productDoc.size.name,
            stockLevel: productDoc.inventory.qty,
            inStock: productDoc.inventory.status === 'AVAILABLE' && productDoc.inventory.qty > 0,
            bossTotal: productDoc.inventory.bossTotalQty,
            purchaseOrderQuantity: productDoc.inventory.purchaseOrderQty,
            discontinuedCode: productDoc.discontinuedCode,
            dropShip: productDoc.flags.dropshipFlag,
            shipFromStore: productDoc.shipping.shipFromStore,
            colorKey: productDoc.color.key,
            sizeKey: productDoc.size.key,
            pimColorKey: productDoc.color.pimKey,
            pimSizeKey: productDoc.size.pimKey,
            depth: productDoc.shipping.boxedDepthInches,
            height: productDoc.shipping.boxedHeightInches,
            width: productDoc.shipping.boxedWidthInches,
            giftWrappableFlag: productDoc.flags.giftWrappableFlag,
            iceFlag: productDoc.iceFlag,
            swatchPath: productDoc.swatchPath,
            expectedShipDate: productDoc.shipping.expectedShipDate,
            deliveryDays: productDoc.shipping.deliveryDays,
            media: exports.mapSkuListMedia(productDoc),
            defaultColor: productDoc.color.default,
            useSkuAsset: productDoc.flags.useSkuAsset,
            displaySwatchImg: productDoc.swatchPath !== null,
            isPerishable: productDoc.flags.perishableFlag,
            isNewColor: false,
            vendorId: productDoc.vendorId,
            hexCode: productDoc.hexValue,
            suggestedInterval: Number(productDoc.suggestedInterval),
            styleId: exports.mapSkuListStyleId(),
            pimColorCode: productDoc.color.pimCode,
            pimSizeCode: productDoc.size.pimCode,
            colorFacet: productDoc.color.facet,
            exclusive: productDoc.flags.exclusive,
            originTimestampInfo: {
                SkuUpdated: config.approximateCreationDateTime,
            },
            fedexEligible: productDoc.flags.fedexEligibleFlag,
            dataPoints: exports.mapSkuListDataPoints(productDoc),
        },
    ];
}
exports.mapSkuUpdateSkuList = mapSkuUpdateSkuList;
exports.mapSkuListId = (productDoc) => productDoc.webSkuId;
exports.mapSkuListBatchId = () => null;
exports.mapSkuListCmosSkuId = () => null;
exports.mapSkuListDiscontinuedCode = (productDoc) => productDoc.discontinuedCode;
exports.mapSkuListMedia = (productDoc) => {
    var _a;
    return (((_a = productDoc.digitalAssets) === null || _a === void 0 ? void 0 : _a.map((digitalAsset) => ({
        tag: digitalAsset.mediaTag,
        url: digitalAsset.url,
    }))) || []);
};
exports.mapSkuListIsNewColor = () => null;
exports.mapSkuListStyleId = () => null;
exports.mapSkuListDataPoints = (productDoc) => ({
    Size: productDoc.size.name,
    Color: productDoc.color.name,
    Instock: productDoc.inventory.status === 'AVAILABLE' && productDoc.inventory.qty > 0,
    Exclusive: productDoc.flags.exclusive,
    DiscontinuedCode: exports.mapSkuListDiscontinuedCode(productDoc),
    ProductId: productDoc.productId,
    POQty: productDoc.inventory.purchaseOrderQty,
    SkuId: exports.mapSkuListId(productDoc),
    StockLevel: productDoc.inventory.qty,
});
exports.mapDataPoints = (productDoc) => ({
    ProductId: productDoc.productId,
    SkuListData: [exports.mapSkuListDataPoints(productDoc)],
});
//# sourceMappingURL=skuUpdatedMapper.js.map