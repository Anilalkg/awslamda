import { DynamoDBRecord, DynamoDBStreamEvent } from 'aws-lambda';
import { IMediaUpdateMedia, IMediaUpdateMessage } from '../models/mediaUpdateMessage';
import { IProduct } from '../models/product';
import { MessageMapperConfig } from '../types';
export declare const MEDIA_UPDATE_MESSAGE_TYPE = "Product media event";
export declare function mapMediaUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IMediaUpdateMessage[];
export declare function mapMediaUpdatesData(record: DynamoDBRecord, config: MessageMapperConfig): IMediaUpdateMessage;
export declare function mapMedia(productDoc: IProduct, approximateCreationDateTime: string): {
    [mediaTag: string]: IMediaUpdateMedia;
};
