"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapAttributes = exports.mapHierarchy = exports.mapCodeSetType = exports.mapMetaInfo = exports.mapProductFlagInLookBook = exports.mapProductFlagIsNewArrival = exports.mapMedia = exports.mapSkuList = exports.mapDesignerDescriptionTitle = exports.mapMerchandiseType = exports.mapSizeGuide = exports.mapHelp = exports.mapDescriptionTitle = exports.mapGroupType = exports.mapDisplayAsGroupEligible = exports.mapRelatedProducts = exports.mapChildProductIds = exports.mapPsAttributes = exports.mapParentGroupIds = exports.mapProductUpdatedDataPoints = exports.mapProductUpdatedTimestampInfo = exports.mapItemGroupUpdateData = exports.mapProductUpdateData = void 0;
const aws_sdk_1 = require("aws-sdk");
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const product_1 = require("../../models/product");
const dynamoMessages_1 = require("../../storage/dynamoMessages");
async function mapProductUpdateData(streamRecord, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    return {
        eventType: 'ProductUpdated',
        batchId: config.batchId,
        id: productDoc.productId,
        childProductIds: exports.mapChildProductIds(),
        parentGroupIds: exports.mapParentGroupIds(productDoc),
        relatedProducts: exports.mapRelatedProducts(),
        isGroup: productDoc.flags.isGroup,
        belongsToGroup: productDoc.flags.belongsToGroup,
        displayAsGroupEligible: exports.mapDisplayAsGroupEligible(),
        groupType: exports.mapGroupType(),
        displayName: productDoc.displayName,
        descriptionTitle: exports.mapDescriptionTitle(),
        shortDescription: productDoc.shortDescription,
        longDescription: productDoc.longDescription,
        notes: productDoc.notes,
        help: exports.mapHelp(),
        sizeGuide: exports.mapSizeGuide(),
        cmosCatalogId: productDoc.cmosCatalogId,
        cmosItem: productDoc.cmosItem,
        merchandiseType: productDoc.merchandiseType,
        catalogType: productDoc.catalogType,
        pimStyle: productDoc.pimStyle,
        departmentDesc: productDoc.department.name,
        classDesc: productDoc.class.name,
        designerName: productDoc.designer.name,
        designerDescriptionTitle: exports.mapDesignerDescriptionTitle(),
        designerDescription: productDoc.designer.description,
        parentheticalCharge: productDoc.parentheticalCharge,
        intlParentheticalAmount: productDoc.intlParentheticalAmount,
        personalShopper: false,
        exclusive: productDoc.flags.exclusive,
        preOrder: productDoc.flags.preOrder,
        displayable: await mapDisplayable(productDoc),
        dynamicImageSkuColor: productDoc.flags.dynamicImageSkuColor,
        canonicalUrl: productDoc.canonicalUrl,
        designerBoutiqueUrl: productDoc.designerBoutiqueUrl,
        serviceLevelCodes: productDoc.serviceLevelCodes,
        skuList: exports.mapSkuList(),
        media: exports.mapMedia(),
        productFlags: {
            isOnlyAtNM: productDoc.flags.isOnlyAtNM,
            dynamicImageSkuColor: productDoc.flags.dynamicImageSkuColor,
            hasMoreColors: productDoc.flags.hasMoreColors,
            isNewArrival: exports.mapProductFlagIsNewArrival(),
            isEditorial: productDoc.flags.isEditorial,
            isEvening: productDoc.flags.isEvening,
            inLookBook: exports.mapProductFlagInLookBook(),
            showMonogramLabel: productDoc.flags.showMonogramLabel,
            previewSupported: productDoc.flags.previewSupported,
        },
        hideInternationally: productDoc.hideInternationally,
        onSale: productDoc.flags.onSale,
        suppressCheckout: productDoc.suppressCheckout,
        aliPay: false,
        parenthetical: productDoc.flags.parenthetical,
        departmentCode: productDoc.department.code,
        commodeCode: productDoc.commodeCode,
        classCode: productDoc.class.code,
        metaInfo: exports.mapMetaInfo(),
        codeSetType: exports.mapCodeSetType(),
        offline: productDoc.offline,
        originTimestampInfo: exports.mapProductUpdatedTimestampInfo(config.approximateCreationDateTime),
        sellableDate: mapSellableDate(productDoc),
        liveTreeDate: productDoc.liveTreeDate,
        adornDate: productDoc.adornDate,
        isBvd: productDoc.flags.storeOnly,
        genderCode: productDoc.genderCode,
        restrictedStates: productDoc.restrictedStates,
        hierarchy: exports.mapHierarchy(),
        attributes: exports.mapAttributes(),
        dataPoints: exports.mapProductUpdatedDataPoints(productDoc),
        restrictedCodes: '',
        psAttributes: exports.mapPsAttributes(productDoc),
    };
}
exports.mapProductUpdateData = mapProductUpdateData;
function mapItemGroupUpdateData(streamRecord, config) {
    const itemGroupDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    return {
        eventType: 'ProductUpdated',
        batchId: config.batchId,
        id: itemGroupDoc.PartitionKey,
        childProductIds: itemGroupDoc.childProductIds,
        parentGroupIds: null,
        isGroup: true,
        belongsToGroup: false,
        displayAsGroupEligible: exports.mapDisplayAsGroupEligible(),
        groupType: exports.mapGroupType(),
        displayName: itemGroupDoc.displayName,
        descriptionTitle: exports.mapDescriptionTitle(),
        shortDescription: itemGroupDoc.description,
        longDescription: itemGroupDoc.description,
        notes: itemGroupDoc.notes,
        help: itemGroupDoc.help,
        sizeGuide: itemGroupDoc.sizeGuide,
        cmosCatalogId: itemGroupDoc.cmosCatalogId,
        cmosItem: itemGroupDoc.cmosItem,
        merchandiseType: itemGroupDoc.merchandiseType,
        catalogType: itemGroupDoc.catalogType,
        pimStyle: itemGroupDoc.pimStyle,
        departmentDesc: itemGroupDoc.departmentDesc,
        classDesc: itemGroupDoc.classDesc,
        designerName: itemGroupDoc.designerName,
        designerDescriptionTitle: itemGroupDoc.designerDescriptionTitle,
        designerDescription: itemGroupDoc.designerDescription,
        parentheticalCharge: itemGroupDoc.parentheticalCharge.toString(),
        intlParentheticalAmount: itemGroupDoc.intlParentheticalAmount.toString(),
        personalShopper: false,
        exclusive: itemGroupDoc.exclusive,
        preOrder: itemGroupDoc.preOrder,
        displayable: itemGroupDoc.displayable,
        dynamicImageSkuColor: itemGroupDoc.dynamicImageSkuColor,
        canonicalUrl: itemGroupDoc.canonicalUrl,
        designerBoutiqueUrl: itemGroupDoc.designerBoutiqueUrl,
        serviceLevelCodes: itemGroupDoc.serviceLevelCodes,
        skuList: [],
        media: exports.mapMedia(),
        productFlags: itemGroupDoc.productFlags,
        hideInternationally: itemGroupDoc.hideInternationally,
        onSale: itemGroupDoc.onSale,
        suppressCheckout: itemGroupDoc.suppressCheckout,
        aliPay: false,
        parenthetical: itemGroupDoc.parenthetical,
        departmentCode: itemGroupDoc.departmentCode,
        commodeCode: itemGroupDoc.commodeCode,
        classCode: itemGroupDoc.classCode,
        metaInfo: itemGroupDoc.metaInfo,
        codeSetType: itemGroupDoc.codeSetType,
        sizeLabels: itemGroupDoc.sizeLabels,
        offline: itemGroupDoc.offline,
        originTimestampInfo: itemGroupDoc.originTimestampInfo,
        sellableDate: itemGroupDoc.sellableDate,
        liveTreeDate: itemGroupDoc.liveTreeDate,
        adornDate: itemGroupDoc.adornDate,
        isBvd: itemGroupDoc.isBvd,
        genderCode: itemGroupDoc.genderCode,
        restrictedStates: itemGroupDoc.restrictedStates,
        hierarchy: itemGroupDoc.hierarchy,
        attributes: itemGroupDoc.attributes
    };
}
exports.mapItemGroupUpdateData = mapItemGroupUpdateData;
const mapDisplayable = async (product) => {
    if (product === null || product === void 0 ? void 0 : product.displayable) {
        return true;
    }
    const products = await dynamoMessages_1.getDisplayItems(product);
    for (const product of products) {
        if (product === null || product === void 0 ? void 0 : product.displayable) {
            logger_1.default.debug({ productDisplayable: 'Product is displayable', product: product.productId, skuNum: product.skuNumber });
            return true;
        }
    }
    logger_1.default.debug({ productDisplayable: 'All skus are out of stock, so not displayable', product: product.productId });
    return false;
};
const mapSellableDate = (productDoc) => {
    return productDoc.sellableDate ? new Date(productDoc.sellableDate).toISOString().replace('Z', '') : null;
};
exports.mapProductUpdatedTimestampInfo = (productUpdated) => ({
    ProductUpdated: productUpdated,
});
exports.mapProductUpdatedDataPoints = (productDoc) => ({
    ProductId: productDoc.productId,
});
exports.mapParentGroupIds = (productDoc) => {
    return productDoc === null || productDoc === void 0 ? void 0 : productDoc.displayGroups;
};
exports.mapPsAttributes = (productDoc) => {
    const psAttributes = [];
    const psa = {};
    if (productDoc === null || productDoc === void 0 ? void 0 : productDoc.psAttributes) {
        Object.entries(productDoc === null || productDoc === void 0 ? void 0 : productDoc.psAttributes).forEach(([key, value]) => {
            psa[key] = value.map(item => item.name);
        });
        psAttributes.push(psa);
    }
    return psAttributes;
};
exports.mapChildProductIds = () => [];
exports.mapRelatedProducts = () => [];
exports.mapDisplayAsGroupEligible = () => null;
exports.mapGroupType = () => null;
exports.mapDescriptionTitle = () => null;
exports.mapHelp = () => null;
exports.mapSizeGuide = () => null;
exports.mapMerchandiseType = () => null;
exports.mapDesignerDescriptionTitle = () => null;
exports.mapSkuList = () => [];
exports.mapMedia = () => (new product_1.Media());
exports.mapProductFlagIsNewArrival = () => null;
exports.mapProductFlagInLookBook = () => null;
exports.mapMetaInfo = () => null;
exports.mapCodeSetType = () => null;
exports.mapHierarchy = () => [];
exports.mapAttributes = () => [];
//# sourceMappingURL=productUpdatedMapper.js.map