import { RecordMapperConfig, StreamRecord } from '../../types';
import { IProductDimensionsUpdated } from '../../models/productDimensionsUpdatedMessage';
export declare function mapProductDimensionUpdateData(streamRecord: StreamRecord, config: RecordMapperConfig): IProductDimensionsUpdated;
