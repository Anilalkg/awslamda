"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapProductDimensionUpdateData = void 0;
const aws_sdk_1 = require("aws-sdk");
const productUpdatedMapper_1 = require("./productUpdatedMapper");
function mapProductDimensionUpdateData(streamRecord, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    return {
        eventType: 'PRODUCT_DIMENSIONS_UPDATED',
        batchId: config.batchId,
        id: productDoc.productId,
        dataPoints: productUpdatedMapper_1.mapProductUpdatedDataPoints(productDoc),
        psAttributes: productUpdatedMapper_1.mapPsAttributes(productDoc),
    };
}
exports.mapProductDimensionUpdateData = mapProductDimensionUpdateData;
//# sourceMappingURL=productDimensionUpdateMapper.js.map