"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPriceChangedProductUpdate = void 0;
function mapPriceChangedProductUpdate(productUpdatedMessage) {
    return {
        ...productUpdatedMessage,
        displayable: false,
        offline: true,
    };
}
exports.mapPriceChangedProductUpdate = mapPriceChangedProductUpdate;
//# sourceMappingURL=productPriceChangedMapper.js.map