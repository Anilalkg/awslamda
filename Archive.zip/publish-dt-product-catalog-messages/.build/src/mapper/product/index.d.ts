import { DynamoDBStreamEvent } from 'aws-lambda';
import { IProductUpdated } from '../../models/productUpdatedMessage';
import { IProductDimensionsUpdated } from '../../models/productDimensionsUpdatedMessage';
import { MessageMapperConfig } from '../../types';
export declare function mapProductUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): Promise<IProductUpdated[]>;
export declare function mapProductDimensionsUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IProductDimensionsUpdated[];
export declare function mapItemGroupUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IProductUpdated[];
