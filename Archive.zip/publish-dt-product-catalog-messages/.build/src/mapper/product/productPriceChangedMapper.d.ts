import { IProductUpdated } from '../../models/productUpdatedMessage';
export declare function mapPriceChangedProductUpdate(productUpdatedMessage: IProductUpdated): IProductUpdated;
