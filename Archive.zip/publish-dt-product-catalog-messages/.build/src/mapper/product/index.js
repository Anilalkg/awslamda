"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapItemGroupUpdates = exports.mapProductDimensionsUpdates = exports.mapProductUpdates = void 0;
const mapHelpers_1 = require("../../utils/mapHelpers");
const productPriceChangedMapper_1 = require("./productPriceChangedMapper");
const productUpdatedMapper_1 = require("./productUpdatedMapper");
const productDimensionUpdateMapper_1 = require("./productDimensionUpdateMapper");
async function mapProductUpdates(event, config) {
    const mappedRecords = [];
    for (const record of event.Records) {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(await productUpdatedMapper_1.mapProductUpdateData(record.dynamodb.NewImage, recordConfig));
        }
        if (mapHelpers_1.isPriceChanged(record)) {
            const mappedOldProductUpdate = await productUpdatedMapper_1.mapProductUpdateData(record.dynamodb.OldImage, recordConfig);
            mappedRecords.push(productPriceChangedMapper_1.mapPriceChangedProductUpdate(mappedOldProductUpdate));
        }
    }
    return mappedRecords;
}
exports.mapProductUpdates = mapProductUpdates;
function mapProductDimensionsUpdates(event, config) {
    return event.Records.reduce((mappedRecords, record) => {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(productDimensionUpdateMapper_1.mapProductDimensionUpdateData(record.dynamodb.NewImage, recordConfig));
        }
        return mappedRecords;
    }, []);
}
exports.mapProductDimensionsUpdates = mapProductDimensionsUpdates;
function mapItemGroupUpdates(event, config) {
    return event.Records.reduce((mappedRecords, record) => {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(productUpdatedMapper_1.mapItemGroupUpdateData(record.dynamodb.NewImage, recordConfig));
        }
        return mappedRecords;
    }, []);
}
exports.mapItemGroupUpdates = mapItemGroupUpdates;
//# sourceMappingURL=index.js.map