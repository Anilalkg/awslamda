import { IAdornmentsUpdated, IPriceAdornment } from '../../models/adornmentsUpdatedMessage';
import { IProduct } from '../../models/product';
import { StreamRecord, RecordMapperConfig } from '../../types';
export declare function mapAdornmentsUpdatedData(streamRecord: StreamRecord, config: RecordMapperConfig): IAdornmentsUpdated;
export declare function mapPriceAdornments(productDoc: IProduct): IPriceAdornment[];
export declare function calculateMaxAdornmentPrice(originalPrice: number, retailPrice: number): number;
