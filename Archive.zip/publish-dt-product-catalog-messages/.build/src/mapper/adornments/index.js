"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapAdornmentsUpdated = void 0;
const mapHelpers_1 = require("../../utils/mapHelpers");
const adornmentsPriceChangedMapper_1 = require("./adornmentsPriceChangedMapper");
const adornmentsUpdatedMapper_1 = require("./adornmentsUpdatedMapper");
function mapAdornmentsUpdated(event, config) {
    return event.Records.reduce((mappedRecords, record) => {
        const recordConfig = {
            ...config,
            approximateCreationDateTime: mapHelpers_1.getApproximateCreationDateTime(record),
        };
        if (mapHelpers_1.isUpdated(record)) {
            mappedRecords.push(adornmentsUpdatedMapper_1.mapAdornmentsUpdatedData(record.dynamodb.NewImage, recordConfig));
        }
        if (mapHelpers_1.isPriceChanged(record)) {
            const mappedOldAdornmentsUpdate = adornmentsUpdatedMapper_1.mapAdornmentsUpdatedData(record.dynamodb.OldImage, recordConfig);
            mappedRecords.push(adornmentsPriceChangedMapper_1.mapPriceChangedAdornmentsUpdate(mappedOldAdornmentsUpdate));
        }
        return mappedRecords;
    }, []);
}
exports.mapAdornmentsUpdated = mapAdornmentsUpdated;
//# sourceMappingURL=index.js.map