import { IAdornmentsUpdated } from '../../models/adornmentsUpdatedMessage';
export declare function mapPriceChangedAdornmentsUpdate(adornmentsUpdatedMessage: IAdornmentsUpdated): IAdornmentsUpdated;
