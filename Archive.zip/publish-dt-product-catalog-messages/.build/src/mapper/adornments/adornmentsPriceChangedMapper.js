"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPriceChangedAdornmentsUpdate = void 0;
function mapPriceChangedAdornmentsUpdate(adornmentsUpdatedMessage) {
    return {
        ...adornmentsUpdatedMessage,
        retailPrice: 0,
        priceAdornments: [],
        dataPoints: {
            ...adornmentsUpdatedMessage.dataPoints,
            RetailPrice: 0,
            MaxAdornmentPrice: 0,
        },
    };
}
exports.mapPriceChangedAdornmentsUpdate = mapPriceChangedAdornmentsUpdate;
//# sourceMappingURL=adornmentsPriceChangedMapper.js.map