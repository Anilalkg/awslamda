"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateMaxAdornmentPrice = exports.mapPriceAdornments = exports.mapAdornmentsUpdatedData = void 0;
const aws_sdk_1 = require("aws-sdk");
function mapAdornmentsUpdatedData(streamRecord, config) {
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(streamRecord);
    let eventType;
    if (productDoc.price.original === productDoc.price.retail) {
        eventType = 'AdornmentsRemoved';
    }
    else {
        eventType = 'AdornmentsUpdated';
    }
    return {
        eventType: eventType,
        batchId: config.batchId,
        id: productDoc.productId,
        retailPrice: productDoc.price.retail,
        priceAdornments: mapPriceAdornments(productDoc),
        dataPoints: {
            RetailPrice: productDoc.price.retail,
            MaxAdornmentPrice: calculateMaxAdornmentPrice(productDoc.price.original, productDoc.price.retail),
        },
        originTimestampInfo: {
            AdornmentsUpdated: config.approximateCreationDateTime,
        },
    };
}
exports.mapAdornmentsUpdatedData = mapAdornmentsUpdatedData;
function mapPriceAdornments(productDoc) {
    if (productDoc.price.original === productDoc.price.retail) {
        return [];
    }
    return [
        {
            id: null,
            batchId: null,
            label: 'Original',
            price: Number(productDoc.price.original),
            productId: productDoc.productId,
        },
        {
            id: null,
            batchId: null,
            label: 'NOW',
            price: Number(productDoc.price.retail),
            productId: productDoc.productId,
        },
    ];
}
exports.mapPriceAdornments = mapPriceAdornments;
function calculateMaxAdornmentPrice(originalPrice, retailPrice) {
    const originalPriceAsNumber = originalPrice;
    return originalPriceAsNumber !== retailPrice ? originalPriceAsNumber : 0;
}
exports.calculateMaxAdornmentPrice = calculateMaxAdornmentPrice;
//# sourceMappingURL=adornmentsUpdatedMapper.js.map