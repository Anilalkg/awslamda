import { DynamoDBStreamEvent } from 'aws-lambda';
import { IAdornmentsUpdated } from '../../models/adornmentsUpdatedMessage';
import { MessageMapperConfig } from '../../types';
export declare function mapAdornmentsUpdated(event: DynamoDBStreamEvent, config: MessageMapperConfig): IAdornmentsUpdated[];
