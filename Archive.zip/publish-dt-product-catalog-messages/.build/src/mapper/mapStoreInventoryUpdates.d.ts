import { DynamoDBStreamEvent, DynamoDBRecord } from 'aws-lambda';
import { IStoreInventoryUpdated, IStoreInventoryUpdatedSkuStore, IStoreSkuListData } from '../models/storeInventoryUpdatedMessage';
import { IProductStoreInventory } from '../models/product';
import { MessageMapperConfig } from '../types';
export declare function mapStoreInventoryUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IStoreInventoryUpdated[];
export declare function mapStoreInventoryUpdateData(record: DynamoDBRecord, config: MessageMapperConfig): IStoreInventoryUpdated;
export declare const mapSkuStores: (sourceStoreInvList: IProductStoreInventory[], skuNumber: string) => IStoreInventoryUpdatedSkuStore[];
export declare const mapDataPointsStoreSkuListData: (skuNumber: string) => IStoreSkuListData[];
