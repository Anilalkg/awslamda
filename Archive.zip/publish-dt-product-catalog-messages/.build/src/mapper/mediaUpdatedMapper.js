"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapMedia = exports.mapMediaUpdatesData = exports.mapMediaUpdates = exports.MEDIA_UPDATE_MESSAGE_TYPE = void 0;
const aws_sdk_1 = require("aws-sdk");
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const uuid_1 = require("uuid");
exports.MEDIA_UPDATE_MESSAGE_TYPE = 'Product media event';
function mapMediaUpdates(event, config) {
    return event.Records.filter((record) => record.eventName === 'INSERT' || record.eventName === 'MODIFY').map((record) => mapMediaUpdatesData(record, config));
}
exports.mapMediaUpdates = mapMediaUpdates;
function mapMediaUpdatesData(record, config) {
    var _a;
    const productDoc = aws_sdk_1.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
    const approximateCreationDateTime = new Date(record.dynamodb.ApproximateCreationDateTime * 1000).toISOString().replace('Z', '');
    logger_1.default.debug({ message: 'Unmarshalled Document', data: productDoc });
    const mappedMediaUpdateMessage = {
        eventType: 'MediaUpdated',
        id: productDoc.productId,
        batchId: config.batchId,
        media: mapMedia(productDoc, approximateCreationDateTime),
        originTimestampInfo: {
            MediaUpdated: approximateCreationDateTime,
        },
        dataPoints: {
            ProductId: productDoc.productId,
            DefaultColor: (_a = productDoc === null || productDoc === void 0 ? void 0 : productDoc.color) === null || _a === void 0 ? void 0 : _a.default,
            DispItem: (productDoc === null || productDoc === void 0 ? void 0 : productDoc.PartitionKey) + ":" + (productDoc === null || productDoc === void 0 ? void 0 : productDoc.SortKey)
        },
    };
    return mappedMediaUpdateMessage;
}
exports.mapMediaUpdatesData = mapMediaUpdatesData;
function mapMedia(productDoc, approximateCreationDateTime) {
    return productDoc.digitalAssets.reduce((result, digitalAsset) => {
        result[digitalAsset.mediaTag] = {
            id: `${uuid_1.v4()}:${digitalAsset.mediaTag}:${productDoc.productId}`,
            mediaTag: digitalAsset.mediaTag,
            mediaVersion: digitalAsset.mediaVersion,
            url: digitalAsset.url,
            productId: productDoc.productId,
            originTimestampInfo: {
                MediaUpdated: approximateCreationDateTime,
            },
            dataPoints: {
                Version: digitalAsset.mediaVersion,
                Tag: digitalAsset.mediaTag,
                Url: digitalAsset.url,
            },
            messageType: exports.MEDIA_UPDATE_MESSAGE_TYPE,
        };
        return result;
    }, {});
}
exports.mapMedia = mapMedia;
//# sourceMappingURL=mediaUpdatedMapper.js.map