"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processStoreInventoryUpdates = exports.processSkuInventoryUpdates = exports.processSkuUpdates = exports.processProductDimensionsUpdates = exports.processProductUpdates = exports.processAdornmentsUpdates = exports.processMediaUpdates = exports.processItemGroupUpdates = exports.processOmniCatalogItemGroupStream = exports.processOmniCatalogProductStream = void 0;
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const adornments_1 = require("../mapper/adornments");
const mediaUpdatedMapper_1 = require("../mapper/mediaUpdatedMapper");
const product_1 = require("../mapper/product");
const messagePublisher_1 = require("../utils/messagePublisher");
const sku_1 = require("../mapper/sku");
const mapStoreInventoryUpdates_1 = require("../mapper/mapStoreInventoryUpdates");
exports.processOmniCatalogProductStream = async (event) => {
    logger_1.default.debug({ message: 'Omni Catalog Product Stream Event', data: event });
    let connection;
    try {
        connection = await messagePublisher_1.establishConnection();
    }
    catch (error) {
        logger_1.default.error({ message: `Failed to connect to RabbitMq: ${error}` });
        return;
    }
    const currentDateTime = new Date().toISOString().replace('Z', '');
    const mapperConfig = {
        batchId: `Product-Hub-Auto-${currentDateTime}`,
    };
    await processProductUpdates(connection, event, mapperConfig);
    await processProductDimensionsUpdates(connection, event, mapperConfig);
    await processMediaUpdates(connection, event, mapperConfig);
    await processAdornmentsUpdates(connection, event, mapperConfig);
    await processSkuUpdates(connection, event, mapperConfig);
    await processSkuInventoryUpdates(connection, event, mapperConfig);
    await processStoreInventoryUpdates(connection, event, mapperConfig);
    await messagePublisher_1.closeConnection(connection);
};
exports.processOmniCatalogItemGroupStream = async (event) => {
    logger_1.default.debug({ message: 'Omni Catalog Product Stream Event', data: event });
    let connection;
    try {
        connection = await messagePublisher_1.establishConnection();
    }
    catch (error) {
        logger_1.default.error({ message: `Failed to connect to RabbitMq: ${error}` });
        return;
    }
    const currentDateTime = new Date().toISOString().replace('Z', '');
    const mapperConfig = {
        batchId: `Auto-${currentDateTime}`,
    };
    await processItemGroupUpdates(connection, event, mapperConfig);
    await messagePublisher_1.closeConnection(connection);
};
async function processItemGroupUpdates(connection, event, mapperConfig) {
    try {
        const mappedProductUpdates = product_1.mapItemGroupUpdates(event, mapperConfig);
        if (mappedProductUpdates.length > 0) {
            logger_1.default.debug({ message: 'Mapped Item Group Updates List', data: mappedProductUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedProductUpdates);
        }
        else {
            logger_1.default.debug({ message: 'Item Group Updates List is empty' });
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing Item Group ProductUpdated message: ${error}`);
    }
}
exports.processItemGroupUpdates = processItemGroupUpdates;
async function processMediaUpdates(connection, event, mapperConfig) {
    var _a, _b, _c, _d;
    try {
        const mappedMediaUpdates = mediaUpdatedMapper_1.mapMediaUpdates(event, mapperConfig);
        if (mappedMediaUpdates.length > 0 && ((_b = (_a = mappedMediaUpdates[0]) === null || _a === void 0 ? void 0 : _a.dataPoints) === null || _b === void 0 ? void 0 : _b.DefaultColor)) {
            logger_1.default.debug({ message: 'Mapped Media Updates List', data: mappedMediaUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedMediaUpdates);
        }
        else {
            logger_1.default.info({ message: 'MediaUpdated  List is empty or its not a default sku/color', MediaNotUpdatedFor: (_d = (_c = mappedMediaUpdates[0]) === null || _c === void 0 ? void 0 : _c.dataPoints) === null || _d === void 0 ? void 0 : _d.DispItem });
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing MediaUpdate message: ${error}`);
    }
}
exports.processMediaUpdates = processMediaUpdates;
async function processAdornmentsUpdates(connection, event, mapperConfig) {
    try {
        const mappedAdornmentsUpdated = adornments_1.mapAdornmentsUpdated(event, mapperConfig);
        if (mappedAdornmentsUpdated.length > 0) {
            logger_1.default.debug({ message: 'Mapped Adornments Updates List', data: mappedAdornmentsUpdated });
            await messagePublisher_1.publishToProductPriceQueue(connection, mappedAdornmentsUpdated);
        }
        else {
            logger_1.default.debug({ message: 'Adornments Updated List is empty' });
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing AdornmentsUpdated message: ${error}`);
    }
}
exports.processAdornmentsUpdates = processAdornmentsUpdates;
async function processProductUpdates(connection, event, mapperConfig) {
    try {
        const mappedProductUpdates = await product_1.mapProductUpdates(event, mapperConfig);
        if (mappedProductUpdates.length > 0) {
            logger_1.default.debug({ message: 'Mapped Product Updates List', data: mappedProductUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedProductUpdates);
        }
        else {
            logger_1.default.debug({ message: 'Product Updates List is empty' });
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing ProductUpdated message: ${error}`);
    }
}
exports.processProductUpdates = processProductUpdates;
async function processProductDimensionsUpdates(connection, event, mapperConfig) {
    try {
        const mappedProductUpdates = product_1.mapProductDimensionsUpdates(event, mapperConfig);
        if (mappedProductUpdates.length > 0) {
            logger_1.default.debug({ message: 'Mapped Product Dimensions Updates List', data: mappedProductUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedProductUpdates);
        }
        else {
            logger_1.default.debug({ message: 'Product Dimensions List is empty' });
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing PRODUCT_DIMENSIONS_UPDATED message: ${error}`);
    }
}
exports.processProductDimensionsUpdates = processProductDimensionsUpdates;
async function processSkuUpdates(connection, event, mapperConfig) {
    try {
        logger_1.default.info('Processing SkuUpdates');
        const mappedSkuUpdates = sku_1.mapSkuUpdates(event, mapperConfig);
        if (mappedSkuUpdates.length > 0) {
            logger_1.default.debug({ message: 'Mapped SkuUpdates List', data: mappedSkuUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedSkuUpdates);
        }
        else {
            logger_1.default.info('SkuUpdates list is empty');
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing SkuUpdates: ${error}`);
    }
}
exports.processSkuUpdates = processSkuUpdates;
async function processSkuInventoryUpdates(connection, event, mapperConfig) {
    try {
        logger_1.default.info('Processing SkuInventoryUpdates');
        const mappedSkuUpdates = sku_1.mapSkuInventoryUpdates(event, mapperConfig);
        if (mappedSkuUpdates.length > 0) {
            logger_1.default.debug({ message: 'Mapped SkuInventoryUpdates List', data: mappedSkuUpdates });
            await messagePublisher_1.publishToProductExchange(connection, mappedSkuUpdates);
        }
        else {
            logger_1.default.info('SkuInventoryUpdates list is empty');
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing SkuInventoryUpdates: ${error}`);
    }
}
exports.processSkuInventoryUpdates = processSkuInventoryUpdates;
async function processStoreInventoryUpdates(connection, event, mapperConfig) {
    try {
        logger_1.default.info('Processing StoreInventoryUpdatedMessage');
        const mappedStoreInventoryUpdates = mapStoreInventoryUpdates_1.mapStoreInventoryUpdates(event, mapperConfig);
        if (mappedStoreInventoryUpdates.length > 0) {
            logger_1.default.info({ message: 'Mapped StoreInventoryUpdates List', data: mappedStoreInventoryUpdates });
            await messagePublisher_1.publishToProductSkuStoresInventoryQueue(connection, mappedStoreInventoryUpdates);
        }
        else {
            logger_1.default.info('StoreInventoryUpdates list is empty');
        }
    }
    catch (error) {
        logger_1.default.error(`Error ocurred while processing StoreInventoryUpdated message: ${error}`);
    }
}
exports.processStoreInventoryUpdates = processStoreInventoryUpdates;
//# sourceMappingURL=streamHandler.js.map