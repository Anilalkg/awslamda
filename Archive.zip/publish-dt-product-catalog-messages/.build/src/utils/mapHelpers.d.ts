import { DynamoDBRecord } from 'aws-lambda';
export declare function isUpdated(record: DynamoDBRecord): boolean;
export declare function isPriceChanged(record: DynamoDBRecord): boolean;
export declare function getApproximateCreationDateTime(record: DynamoDBRecord): string;
