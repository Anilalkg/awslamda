"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.publishToProductSkuStoresInventoryQueue = exports.publishToProductPriceQueue = exports.publishToInventoryExchange = exports.publishToProductExchange = exports.publishToExchange = exports.publishToQueue = exports.closeConnection = exports.establishConnection = void 0;
const amqplib_1 = __importDefault(require("amqplib"));
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const RABBITMQ_HOST = process.env.RABBITMQ_HOST || '';
const RABBITMQ_USERNAME = process.env.RABBITMQ_USERNAME || '';
const RABBITMQ_PASSWORD = encodeURIComponent(process.env.RABBITMQ_PASSWORD || '');
const PRODUCT_EXCHANGE = process.env.PRODUCT_EXCHANGE || '';
const INVENTORY_EXCHANGE = process.env.INVENTORY_EXCHANGE || '';
const PRODUCT_PRICE_QUEUE = process.env.PRODUCT_PRICE_QUEUE || '';
const PRODUCT_SKU_STORES_INVENTORY_QUEUE = process.env.PRODUCT_SKU_STORES_INVENTORY_QUEUE || '';
async function establishConnection() {
    logger_1.default.debug({ message: 'Connecting to RabbitMQ...' });
    const connection = await amqplib_1.default.connect(`amqp://${RABBITMQ_USERNAME}:${RABBITMQ_PASSWORD}@${RABBITMQ_HOST}`);
    logger_1.default.debug({ message: 'RabbitMQ connection established!' });
    return connection;
}
exports.establishConnection = establishConnection;
async function closeConnection(connection) {
    logger_1.default.debug({ message: 'Closing connection to RabbitMQ...' });
    await connection.close();
    logger_1.default.debug({ message: 'RabbitMq connection closed!' });
}
exports.closeConnection = closeConnection;
async function publishToQueue(connection, data, config) {
    let channel;
    try {
        logger_1.default.debug({ message: 'Creating Channel...' });
        channel = await connection.createChannel();
        logger_1.default.debug({ message: 'Channel created, Asserting queue...' });
        await channel.assertQueue(config.queueName, config.queueOptions);
        data.forEach((messageData) => {
            const message = JSON.stringify(messageData);
            logger_1.default.info(`Sending message to queue: ${message}`);
            channel.sendToQueue(config.queueName, Buffer.from(message), { ...config.publishOptions, headers: { "Product-Hub": "true" } });
        });
        logger_1.default.debug({ message: `Closing Channel ${config.queueName}...` });
    }
    catch (error) {
        logger_1.default.error(`Error occurred while publishing message to queue: ${error}`);
    }
    if (channel) {
        await channel.close();
        logger_1.default.debug({ message: `Channel ${config.queueName} closed` });
    }
}
exports.publishToQueue = publishToQueue;
async function publishToExchange(connection, data, config) {
    let channel;
    try {
        logger_1.default.debug({ message: 'Creating Channel...' });
        channel = await connection.createChannel();
        logger_1.default.debug({ message: 'Channel created, Asserting exchange...' });
        await channel.assertExchange(config.exchangeName, config.exchangeType, config.exchangeOptions);
        data.forEach((messageData) => {
            const message = JSON.stringify(messageData);
            logger_1.default.info(`Publishing message to exchange: ${message}`);
            channel.publish(config.exchangeName, '', Buffer.from(message), { ...config.publishOptions, type: messageData === null || messageData === void 0 ? void 0 : messageData.eventType, headers: { "Product-Hub": "true" } });
        });
    }
    catch (error) {
        logger_1.default.error(`Error occurred while publishing message to exchange: ${error}`);
    }
    if (channel) {
        channel.close();
    }
}
exports.publishToExchange = publishToExchange;
async function publishToProductExchange(connection, data) {
    await publishToExchange(connection, data, {
        exchangeName: PRODUCT_EXCHANGE,
        exchangeType: 'fanout',
        exchangeOptions: { durable: true },
    });
}
exports.publishToProductExchange = publishToProductExchange;
async function publishToInventoryExchange(connection, data) {
    await publishToExchange(connection, data, {
        exchangeName: INVENTORY_EXCHANGE,
        exchangeType: 'fanout',
        exchangeOptions: { durable: true },
    });
}
exports.publishToInventoryExchange = publishToInventoryExchange;
async function publishToProductPriceQueue(connection, data) {
    await publishToQueue(connection, data, {
        queueName: PRODUCT_PRICE_QUEUE,
        publishOptions: {
            contentType: 'application/json',
            type: 'AdornmentsUpdated'
        },
    });
}
exports.publishToProductPriceQueue = publishToProductPriceQueue;
async function publishToProductSkuStoresInventoryQueue(connection, data) {
    await publishToQueue(connection, data, {
        queueName: PRODUCT_SKU_STORES_INVENTORY_QUEUE,
        publishOptions: {
            contentType: 'application/json',
        },
    });
}
exports.publishToProductSkuStoresInventoryQueue = publishToProductSkuStoresInventoryQueue;
//# sourceMappingURL=messagePublisher.js.map