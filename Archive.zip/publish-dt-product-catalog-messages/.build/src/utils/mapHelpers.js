"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApproximateCreationDateTime = exports.isPriceChanged = exports.isUpdated = void 0;
const UPDATE_EVENTS = ['INSERT', 'MODIFY'];
const PRICE_CHANGED_EVENTS = ['MODIFY', 'REMOVE'];
function isUpdated(record) {
    return UPDATE_EVENTS.includes(record.eventName);
}
exports.isUpdated = isUpdated;
function isPriceChanged(record) {
    var _a, _b;
    return (PRICE_CHANGED_EVENTS.includes(record.eventName) &&
        ((_a = record.dynamodb.NewImage) === null || _a === void 0 ? void 0 : _a.productId.S) !== ((_b = record.dynamodb.OldImage) === null || _b === void 0 ? void 0 : _b.productId.S));
}
exports.isPriceChanged = isPriceChanged;
function getApproximateCreationDateTime(record) {
    return new Date(record.dynamodb.ApproximateCreationDateTime * 1000).toISOString().replace('Z', '');
}
exports.getApproximateCreationDateTime = getApproximateCreationDateTime;
//# sourceMappingURL=mapHelpers.js.map