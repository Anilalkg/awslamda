import { NotImplementedArray, NotImplemented } from '../types';
import { Media } from "./product";
export declare type ProductUpdatedEventType = 'ProductUpdated';
export interface IProductUpdatedDataPoints {
    ProductId: string;
}
export interface IProductUpdatedFlags {
    isOnlyAtNM: NotImplemented;
    dynamicImageSkuColor: boolean;
    hasMoreColors: NotImplemented;
    isNewArrival: NotImplemented;
    isEditorial: boolean;
    isEvening: boolean;
    inLookBook: NotImplemented;
    showMonogramLabel: boolean;
    previewSupported: boolean;
}
export interface IProductUpdatedSizeLabel {
    sortOrder: NotImplemented;
    label: NotImplemented;
}
export interface IProductUpdatedHierarchy {
    level1: NotImplemented;
    level2: NotImplemented;
}
export interface IProductUpdatedTimestampInfo {
    ProductUpdated: string;
}
export interface IProductUpdated {
    eventType: ProductUpdatedEventType;
    batchId: string;
    id: string;
    childProductIds?: NotImplementedArray;
    parentGroupIds?: NotImplementedArray;
    relatedProducts?: NotImplementedArray;
    isGroup?: boolean;
    belongsToGroup?: boolean;
    displayAsGroupEligible?: NotImplemented;
    groupType?: NotImplemented;
    displayName?: string;
    descriptionTitle?: NotImplemented;
    shortDescription?: string;
    longDescription?: string;
    notes?: string;
    help?: NotImplemented;
    sizeGuide?: NotImplemented;
    cmosCatalogId?: string;
    cmosItem?: string;
    merchandiseType?: NotImplemented;
    catalogType?: NotImplemented;
    pimStyle?: string;
    departmentDesc?: string;
    classDesc?: string;
    designerName?: string;
    designerDescriptionTitle?: NotImplemented;
    designerDescription?: string;
    parentheticalCharge?: string;
    intlParentheticalAmount?: string;
    personalShopper?: boolean;
    exclusive?: boolean;
    preOrder?: boolean;
    displayable?: boolean;
    dynamicImageSkuColor?: boolean;
    canonicalUrl?: string;
    designerBoutiqueUrl?: NotImplemented;
    serviceLevelCodes?: string[];
    skuList?: NotImplementedArray;
    media?: Media;
    productFlags?: IProductUpdatedFlags;
    hideInternationally?: boolean;
    onSale?: boolean;
    suppressCheckout?: NotImplemented;
    aliPay?: boolean;
    parenthetical?: boolean;
    departmentCode?: string;
    commodeCode?: string;
    classCode?: string;
    metaInfo?: NotImplemented;
    codeSetType?: NotImplemented;
    sizeLabels?: NotImplementedArray<IProductUpdatedSizeLabel>;
    offline?: NotImplemented;
    originTimestampInfo?: IProductUpdatedTimestampInfo;
    dataPoints?: IProductUpdatedDataPoints;
    sellableDate?: string;
    liveTreeDate?: NotImplemented;
    adornDate?: string;
    isBvd?: boolean;
    genderCode?: string;
    restrictedStates?: string;
    restrictedCodes?: NotImplemented;
    hierarchy?: NotImplementedArray<IProductUpdatedHierarchy>;
    attributes?: NotImplementedArray;
    psAttributes?: any[];
}
