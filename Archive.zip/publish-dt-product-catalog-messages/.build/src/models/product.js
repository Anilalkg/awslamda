"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ItemGroup = exports.Components = exports.DataPoints = exports.FilterFacet = exports.OriginTimestampInfo = exports.ProductFlags = exports.Media = void 0;
class AttributeValue {
}
class Media {
}
exports.Media = Media;
class ProductFlags {
}
exports.ProductFlags = ProductFlags;
class OriginTimestampInfo {
}
exports.OriginTimestampInfo = OriginTimestampInfo;
class FilterFacet {
}
exports.FilterFacet = FilterFacet;
class DataPoints {
}
exports.DataPoints = DataPoints;
class Components {
}
exports.Components = Components;
class ItemGroup {
}
exports.ItemGroup = ItemGroup;
//# sourceMappingURL=product.js.map