import { NotImplemented } from '../types';
export declare type ProductDimensionsUpdatedEventType = 'PRODUCT_DIMENSIONS_UPDATED';
export interface IProductUpdatedDataPoints {
    ProductId: string;
}
export interface IProductUpdatedHierarchy {
    level1: NotImplemented;
    level2: NotImplemented;
}
export interface IProductUpdatedTimestampInfo {
    ProductUpdated: string;
}
export interface IProductDimensionsUpdated {
    eventType: ProductDimensionsUpdatedEventType;
    batchId: string;
    id: string;
    originTimestampInfo?: IProductUpdatedTimestampInfo;
    dataPoints?: IProductUpdatedDataPoints;
    psAttributes?: any[];
}
