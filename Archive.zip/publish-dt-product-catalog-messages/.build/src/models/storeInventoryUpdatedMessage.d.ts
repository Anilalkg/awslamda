export declare type StoreInventoryUpdatedEventType = 'SKU_STORES_INVENTORY_UPDATED';
export interface IStoreInventory {
    storeNo: string;
    storeId: string;
    locationNumber: string;
    bopsQty: number;
    qty: number;
    invLevel: bigint;
}
export interface IStoreSkuListData {
    SkuId: string;
}
export interface IStoreInventoryUpdatedDataPoints {
    StoreSkuListData: IStoreSkuListData[];
    ProductId: string;
}
export interface IStoreInventoryUpdatedSkuStore {
    skuId: string;
    storeInventories: IStoreInventory[];
}
export interface IStoreInventoryUpdated {
    eventType: StoreInventoryUpdatedEventType;
    batchId: string;
    id: string;
    skuStores: IStoreInventoryUpdatedSkuStore[];
    originTimestampInfo: {
        SKU_STORES_INVENTORY_UPDATED: string;
    };
    dataPoints: IStoreInventoryUpdatedDataPoints;
}
