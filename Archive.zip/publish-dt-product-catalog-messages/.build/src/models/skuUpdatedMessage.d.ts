import { NotImplemented } from '../types';
export declare type SkuUpdatedEventType = 'SkuUpdated';
export interface ISkuUpdatedSkuListDataPoints {
    Size: string;
    Color: string;
    Instock: boolean;
    Exclusive: boolean;
    DiscontinuedCode: NotImplemented;
    ProductId: string;
    POQty: number;
    SkuId: string;
    StockLevel: number;
}
export interface ISkuUpdatedDataPoints {
    ProductId: string;
    SkuListData: ISkuUpdatedSkuListDataPoints[];
}
export interface ISkuMedia {
    tag: string;
    url: string;
}
export interface ISkuUpdatedSkuList {
    id: NotImplemented;
    batchId: NotImplemented;
    sequenceNumber: number;
    productId: string;
    cmosSkuId: NotImplemented;
    pimSkuId: string;
    codeUpc: string;
    colorName: string;
    sizeName: string;
    stockLevel: number;
    inStock: boolean;
    bossTotal: NotImplemented;
    purchaseOrderQuantity: number;
    discontinuedCode: boolean;
    dropShip: boolean;
    shipFromStore: NotImplemented;
    colorKey: string;
    sizeKey: string;
    pimColorKey: string;
    pimSizeKey: string;
    depth: number;
    height: number;
    width: number;
    giftWrappableFlag: boolean;
    iceFlag: boolean;
    swatchPath: string;
    expectedShipDate: NotImplemented;
    deliveryDays: number;
    media: ISkuMedia[];
    defaultColor: boolean;
    useSkuAsset: boolean;
    displaySwatchImg: boolean;
    isPerishable: boolean;
    isNewColor: NotImplemented;
    vendorId: string;
    hexCode: string;
    suggestedInterval: number;
    styleId: NotImplemented;
    pimColorCode: string;
    pimSizeCode: string;
    colorFacet: string;
    exclusive: boolean;
    originTimestampInfo: {
        SkuUpdated: string;
    };
    fedexEligible: boolean;
    dataPoints: ISkuUpdatedSkuListDataPoints;
}
export interface ISkuUpdated {
    eventType: SkuUpdatedEventType;
    batchId: string;
    id: string;
    exclusive: boolean;
    skuList: ISkuUpdatedSkuList[];
    originTimestampInfo: {
        SkuUpdated: string;
    };
    dataPoints: ISkuUpdatedDataPoints;
}
