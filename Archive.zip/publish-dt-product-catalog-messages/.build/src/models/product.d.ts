import { NotImplemented, NotImplementedArray } from '../types';
import { IProductUpdatedHierarchy } from "./productUpdatedMessage";
export interface IProductDigitalAsset {
    mediaTag: string;
    mediaVersion: string;
    url: string;
}
export interface ITaxonomy {
    code: string;
    name: string;
}
export interface IDesigner {
    name: string;
    descriptionTitle: string;
    description: string;
}
export interface IFlags {
    isGroup: boolean;
    belongsToGroup: boolean;
    preOrder: boolean;
    allowBackOrders: boolean;
    blockOrders: boolean;
    dynamicImageSkuColor: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
    storeOnly: boolean;
    exclusive: boolean;
    inStock: boolean;
    useSkuAsset: boolean;
    giftWrappableFlag: boolean;
    perishableFlag: boolean;
    dropshipFlag: boolean;
    fedexEligibleFlag: boolean;
    onSale: boolean;
    parenthetical: boolean;
    isOnlyAtNM: NotImplemented;
    hasMoreColors: NotImplemented;
}
export interface IColor {
    name: string;
    pimKey: string;
    pimCode: string;
    facet: string;
    key: string;
    default: boolean;
}
export interface ISize {
    name: string;
    pimKey: string;
    pimCode: string;
    key: string;
}
export interface IInventory {
    status: string;
    purchaseOrderQty: number;
    qty: number;
    bossTotalQty: NotImplemented;
}
export interface IShipping {
    boxedDepthInches: number;
    boxedHeightInches: number;
    boxedWidthInches: number;
    deliveryDays: number;
    shipFromStore: NotImplemented;
    expectedShipDate: NotImplemented;
}
export interface IPrice {
    retail: number;
    original: number;
}
export interface IProductStoreInventory {
    storeId: string;
    storeNumber: string;
    locationNumber: string;
    quantity: number;
    bopsQuantity: number;
    invLevel: bigint;
}
export interface IProduct {
    PartitionKey: string;
    SortKey: string;
    skuNumber: string;
    skuSequenceNumber: number;
    displayItem: string;
    displayItemType: string;
    productId: string;
    price: IPrice;
    color: IColor;
    size: ISize;
    inventory: IInventory;
    digitalAssets: IProductDigitalAsset[];
    hexValue: string;
    swatchPath: string;
    shipping: IShipping;
    suggestedInterval: string;
    displayName: string;
    department: ITaxonomy;
    class: ITaxonomy;
    designer: IDesigner;
    serviceLevelCodes: string[];
    sellableDate: string;
    commodeCode: string;
    genderCode: string;
    flags: IFlags;
    shortDescription: string;
    longDescription: string;
    notes: string;
    cmosCatalogId: string;
    cmosItem: string;
    catalogType: NotImplemented;
    pimStyle: string;
    parentheticalCharge: string;
    intlParentheticalAmount: string;
    displayable: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl: NotImplemented;
    launchDate: string;
    adornDate: string;
    hideInternationally: boolean;
    suppressCheckout: NotImplemented;
    sizeLabels: NotImplementedArray;
    offline: NotImplemented;
    liveTreeDate: NotImplemented;
    restrictedStates: string;
    restrictedCodes: NotImplemented;
    cmosSkuId: NotImplemented;
    codeUpc: string;
    vendorId: string;
    discontinuedCode: boolean;
    iceFlag: boolean;
    storeInventories: IProductStoreInventory[];
    displayGroups?: string[];
    webProductIDs?: string[];
    psAttributes?: Record<string, AttributeValue[]>;
    webSkuId?: string;
    merchandiseType: string;
}
declare class AttributeValue {
    name?: string;
    code?: string;
}
export declare class Media {
    id: string;
    mediaTag: string;
    mediaVersion: string;
    url: string;
    productId: string;
    dynamicImageSkuColor: boolean;
}
export declare class ProductFlags {
    isOnlyAtNM: boolean;
    dynamicImageSkuColor: boolean;
    hasMoreColors: boolean;
    isNewArrival: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    inLookBook: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
}
export declare class OriginTimestampInfo {
    ProductUpdated: string;
}
export declare class FilterFacet {
    label: string;
    sortOrder: number;
}
export declare class DataPoints {
    ProductId: string;
}
export declare class Components {
    componentLevel: string;
    componentNumber: string;
    quantity?: number;
    componentSequence?: number;
    componentDepiction?: string;
    componentDepictionSequence?: number;
}
export declare class ItemGroup {
    PartitionKey: string;
    SortKey: string;
    childProductIds: string[];
    componentType: string;
    description: string;
    media: Media[];
    displayName: string;
    notes: string;
    help: string;
    sizeGuide: string;
    cmosCatalogId: string;
    cmosItem: string;
    merchandiseType: string;
    catalogType: string;
    pimStyle: string;
    departmentDesc: string;
    classDesc: string;
    designerName: string;
    designerDescriptionTitle: string;
    designerDescription: string;
    parentheticalCharge: number;
    intlParentheticalAmount: number;
    personalShopper: boolean;
    exclusive: boolean;
    preOrder: boolean;
    displayable: boolean;
    dynamicImageSkuColor: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl: string;
    serviceLevelCodes: string[];
    productFlags: ProductFlags;
    hideInternationally: boolean;
    onSale: boolean;
    suppressCheckout: boolean;
    aliPay: boolean;
    parenthetical: boolean;
    departmentCode: string;
    commodeCode: string;
    classCode: string;
    metaInfo: string;
    codeSetType: string;
    sizeLabels: FilterFacet[];
    offline: boolean;
    originTimestampInfo: OriginTimestampInfo;
    sellableDate: string;
    liveTreeDate: string;
    adornDate: string;
    isBvd: boolean;
    genderCode: string;
    restrictedStates: string;
    restrictedCodes: string;
    hierarchy: NotImplementedArray<IProductUpdatedHierarchy>;
    attributes: {
        [key: string]: string[];
    }[];
    dataPoints: DataPoints;
    components?: Components[];
}
export {};
