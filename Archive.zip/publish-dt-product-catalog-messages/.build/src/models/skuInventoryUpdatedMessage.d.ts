import { ISkuUpdatedDataPoints, ISkuMedia } from './skuUpdatedMessage';
import { NotImplemented } from '../types';
export declare type SkuInventoryUpdatedEventType = 'SkuInventoryUpdated';
export interface ISkuInventoryUpdated {
    eventType: SkuInventoryUpdatedEventType;
    batchId: string;
    id: string;
    exclusive: boolean;
    skuList: ISkuInventoryUpdatedSkuList[];
    originTimestampInfo: {
        SkuUpdated: string;
    };
    dataPoints: ISkuUpdatedDataPoints;
}
export interface ISkuInventoryUpdatedSkuList {
    id: string;
    batchId: string;
    productId: string;
    stockLevel: number;
    inStock: boolean;
    bossTotal: NotImplemented;
    purchaseOrderQuantity: number;
    discontinuedCode: boolean;
    expectedShipDate: NotImplemented;
    deliveryDays: number;
    useSkuAsset: boolean;
    exclusive: boolean;
    isPerishable: boolean;
    media: ISkuMedia[];
}
