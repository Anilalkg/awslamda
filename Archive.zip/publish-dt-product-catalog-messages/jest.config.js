module.exports = {
  setupFiles: ['<rootDir>/dotenv/config'],
  verbose: true,
  roots: ['<rootDir>'],
  transform: {
    '^.+\\.ts?$': 'ts-jest'
  },
  coveragePathIgnorePatterns: [
    '__test__',
    '<rootDir>/src/test/'
  ],
  moduleFileExtensions: ['ts', 'js', 'json', 'node'],
  collectCoverage: true,
  clearMocks: true,
  coverageDirectory: 'coverage',
  testMatch: ['**/__tests__/**/*.spec.[jt]s?(x)', '**/?(*.)+(spec|it|test).[jt]s?(x)']
};
