## DPPE - Publish DT Product Catalog Messages 
   
