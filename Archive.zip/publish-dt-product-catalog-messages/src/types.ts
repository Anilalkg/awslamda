import rabbit from 'amqplib'
import { AttributeValue } from 'aws-lambda'

export interface PublishToQueueConfig {
  queueName: string
  queueOptions?: rabbit.Options.AssertQueue
  publishOptions?: rabbit.Options.Publish
}

export interface PublishToExchangeConfig {
  exchangeName: string
  exchangeType: string
  exchangeOptions?: rabbit.Options.AssertExchange
  publishOptions?: rabbit.Options.Publish
}

export interface MessageMapperConfig {
  batchId: string
}

export interface RecordMapperConfig extends MessageMapperConfig {
  approximateCreationDateTime: string
}

export type StreamRecord = { [key: string]: AttributeValue }

export type NotImplementedArray<T = unknown> = T[]
export type NotImplemented<T = null | string | boolean> = T
export type NotImplementedObject<T = unknown> = Record<string, T>
