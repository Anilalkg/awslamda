// eslint-disable-next-line @typescript-eslint/no-var-requires
const { mockUnmarshalledStreamImage } = require('../test/testData')

module.exports = {
  DynamoDB: {
    Converter: {
      unmarshall: jest.fn().mockReturnValue(mockUnmarshalledStreamImage),
    },
  },
}
