module.exports = {
  error: jest.fn(),
  debug: jest.fn(),
  info: jest.fn(),
}
