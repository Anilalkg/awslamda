import {attribute, hashKey, rangeKey, table} from '@aws/dynamodb-data-mapper-annotations'
import { DataMapper, embed } from '@aws/dynamodb-data-mapper'
import { DynamoDB } from 'aws-sdk'
import { property } from '../utils/config'
import {IDesigner, IFlags, IProduct, IShipping, ITaxonomy} from '../models/product'

const mapper = new DataMapper({ client: new DynamoDB() })
const productsTableName = property('PRODUCTS_TABLE')


export class DigitalAsset {
  @attribute()
  mediaTag: string
  @attribute()
  mediaVersion: string
  @attribute()
  url: string
}

export class Taxonomy {
  @attribute()
  code: string
  @attribute()
  name: string
}

export class Designer {
  @attribute()
  name: string
  @attribute()
  descriptionTitle: string
  @attribute()
  description: string
}

export class Flags {
  @attribute()
  isGroup: boolean
  @attribute()
  belongsToGroup: boolean
  @attribute()
  preOrder: boolean
  @attribute()
  allowBackOrders: boolean
  @attribute()
  blockOrders: boolean
  @attribute()
  dynamicImageSkuColor: boolean
  @attribute()
  isEditorial: boolean
  @attribute()
  isEvening: boolean
  @attribute()
  showMonogramLabel: boolean
  @attribute()
  previewSupported: boolean
  @attribute()
  storeOnly: boolean
  @attribute()
  exclusive: boolean
  @attribute()
  inStock: boolean
  @attribute()
  useSkuAsset: boolean
  @attribute()
  giftWrappableFlag: boolean
  @attribute()
  perishableFlag: boolean
  @attribute()
  dropshipFlag: boolean
  @attribute()
  fedexEligibleFlag: boolean
  @attribute()
  parenthetical: boolean
  @attribute()
  isOnlyAtNM: string
  @attribute()
  hasMoreColors: string
  @attribute()
  onSale: boolean
}

export class Color {
  @attribute()
  key: string
  @attribute()
  name: string
  @attribute()
  pimKey: string
  @attribute()
  pimCode: string
  @attribute()
  facet: string
  @attribute()
  default: boolean
}

export class Size {
  @attribute()
  name: string
  @attribute()
  pimKey: string
  @attribute()
  pimCode: string
  @attribute()
  key: string
}

export class Inventory {
  @attribute()
  status: string
  @attribute()
  qty: number
  @attribute()
  purchaseOrderQty: number
  @attribute()
  bossTotalQty: number
}

export class Shipping {
  @attribute()
  boxedDepthInches: number
  @attribute()
  boxedHeightInches: number
  @attribute()
  boxedWidthInches: number
  @attribute()
  deliveryDays: number
  @attribute()
  shipFromStore?: string
  @attribute()
  expectedShipDate?: string
}

export class StoreInventory {
  @attribute()
  storeId: string
  @attribute()
  storeNumber: string
  @attribute()
  locationNumber: string
  @attribute()
  quantity: bigint
  @attribute()
  bopsQuantity: bigint
  @attribute()
  invLevel: bigint
}

export class Price {
  @attribute()
  retail: number
  @attribute()
  original: number
}

@table(productsTableName)
export class Product {
  @hashKey({ type: 'String' })
  PartitionKey: string
  @rangeKey()
  SortKey: string
  @attribute()
  skuNumber: string
  @attribute()
  skuSequenceNumber: number
  @attribute()
  displayItem: string
  @attribute()
  displayItemType: string
  @attribute()
  variationId: string
  @attribute()
  productId: string
  @attribute({ memberType: embed(Price) })
  price: Price
  @attribute({ memberType: embed(Color) })
  color: Color
  @attribute({ memberType: embed(Size) })
  size: Size
  @attribute({ memberType: embed(Inventory) })
  inventory: Inventory
  @attribute({ memberType: embed(DigitalAsset) })
  digitalAssets: DigitalAsset[]
  @attribute()
  hexValue: string
  @attribute()
  merchandiseType: string
  @attribute()
  swatchPath: string
  @attribute({ memberType: embed(Shipping) })
  shipping: IShipping
  @attribute()
  suggestedInterval: string
  @attribute()
  displayName: string
  @attribute({ memberType: embed(Taxonomy) })
  department: ITaxonomy
  @attribute({ memberType: embed(Taxonomy) })
  class: ITaxonomy
  @attribute({ memberType: embed(Taxonomy) })
  subclass?: ITaxonomy
  @attribute({ memberType: embed(Designer) })
  designer: IDesigner
  @attribute()
  serviceLevelCodes: string[]
  @attribute()
  sellableDate: string
  @attribute()
  adornDate: string
  @attribute()
  launchDate: string
  @attribute()
  commodeCode: string
  @attribute()
  genderCode: string
  @attribute({ memberType: embed(Flags) })
  flags: IFlags
  @attribute()
  shortDescription: string
  @attribute()
  longDescription: string
  @attribute()
  notes: string
  @attribute()
  cmosCatalogId: string
  @attribute()
  cmosItem: string
  @attribute()
  catalogType?: string
  @attribute()
  pimStyle: string
  @attribute()
  parentheticalCharge: string
  @attribute()
  intlParentheticalAmount: string
  @attribute()
  displayable?: boolean
  @attribute()
  canonicalUrl: string
  @attribute()
  designerBoutiqueUrl?: string
  @attribute()
  hideInternationally: boolean
  @attribute()
  suppressCheckout?: string
  @attribute()
  sizeLabels?: string
  @attribute()
  offline?: string
  @attribute()
  liveTreeDate?: string
  @attribute()
  restrictedStates: string
  @attribute()
  cmosSkuId?: string
  @attribute()
  codeUpc: string
  @attribute()
  discontinuedCode?: string
  @attribute()
  vendorId: string
  @attribute()
  iceFlag?: string
  @attribute({ memberType: embed(StoreInventory) })
  storeInventories: StoreInventory[]
  @attribute()
  onHandQty?: number
  @attribute()
  onOrderQty?: number
  @attribute()
  displayGroups?: string[]
  @attribute()
  webProductIDs?: string[]
  @attribute()
  attributes: any
  @attribute()
  psAttributes: any
  @attribute()
  componentsOf?: string[]
  @attribute()
  displayAsGroupEligible?: boolean
  @attribute()
  sizeGuide?: string
  @attribute()
  webSkuId: string
}

export const getDisplayItems = async  (product: IProduct): Promise<Product[]> => {
  const products: Product[] = [];
  // eslint-disable-next-line max-len
  // const iterator = mapper.query(Product,  {displayItem : `${product.displayItem}`} , { indexName: 'DisplayItemIndex'}  );
  const iterator = mapper.query(Product, { PartitionKey: `${product.PartitionKey}` } );
  for await (const record of iterator) {
    products.push(record);
  }

  return Promise.all(products);
}