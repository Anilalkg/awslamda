import {
  ISkuInventoryUpdated, ISkuInventoryUpdatedSkuList
} from '../../models/skuInventoryUpdatedMessage'
import {mapSkuListId, mapSkuListBatchId, mapDataPoints} from './skuUpdatedMapper'
import { IProduct } from '../../models/product'
import { RecordMapperConfig } from '../../types'

export function mapSkuInventoryUpdateData(productDoc: IProduct, config: RecordMapperConfig, productId: string): ISkuInventoryUpdated {

  return {
    eventType: 'SkuInventoryUpdated',
    batchId: config.batchId,
    id: productId,
    exclusive: productDoc.flags.exclusive,
    skuList: mapSkuInventoryUpdateSkuList(productDoc, productId),
    originTimestampInfo: {
      SkuUpdated: config.approximateCreationDateTime,
    },
    dataPoints: mapDataPoints(productDoc, productId),
  }
}

export function mapSkuInventoryUpdateSkuList(productDoc: IProduct, productId: string): ISkuInventoryUpdatedSkuList[] {
  return [
    {
      id: mapSkuListId(productDoc),
      batchId: mapSkuListBatchId(),
      productId,
      stockLevel: productDoc.inventory.qty,
      inStock: productDoc.inventory.onHandStatus === 'AVAILABLE' && productDoc.inventory.qty > 0,
      bossTotal: productDoc.inventory.bossTotalQty,
      purchaseOrderQuantity: productDoc.inventory.purchaseOrderQty,
      discontinuedCode: productDoc.discontinuedCode,
      expectedShipDate: productDoc.shipping.expectedShipDate,
      deliveryDays: productDoc.shipping.deliveryDays,
      useSkuAsset: productDoc.flags.useSkuAsset,
      exclusive: productDoc.flags.exclusive,
      isPerishable: productDoc.flags.perishableFlag,
      media: null,
    },
  ]
}
