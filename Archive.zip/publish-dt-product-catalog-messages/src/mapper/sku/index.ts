import { DynamoDBStreamEvent } from 'aws-lambda'
import { DynamoDB } from 'aws-sdk'
import { ISkuUpdated } from '../../models/skuUpdatedMessage'
import { IProduct } from '../../models/product'
import { ISkuInventoryUpdated } from '../../models/skuInventoryUpdatedMessage'
import { MessageMapperConfig } from '../../types'
import { isUpdated, isPriceChanged, getApproximateCreationDateTime } from '../../utils/mapHelpers'
import { mapSkuUpdateData } from './skuUpdatedMapper'
import { mapSkuInventoryUpdateData } from './skuInventoryUpdatedMapper'
import { mapPriceChangedSkuUpdate } from './skuPriceChangedMapper'

export function mapSkuUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): ISkuUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }
    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        for (const webProductId of productDoc.webProductIDs){   
          mappedRecords.push(mapSkuUpdateData(productDoc, recordConfig, webProductId))
        }
      }
    }

    /*
    if (isPriceChanged(record)) {
      const mappedOldSkuUpdate = mapSkuUpdateData(record.dynamodb.OldImage, recordConfig)
      mappedRecords.push(mapPriceChangedSkuUpdate(mappedOldSkuUpdate))
    }
    */
    return mappedRecords
  }, [] as ISkuUpdated[])
}

export function mapSkuInventoryUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): ISkuInventoryUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }
    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        for (const webProductId of productDoc.webProductIDs){   
          mappedRecords.push(mapSkuInventoryUpdateData(productDoc, recordConfig, webProductId))
        }
      }
    }

    return mappedRecords
  }, [] as ISkuInventoryUpdated[])
}
