import {
  ISkuUpdatedSkuList,
  ISkuUpdated,
  ISkuUpdatedSkuListDataPoints,
  ISkuUpdatedDataPoints,
} from '../../models/skuUpdatedMessage'

export function mapPriceChangedSkuUpdate(skuUpdatedMessage: ISkuUpdated): ISkuUpdated {
  return {
    ...skuUpdatedMessage,
    skuList: mapPriceChangedSkuUpdateSkuList(skuUpdatedMessage.skuList),
    dataPoints: mapPriceChangeSkuUpdateDataPoints(skuUpdatedMessage.dataPoints),
  }
}

export function mapPriceChangedSkuUpdateSkuList(skuList: ISkuUpdatedSkuList[]): ISkuUpdatedSkuList[] {
  return skuList.map((skuItem) => ({
    ...skuItem,
    // discontinuedCode: 'V',
    dataPoints: mapPriceChangedSkuUpdateListDataPoints(skuItem.dataPoints),
  }))
}

export function mapPriceChangedSkuUpdateListDataPoints(
  dataPoints: ISkuUpdatedSkuListDataPoints,
): ISkuUpdatedSkuListDataPoints {
  return {
    ...dataPoints,
    DiscontinuedCode: 'V',
  }
}

export function mapPriceChangeSkuUpdateDataPoints(dataPoints: ISkuUpdatedDataPoints): ISkuUpdatedDataPoints {
  return {
    ...dataPoints,
    SkuListData: dataPoints.SkuListData.map((skuListItem) => mapPriceChangedSkuUpdateListDataPoints(skuListItem)),
  }
}
