import { DynamoDB } from 'aws-sdk'
import {
  ISkuUpdatedSkuList,
  ISkuUpdated,
  ISkuUpdatedSkuListDataPoints,
  ISkuUpdatedDataPoints,
  ISkuMedia,
} from '../../models/skuUpdatedMessage'
import { IProduct } from '../../models/product'
import { RecordMapperConfig } from '../../types'

export function mapSkuUpdateData(productDoc: IProduct, config: RecordMapperConfig, productId: string): ISkuUpdated {

  return {
    eventType: 'SkuUpdated',
    batchId: config.batchId,
    id: productId,
    exclusive: productDoc.flags.exclusive,
    skuList: mapSkuUpdateSkuList(productDoc, config, productId),
    originTimestampInfo: {
      SkuUpdated: config.approximateCreationDateTime,
    },
    dataPoints: mapDataPoints(productDoc, productId),
  }
}

export function mapSkuUpdateSkuList(productDoc: IProduct, config: RecordMapperConfig, productId: string): ISkuUpdatedSkuList[] {
  return [
    {
      id: mapSkuListId(productDoc),
      batchId: mapSkuListBatchId(),
      sequenceNumber: productDoc.skuSequenceNumber,
      productId,
      cmosSkuId: productDoc.cmosSkuId,
      pimSkuId: productDoc.skuNumber,
      codeUpc: productDoc.codeUpc,
      colorName: productDoc.color.name,
      sizeName: productDoc.size.name,
      stockLevel: productDoc.inventory.qty,
      inStock: productDoc.inventory.status === 'AVAILABLE' && productDoc.inventory.qty > 0,
      bossTotal: productDoc.inventory.bossTotalQty,
      purchaseOrderQuantity: productDoc.inventory.purchaseOrderQty,
      discontinuedCode: productDoc.discontinuedCode,
      dropShip: productDoc.flags.dropshipFlag,
      shipFromStore: productDoc.shipping.shipFromStore,
      colorKey: productDoc.color.key,
      sizeKey: productDoc.size.key,
      pimColorKey: productDoc.color.pimKey,
      pimSizeKey: productDoc.size.pimKey,
      depth: productDoc.shipping.boxedDepthInches,
      height: productDoc.shipping.boxedHeightInches,
      width: productDoc.shipping.boxedWidthInches,
      giftWrappableFlag: productDoc.flags.giftWrappableFlag,
      iceFlag: productDoc.iceFlag,
      swatchPath: productDoc.swatchPath,
      expectedShipDate: productDoc.shipping.expectedShipDate,
      deliveryDays: productDoc.shipping.deliveryDays,
      media: mapSkuListMedia(productDoc),
      defaultColor: productDoc.color.default,
      useSkuAsset: productDoc.flags.useSkuAsset,
      displaySwatchImg: productDoc.swatchPath !== null,
      isPerishable: productDoc.flags.perishableFlag,
      isNewColor: false,
      vendorId: productDoc.vendorId,
      hexCode: productDoc.hexValue,
      suggestedInterval: Number(productDoc.suggestedInterval),
      styleId: mapSkuListStyleId(),
      pimColorCode: productDoc.color.pimCode,
      pimSizeCode: productDoc.size.pimCode,
      colorFacet: mapColorFacet(productDoc?.color?.facet),
      exclusive: productDoc.flags.exclusive,
      originTimestampInfo: {
        SkuUpdated: config.approximateCreationDateTime,
      },
      fedexEligible: productDoc.flags.fedexEligibleFlag,
      dataPoints: mapSkuListDataPoints(productDoc, productId),
    },
  ]
}

export const mapColorFacet = (facets: string | string[]): string => {

  // TODO This method needs to return a string array once the consumers are ready to accept Object instead of string
  if(Array.isArray(facets)) {
    if(facets && facets.length >0){
      return facets[0]
    }
    return "";
  } 
  return facets;

}

export const mapSkuListId = (productDoc: IProduct): string => productDoc.webSkuId
export const mapSkuListBatchId = (): null => null
export const mapSkuListCmosSkuId = (): null => null
export const mapSkuListDiscontinuedCode = (productDoc: IProduct): boolean => productDoc.discontinuedCode
export const mapSkuListMedia = (productDoc: IProduct): ISkuMedia[] => {
  return (
    productDoc.digitalAssets?.map((digitalAsset) => ({
      tag: digitalAsset.mediaTag,
      url: digitalAsset.url,
    })) || []
  )
}
export const mapSkuListIsNewColor = (): null => null
export const mapSkuListStyleId = (): null => null
export const mapSkuListDataPoints = (productDoc: IProduct, productId: string): ISkuUpdatedSkuListDataPoints => ({
  Size: productDoc.size.name,
  Color: productDoc.color.name,
  Instock: productDoc.inventory.status === 'AVAILABLE' && productDoc.inventory.qty > 0,
  Exclusive: productDoc.flags.exclusive,
  DiscontinuedCode: mapSkuListDiscontinuedCode(productDoc),
  ProductId: productId,
  POQty: productDoc.inventory.purchaseOrderQty,
  SkuId: mapSkuListId(productDoc),
  StockLevel: productDoc.inventory.qty,
})
export const mapDataPoints = (productDoc: IProduct, productId: string): ISkuUpdatedDataPoints => ({
  ProductId: productId,
  SkuListData: [mapSkuListDataPoints(productDoc, productId)],
})
