import { IProduct } from '../../models/product'
import { RecordMapperConfig } from '../../types'
import { mapPsAttributes, mapProductUpdatedDataPoints } from './productUpdatedMapper'
import { IProductDimensionsUpdated } from '../../models/productDimensionsUpdatedMessage'

export function mapProductDimensionUpdateData(productDoc: IProduct, config: RecordMapperConfig, productId: string): IProductDimensionsUpdated {
  // const productDoc = DynamoDB.Converter.unmarshall(streamRecord) as IProduct
  return {
    eventType: 'PRODUCT_DIMENSIONS_UPDATED',
    batchId: config.batchId,
    id: productId,
    dataPoints: mapProductUpdatedDataPoints(productId),
    psAttributes: mapPsAttributes(productDoc),
    cm4Hierarchy: productDoc.psHierarchy
  }
}