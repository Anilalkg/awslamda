import { IProductUpdated } from '../../models/productUpdatedMessage'

export function mapPriceChangedProductUpdate(productUpdatedMessage: IProductUpdated): IProductUpdated {
  return {
    ...productUpdatedMessage,
    displayable: false,
    offline: true,
  }
}
