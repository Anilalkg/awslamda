import { DynamoDB } from 'aws-sdk'
import logger from '@nmg/oco-backend-utils/logger'
import {IProduct, ItemGroup, Media} from '../../models/product'
import {getDisplayItems, Product} from "../../storage/dynamoMessages";
import {
  IProductUpdatedHierarchy,
  IProductUpdated,
  IProductUpdatedTimestampInfo,
  IProductUpdatedDataPoints,
} from '../../models/productUpdatedMessage'
import { RecordMapperConfig, StreamRecord } from '../../types'

// eslint-disable-next-line max-len
export async function mapProductUpdateData(productDoc: IProduct, config: RecordMapperConfig, productId : string): Promise<IProductUpdated> {

  // const productDoc = DynamoDB.Converter.unmarshall(streamRecord) as IProduct

  return {
    eventType: 'ProductUpdated',
    batchId: config.batchId,
    id: productId,
    childProductIds: mapChildProductIds(),
    parentGroupIds: mapParentGroupIds(productDoc),
    relatedProducts: mapRelatedProducts(),
    isGroup: productDoc.flags.isGroup === null ? false : productDoc.flags.isGroup ,
    belongsToGroup: productDoc.flags.belongsToGroup  === null ? false : productDoc.flags.belongsToGroup,
    displayAsGroupEligible: productDoc?.displayAsGroupEligible  === null ? false : productDoc?.displayAsGroupEligible,
    groupType: mapGroupType(),
    displayName: productDoc.displayName,
    descriptionTitle: mapDescriptionTitle(),
    shortDescription: productDoc.shortDescription,
    longDescription: productDoc.longDescription,
    notes: productDoc.notes,
    help: mapHelp(),
    sizeGuide: productDoc.sizeGuide,
    cmosCatalogId: productDoc.cmosCatalogId,
    cmosItem: productDoc.cmosItem,
    merchandiseType: productDoc.merchandiseType,
    catalogType: productDoc.catalogType,
    pimStyle: productDoc.pimStyle,
    departmentDesc: productDoc.department.name,
    classDesc: productDoc.class.name,
    designerName: productDoc.designer.name,
    designerDescriptionTitle: mapDesignerDescriptionTitle(),
    designerDescription: productDoc.designer.description,
    parentheticalCharge: productDoc.parentheticalCharge,
    intlParentheticalAmount: productDoc.intlParentheticalAmount,
    personalShopper: false,
    exclusive: productDoc.flags.exclusive === null ? false : productDoc.flags.exclusive ,
    preOrder: productDoc.flags.preOrder === null ? false :  productDoc.flags.preOrder,
    displayable: await mapDisplayable(productDoc),
    dynamicImageSkuColor: productDoc.flags.dynamicImageSkuColor,
    canonicalUrl: productDoc.canonicalUrl,
    designerBoutiqueUrl: productDoc.designerBoutiqueUrl,
    serviceLevelCodes: productDoc.serviceLevelCodes,
    skuList: mapSkuList(),
    media: mapMedia(),
    productFlags: {
      isOnlyAtNM: productDoc.flags.exclusive === null ? false : productDoc.flags.exclusive,
      dynamicImageSkuColor: productDoc.flags.dynamicImageSkuColor === null ? false : productDoc.flags.dynamicImageSkuColor,
      hasMoreColors: productDoc.flags.hasMoreColors  === null ? false : productDoc.flags.hasMoreColors ,
      isNewArrival: mapProductFlagIsNewArrival(),
      isEditorial: productDoc.flags.isEditorial === null ? false : productDoc.flags.isEditorial,
      isEvening: productDoc.flags.isEvening === null ? false : productDoc.flags.isEvening,
      inLookBook: false,
      showMonogramLabel: productDoc.flags.showMonogramLabel === null ? false : productDoc.flags.showMonogramLabel ,
      previewSupported: productDoc.flags.previewSupported === null ? false : productDoc.flags.previewSupported,
    },
    hideInternationally: productDoc.hideInternationally,
    onSale: productDoc.flags.onSale === null ? false : productDoc.flags.onSale,
    suppressCheckout: productDoc.suppressCheckout,
    aliPay: false,
    parenthetical: productDoc.flags.parenthetical,
    departmentCode: productDoc.department.code,
    commodeCode: productDoc.commodeCode,
    classCode: productDoc.class.code,
    metaInfo: mapMetaInfo(),
    codeSetType: mapCodeSetType(),
    sizeLabels: productDoc.sizeLabels,
    offline: productDoc.offline,
    originTimestampInfo: mapProductUpdatedTimestampInfo(config.approximateCreationDateTime),
    sellableDate: mapSellableDate(productDoc),
    liveTreeDate: productDoc.liveTreeDate,
    adornDate: productDoc.adornDate,
    isBvd: productDoc.flags.storeOnly,
    genderCode: productDoc.genderCode,
    restrictedStates: productDoc.restrictedStates,
    dataPoints: mapProductUpdatedDataPoints(productId),
    // TODO
    restrictedCodes: '',
    psAttributes: mapPsAttributes(productDoc),
    cm4Hierarchy: productDoc.psHierarchy
  }
}

export function mapItemGroupUpdateData(streamRecord: StreamRecord, config: RecordMapperConfig): IProductUpdated {
  const itemGroupDoc = DynamoDB.Converter.unmarshall(streamRecord) as ItemGroup

  return {
    eventType: 'ProductUpdated',
    batchId: config.batchId,
    id: itemGroupDoc.productId,
    childProductIds: itemGroupDoc.childProductIds,
    parentGroupIds: null,
    isGroup: true,
    belongsToGroup: false,
    displayAsGroupEligible: mapDisplayAsGroupEligible(),
    groupType: mapGroupType(),
    displayName: itemGroupDoc.displayName,
    descriptionTitle: mapDescriptionTitle(),
    shortDescription: itemGroupDoc.description,
    longDescription: itemGroupDoc.description,
    notes: itemGroupDoc.notes,
    help: itemGroupDoc.help,
    sizeGuide: itemGroupDoc.sizeGuide,
    cmosCatalogId: itemGroupDoc.cmosCatalogId,
    cmosItem: itemGroupDoc.cmosItem,
    merchandiseType: itemGroupDoc.merchandiseType,
    catalogType: itemGroupDoc.catalogType,
    pimStyle: itemGroupDoc.pimStyle,
    departmentDesc: itemGroupDoc.departmentDesc,
    classDesc: itemGroupDoc.classDesc,
    designerName: itemGroupDoc.designerName,
    designerDescriptionTitle: itemGroupDoc.designerDescriptionTitle,
    designerDescription: itemGroupDoc.designerDescription,
    parentheticalCharge: itemGroupDoc.parentheticalCharge.toString(),
    intlParentheticalAmount: itemGroupDoc.intlParentheticalAmount.toString(),
    personalShopper: false,
    exclusive: itemGroupDoc.exclusive,
    preOrder: itemGroupDoc.preOrder,
    displayable: itemGroupDoc.displayable,
    dynamicImageSkuColor: itemGroupDoc.dynamicImageSkuColor,
    canonicalUrl: itemGroupDoc.canonicalUrl,
    designerBoutiqueUrl: itemGroupDoc.designerBoutiqueUrl,
    serviceLevelCodes: itemGroupDoc.serviceLevelCodes,
    skuList: [],
    media: mapMedia(),
    productFlags: itemGroupDoc.productFlags,
    hideInternationally: itemGroupDoc.hideInternationally,
    onSale: itemGroupDoc.onSale,
    suppressCheckout: itemGroupDoc.suppressCheckout,
    aliPay: false,
    parenthetical: itemGroupDoc.parenthetical,
    departmentCode: itemGroupDoc.departmentCode,
    commodeCode: itemGroupDoc.commodeCode,
    classCode: itemGroupDoc.classCode,
    metaInfo: itemGroupDoc.metaInfo,
    codeSetType: itemGroupDoc.codeSetType,
    // @ts-expect-error unknown types
    sizeLabels: itemGroupDoc.sizeLabels,
    offline: itemGroupDoc.offline,
    originTimestampInfo: itemGroupDoc.originTimestampInfo,
    sellableDate: itemGroupDoc.sellableDate,
    liveTreeDate: itemGroupDoc.liveTreeDate,
    adornDate: itemGroupDoc.adornDate,
    isBvd: itemGroupDoc.isBvd,
    genderCode: itemGroupDoc.genderCode,
    restrictedStates: itemGroupDoc.restrictedStates,
  }
}

const mapDisplayable = async (product: IProduct): Promise<boolean> => {
  if(product?.displayable){
    return true;
  }
  const products: Product[] = await getDisplayItems(product);
  for(const product of products){
    if(product?.displayable){
      logger.debug({ productDisplayable: 'Product is displayable', product: product.productId, skuNum: product.skuNumber })
      return true;
    }
  }
  logger.debug({ productDisplayable: 'All skus are out of stock, so not displayable', product: product.productId })
  return false;
}

const mapSellableDate = (productDoc: IProduct): string => {
  return productDoc.sellableDate ? new Date(productDoc.sellableDate).toISOString().replace('Z', '') : null
}

export const mapProductUpdatedTimestampInfo = (productUpdated: string): IProductUpdatedTimestampInfo => ({
  ProductUpdated: productUpdated,
})

export const mapProductUpdatedDataPoints = (productId: string): IProductUpdatedDataPoints => ({
  ProductId: productId,
})

export const mapParentGroupIds = (productDoc: IProduct): string[] => {
  return productDoc?.displayGroups;
}

export const mapPsAttributes = (productDoc: IProduct): any[] => {
  const psAttributes: any[] = [];
  const psa: Record<string,string[]> = {}
  if(productDoc?.psAttributes){
    Object.entries(productDoc?.psAttributes).forEach(([key, value]) => {
      psa[key] = value.map  (item => item);
    });
    psAttributes.push(psa);  
  }  
  return psAttributes;
}


export const mapChildProductIds = (): unknown[] => []
export const mapRelatedProducts = (): unknown[] => []
export const mapDisplayAsGroupEligible = (): null => null
export const mapGroupType = (): null => null
export const mapDescriptionTitle = (): null => null
export const mapHelp = (): null => null
export const mapSizeGuide = (): null => null
export const mapMerchandiseType = (): null => null
export const mapDesignerDescriptionTitle = (): null => null
export const mapSkuList = (): unknown[] => []
export const mapMedia = (): Media => (new Media())
export const mapProductFlagIsNewArrival = (): null => null
export const mapProductFlagInLookBook = (): null => null
export const mapMetaInfo = (): null => null
export const mapCodeSetType = (): null => null
// TODO needs logic to map attributs and hirearchy once we see data from catman 4
export const mapHierarchy = (): IProductUpdatedHierarchy[] => []
export const mapAttributes = (): unknown[] => []
