import { DynamoDB } from 'aws-sdk'
import { DynamoDBStreamEvent } from 'aws-lambda'
import logger from "@nmg/oco-backend-utils/logger";
import { IProductUpdated } from '../../models/productUpdatedMessage'
import { IProduct } from '../../models/product'
import { IProductDimensionsUpdated } from '../../models/productDimensionsUpdatedMessage'
import { MessageMapperConfig } from '../../types'
import { getApproximateCreationDateTime, isPriceChanged, isUpdated } from '../../utils/mapHelpers'
import { mapPriceChangedProductUpdate } from './productPriceChangedMapper'
import { mapItemGroupUpdateData, mapProductUpdateData } from './productUpdatedMapper'
import { mapProductDimensionUpdateData  } from './productDimensionUpdateMapper'

// eslint-disable-next-line max-len
export async function mapProductUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): Promise<IProductUpdated[]> {
  const mappedRecords: IProductUpdated[] = [];
  for(const record of event.Records){
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }

    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct 

      logger.info ({webproductids : productDoc.webProductIDs});

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        if(productDoc.webProductIDs.length > 1){
          logger.debug ({multipleWebProductIds : "found more than one webproductids for style ", style : productDoc.PartitionKey});
        }

        for (const webProductId of productDoc.webProductIDs){   
          logger.info ({productId : webProductId});       
          mappedRecords.push(await mapProductUpdateData(productDoc, recordConfig, webProductId))
        }
      } else {
        logger.warn ({missingWebProductId : "web product id is missing" , style : productDoc.PartitionKey})
      }
    }
    /*
    if (isPriceChanged(record)) {
      const oldProductDoc = DynamoDB.Converter.unmarshall(record.dynamodb.OldImage) as IProduct

      const mappedOldProductUpdate = await mapProductUpdateData(oldProductDoc, recordConfig)
      mappedRecords.push(mapPriceChangedProductUpdate(mappedOldProductUpdate))
    }
    */
  }
  return mappedRecords;
}


// eslint-disable-next-line max-len
export function mapProductDimensionsUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IProductDimensionsUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }

    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct
      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        if(productDoc.webProductIDs.length > 1){
          logger.debug ({multipleWebProductIds : "found more than one webproductids for style ", style : productDoc.PartitionKey});
        }

        for (const webProductId of productDoc.webProductIDs){   
          if(webProductId){
            mappedRecords.push(mapProductDimensionUpdateData(productDoc, recordConfig, webProductId))
          }
        }
      } else {
        logger.warn ({missingWebProductId : "web product id is missing" , style : productDoc.PartitionKey})
      }
    }

    return mappedRecords
  }, [] as IProductDimensionsUpdated[])
}


export function mapItemGroupUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IProductUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }

    if (isUpdated(record)) {
      mappedRecords.push(mapItemGroupUpdateData(record.dynamodb.NewImage, recordConfig))
    }

    return mappedRecords
  }, [] as IProductUpdated[])
}
