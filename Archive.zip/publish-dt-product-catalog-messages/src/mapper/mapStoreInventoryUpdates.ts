import { DynamoDBStreamEvent, DynamoDBRecord } from 'aws-lambda'
import { DynamoDB } from 'aws-sdk'
import { IProduct } from '../models/product'
import {
  IStoreInventoryUpdated,
  IStoreInventoryUpdatedSkuStore,
  IStoreSkuListData, IStoreInventory
} from '../models/storeInventoryUpdatedMessage'
import { IProductStoreInventory } from '../models/product'
import { MessageMapperConfig, RecordMapperConfig } from '../types'
import { isUpdated, getApproximateCreationDateTime } from '../utils/mapHelpers'

/*
export function mapStoreInventoryUpdates(
  event: DynamoDBStreamEvent,
  config: MessageMapperConfig,
): IStoreInventoryUpdated[] {
  return event.Records.filter((record) => record.eventName === 'INSERT' || record.eventName === 'MODIFY').map(
    (record) => mapStoreInventoryUpdateData(record, config),
  )
}
*/


export function mapStoreInventoryUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IStoreInventoryUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }
    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        for (const webProductId of productDoc.webProductIDs){   
          mappedRecords.push(mapStoreInventoryUpdateData(productDoc, recordConfig, webProductId))
        }
      }
    }

    return mappedRecords
  }, [] as IStoreInventoryUpdated[])
}

export function mapStoreInventoryUpdateData(
  productDoc: IProduct,
  config: RecordMapperConfig,
  productId: string
): IStoreInventoryUpdated {
  

  return {
    eventType: 'SKU_STORES_INVENTORY_UPDATED',
    batchId: config.batchId,
    id: productId,
    skuStores: mapSkuStores(productDoc.storeInventories, productDoc.webSkuId),
    originTimestampInfo: {
      SKU_STORES_INVENTORY_UPDATED: config.approximateCreationDateTime,
    },
    dataPoints: {
      StoreSkuListData: mapDataPointsStoreSkuListData(productDoc.webSkuId),
      ProductId: productId,
    },
  }
}

export const mapSkuStores = (sourceStoreInvList: IProductStoreInventory[], skuNumber:string): IStoreInventoryUpdatedSkuStore[] => {

  const locationList:IStoreInventoryUpdatedSkuStore[] = [];

  if(sourceStoreInvList && sourceStoreInvList.length){
     const location:IStoreInventoryUpdatedSkuStore = <IStoreInventoryUpdatedSkuStore>{};
     location.skuId = skuNumber;
     
     const storeInventories: IStoreInventory []= [];
     for(const sourceStoreInv of sourceStoreInvList){
       const destStoreInv: IStoreInventory = <IStoreInventory> {} ;
       destStoreInv.bopsQty = sourceStoreInv?.bopsQuantity;
       destStoreInv.locationNumber = sourceStoreInv?.locationNumber;
       destStoreInv.qty = sourceStoreInv?.quantity;
       destStoreInv.storeId = sourceStoreInv?.storeId;
       destStoreInv.storeNo = sourceStoreInv?.storeNumber;
       destStoreInv.invLevel = sourceStoreInv?.invLevel;
       storeInventories.push(destStoreInv);
     }
    
     location.storeInventories = storeInventories;
     locationList.push (location);
  }
  return locationList;
}
export const mapDataPointsStoreSkuListData = (skuNumber: string): IStoreSkuListData[] => {
  const storeSkuListData:IStoreSkuListData[] = [];
  const storeSkuData: IStoreSkuListData = <IStoreSkuListData> {}
  storeSkuData.SkuId = skuNumber;
  storeSkuListData.push(storeSkuData);
  return storeSkuListData;
}
