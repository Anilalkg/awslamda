import { buildDynamoDBEvent, buildDynamoDBRecord } from '../../test/testData'
import {
  mapStoreInventoryUpdates,
  mapStoreInventoryUpdateData,
  mapSkuStores,
  mapDataPointsStoreSkuListData,
} from '../mapStoreInventoryUpdates'

const mockConfig = {
  batchId: 'Auto-testId',
}

describe('mediaUpdatedMapper', () => {
  beforeAll(() => {
    jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('1')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  describe('mapMediaUpdates', () => {
    it('returns the mapped record for every record that has INSERT or MODIFY eventName', () => {
      expect(mapStoreInventoryUpdates(buildDynamoDBEvent('INSERT'), mockConfig)).toHaveLength(1)
      expect(mapStoreInventoryUpdates(buildDynamoDBEvent('MODIFY'), mockConfig)).toHaveLength(1)
      expect(mapStoreInventoryUpdates(buildDynamoDBEvent('REMOVE'), mockConfig)).toHaveLength(0)
    })
  })

  describe('mapStoreInventoryUpdateData', () => {
    it('returns the mapped message', () => {
      const result = mapStoreInventoryUpdateData(buildDynamoDBRecord('INSERT'), mockConfig)
      expect(result.eventType).toBe('SKU_STORES_INVENTORY_UPDATED')
      expect(result.batchId).toBe(mockConfig.batchId)
      expect(result.id).toBe('2891137#0')
      expect(result.skuStores).toEqual([])
      expect(result.originTimestampInfo).toEqual({
        SKU_STORES_INVENTORY_UPDATED: '1',
      })
      expect(result.dataPoints).toEqual({
        StoreSkuListData: [],
        ProductId: '2891137#0',
      })
    })
  })

  describe('mapSkuStores', () => {
    it('returns an empty array', () => {
      expect(mapSkuStores()).toEqual([])
    })
  })

  describe('mapDataPointsStoreSkuListData', () => {
    it('returns an empty array', () => {
      expect(mapDataPointsStoreSkuListData()).toEqual([])
    })
  })
})
