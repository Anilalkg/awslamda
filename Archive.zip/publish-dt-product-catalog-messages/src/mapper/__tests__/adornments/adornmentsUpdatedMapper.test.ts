/* eslint-disable max-len */
import { buildStreamImage } from '../../../test/testData'
import { mapAdornmentsUpdatedData } from '../../adornments/adornmentsUpdatedMapper'

const mockRecordConfig = {
  batchId: 'Auto-testId',
  approximateCreationDateTime: '1',
}

describe('mediaUpdatedMapper', () => {
  it('matches snapshot', () => {
    expect(mapAdornmentsUpdatedData(buildStreamImage(), mockRecordConfig)).toMatchInlineSnapshot(`
      Object {
        "batchId": "Auto-testId",
        "dataPoints": Object {
          "MaxAdornmentPrice": null,
          "RetailPrice": 0,
        },
        "eventType": "AdornmentsUpdated",
        "id": "2891137#0",
        "originTimestampInfo": Object {
          "AdornmentsUpdated": "1",
        },
        "priceAdornments": Array [],
        "retailPrice": 0,
      }
    `)
  })
})
