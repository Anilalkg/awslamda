/* eslint-disable max-len */
import { buildStreamImage } from '../../../test/testData'
import { mapProductUpdateData } from '../../product/productUpdatedMapper'

const mockRecordConfig = {
  batchId: 'Auto-testId',
  approximateCreationDateTime: '1',
}

describe('mediaUpdatedMapper', () => {
  beforeAll(() => {
    jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('1')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  it('matches snapshot', () => {
    expect(mapProductUpdateData(buildStreamImage(), mockRecordConfig)).toMatchInlineSnapshot(`
      Object {
        "adornDate": null,
        "aliPay": false,
        "attributes": Array [],
        "batchId": "Auto-testId",
        "belongsToGroup": false,
        "canonicalUrl": "/p/Designers Guild-Rivoli Decorative Pillow-2891137#0",
        "catalogType": null,
        "childProductIds": Array [],
        "classCode": "21-202-2009-648",
        "classDesc": "Pillows ",
        "cmosCatalogId": null,
        "cmosItem": "HBY4X",
        "codeSetType": null,
        "commodeCode": "76256",
        "departmentCode": "21-202-2009",
        "departmentDesc": "Decorative I",
        "descriptionTitle": null,
        "designerBoutiqueUrl": null,
        "designerDescription": null,
        "designerDescriptionTitle": null,
        "designerName": "Designers Guild",
        "displayAsGroupEligible": null,
        "displayName": "Rivoli Decorative Pillow",
        "displayable": false,
        "dynamicImageSkuColor": true,
        "eventType": "ProductUpdated",
        "exclusive": null,
        "genderCode": "Unisex",
        "groupType": null,
        "help": null,
        "hideInternationally": false,
        "hierarchy": Array [],
        "id": "2891137#0",
        "intlParentheticalAmount": null,
        "isBvd": null,
        "isGroup": false,
        "liveTreeDate": null,
        "longDescription": "<ul><li>Viscose velvet pillow.</li><li>Reverse: linen/cotton. </li><li>12\\" x 20\\". </li><li>Dry clean.</li><li>Imported.</li></ul>",
        "media": Object {},
        "merchandiseType": null,
        "metaInfo": null,
        "notes": null,
        "offline": null,
        "onSale": false,
        "originTimestampInfo": Object {
          "ProductUpdated": "1",
        },
        "parentGroupIds": Array [],
        "parenthetical": false,
        "parentheticalCharge": null,
        "personalShopper": false,
        "pimStyle": "2891137",
        "preOrder": null,
        "productFlags": Object {
          "dynamicImageSkuColor": true,
          "hasMoreColors": null,
          "inLookBook": null,
          "isEditorial": null,
          "isEvening": false,
          "isNewArrival": null,
          "isOnlyAtNM": true,
          "previewSupported": false,
          "showMonogramLabel": false,
        },
        "relatedProducts": Array [],
        "restrictedStates": null,
        "sellableDate": null,
        "serviceLevelCodes": Array [],
        "shortDescription": null,
        "sizeGuide": null,
        "sizeLabels": null,
        "skuList": Array [],
        "suppressCheckout": null,
      }
    `)
  })
})
