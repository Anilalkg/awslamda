import { buildDynamoDBEvent, buildDynamoDBRecord, mockUnmarshalledStreamImage } from '../../test/testData'
import { mapMediaUpdates, mapMediaUpdatesData, mapMedia } from '../mediaUpdatedMapper'

jest.mock('uuid', () => ({
  v4: jest.fn().mockReturnValue('1'),
}))

const mockConfig = {
  batchId: 'Auto-testId',
}

describe('mediaUpdatedMapper', () => {
  beforeAll(() => {
    jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('1')
  })

  afterAll(() => {
    jest.resetAllMocks()
  })

  describe('mapMediaUpdates', () => {
    it('returns the mapped record for every record that has INSERT or MODIFY eventName', () => {
      expect(mapMediaUpdates(buildDynamoDBEvent('INSERT'), mockConfig)).toHaveLength(1)
      expect(mapMediaUpdates(buildDynamoDBEvent('MODIFY'), mockConfig)).toHaveLength(1)
      expect(mapMediaUpdates(buildDynamoDBEvent('REMOVE'), mockConfig)).toHaveLength(0)
    })
  })

  describe('mapMediaUpdatesData', () => {
    it('returns the mapped message', () => {
      const result = mapMediaUpdatesData(buildDynamoDBRecord('INSERT'), mockConfig)
      expect(result.eventType).toBe('MediaUpdated')
      expect(result.id).toBe('2891137#0')
      expect(result.batchId).toBe(mockConfig.batchId)
      expect(result.media).toEqual(expect.objectContaining({}))
      expect(result.originTimestampInfo).toEqual({
        MediaUpdated: '1',
      })
      expect(result.dataPoints).toEqual({
        ProductId: '2891137#0',
      })
    })
  })
  describe('mapMedia', () => {
    it('matches snapshot', () => {
      const result = mapMedia(mockUnmarshalledStreamImage, '1')
      expect(result).toMatchInlineSnapshot(`
        Object {
          "a0": Object {
            "dataPoints": Object {
              "Tag": "a0",
              "Url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_a",
              "Version": "1",
            },
            "id": "1:a0:2891137#0",
            "mediaTag": "a0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_a",
          },
          "e0": Object {
            "dataPoints": Object {
              "Tag": "e0",
              "Url": "media.neimanmarcus.com/01/nm_2891137_100000_e",
              "Version": "1",
            },
            "id": "1:e0:2891137#0",
            "mediaTag": "e0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/01/nm_2891137_100000_e",
          },
          "k0": Object {
            "dataPoints": Object {
              "Tag": "k0",
              "Url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_k",
              "Version": "1",
            },
            "id": "1:k0:2891137#0",
            "mediaTag": "k0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_k",
          },
          "l0": Object {
            "dataPoints": Object {
              "Tag": "l0",
              "Url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_l",
              "Version": "1",
            },
            "id": "1:l0:2891137#0",
            "mediaTag": "l0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_l",
          },
          "m0": Object {
            "dataPoints": Object {
              "Tag": "m0",
              "Url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_m",
              "Version": "1",
            },
            "id": "1:m0:2891137#0",
            "mediaTag": "m0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_m",
          },
          "s0": Object {
            "dataPoints": Object {
              "Tag": "s0",
              "Url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_s",
              "Version": "1",
            },
            "id": "1:s0:2891137#0",
            "mediaTag": "s0",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_s",
          },
          "sw": Object {
            "dataPoints": Object {
              "Tag": "sw",
              "Url": null,
              "Version": "1",
            },
            "id": "1:sw:2891137#0",
            "mediaTag": "sw",
            "mediaVersion": "1",
            "messageType": "Product media event",
            "originTimestampInfo": Object {
              "MediaUpdated": "1",
            },
            "productId": "2891137#0",
            "url": null,
          },
        }
      `)
    })
  })
})
