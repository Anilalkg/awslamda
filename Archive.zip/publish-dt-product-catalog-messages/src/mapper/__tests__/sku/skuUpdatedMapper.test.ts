/* eslint-disable max-len */
import { buildStreamImage } from '../../../test/testData'
import { mapSkuUpdateData } from '../../sku/skuUpdatedMapper'

const mockRecordConfig = {
  batchId: 'Auto-testId',
  approximateCreationDateTime: '1',
}

describe('mediaUpdatedMapper', () => {
  it('matches snapshot', () => {
    expect(mapSkuUpdateData(buildStreamImage(), mockRecordConfig)).toMatchInlineSnapshot(`
      Object {
        "batchId": "Auto-testId",
        "dataPoints": Object {
          "ProductId": "2891137#0",
          "SkuListData": Array [
            Object {
              "Color": "SILVER 1",
              "DiscontinuedCode": null,
              "Exclusive": null,
              "Instock": false,
              "POQty": null,
              "ProductId": "2891137#0",
              "Size": "NO SIZE",
              "SkuId": null,
              "StockLevel": 0,
            },
          ],
        },
        "eventType": "SkuUpdated",
        "exclusive": null,
        "id": "2891137#0",
        "originTimestampInfo": Object {
          "SkuUpdated": "1",
        },
        "skuList": Array [
          Object {
            "batchId": null,
            "bossTotal": null,
            "cmosSkuId": null,
            "codeUpc": "5051001639510",
            "colorFacet": "SILVER",
            "colorKey": null,
            "colorName": "SILVER 1",
            "dataPoints": Object {
              "Color": "SILVER 1",
              "DiscontinuedCode": null,
              "Exclusive": null,
              "Instock": false,
              "POQty": null,
              "ProductId": "2891137#0",
              "Size": "NO SIZE",
              "SkuId": null,
              "StockLevel": 0,
            },
            "defaultColor": null,
            "deliveryDays": null,
            "depth": 20,
            "discontinuedCode": null,
            "displaySwatchImg": false,
            "dropShip": false,
            "exclusive": null,
            "expectedShipDate": null,
            "fedexEligible": null,
            "giftWrappableFlag": true,
            "height": 3,
            "hexCode": null,
            "iceFlag": null,
            "id": null,
            "inStock": false,
            "isNewColor": null,
            "isPerishable": null,
            "media": Array [
              Object {
                "tag": "a0",
                "url": null,
              },
              Object {
                "tag": "sw",
                "url": null,
              },
              Object {
                "tag": "e0",
                "url": null,
              },
              Object {
                "tag": "l0",
                "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_l",
              },
              Object {
                "tag": "a0",
                "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_a",
              },
              Object {
                "tag": "e0",
                "url": null,
              },
              Object {
                "tag": "s0",
                "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_s",
              },
              Object {
                "tag": "k0",
                "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_k",
              },
              Object {
                "tag": "m0",
                "url": "media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_m",
              },
              Object {
                "tag": "e0",
                "url": "media.neimanmarcus.com/01/nm_2891137_100000_e",
              },
            ],
            "originTimestampInfo": Object {
              "SkuUpdated": "1",
            },
            "pimColorCode": "100178",
            "pimColorKey": "47700",
            "pimSizeCode": "109999",
            "pimSizeKey": "12222100",
            "pimSkuId": "401102429766",
            "productId": "2891137#0",
            "purchaseOrderQuantity": null,
            "sequenceNumber": 1,
            "shipFromStore": null,
            "sizeKey": "109999",
            "sizeName": "NO SIZE",
            "stockLevel": 0,
            "styleId": null,
            "suggestedInterval": 0,
            "swatchPath": null,
            "useSkuAsset": false,
            "vendorId": "10001098",
            "width": 12,
          },
        ],
      }
    `)
  })
})
