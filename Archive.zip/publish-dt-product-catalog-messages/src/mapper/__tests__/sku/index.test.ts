import { buildDynamoDBEvent } from '../../../test/testData'
import { mapSkuUpdates } from '../../sku'

jest.mock('../../../utils/mapHelpers', () => ({
  isUpdated: jest.fn().mockImplementation((record) => record.eventName === 'INSERT' || record.eventName === 'MODIFY'),
  isPriceChanged: jest.fn().mockImplementation((record) => record.eventName === 'MODIFY'),
  getApproximateCreationDateTime: jest.fn().mockReturnValue('1'),
}))

const mockConfig = {
  batchId: 'Auto-mockConfig',
}

describe('mapProductUpdates', () => {
  it('returns empty array if record is not updated and if price has not changed', () => {
    expect(mapSkuUpdates(buildDynamoDBEvent('REMOVE'), mockConfig)).toEqual([])
  })

  it('maps a record if record is updated', () => {
    expect(mapSkuUpdates(buildDynamoDBEvent('INSERT'), mockConfig)).toHaveLength(1)
  })

  it('maps a record if records price has changed', () => {
    expect(mapSkuUpdates(buildDynamoDBEvent('MODIFY'), mockConfig)).toHaveLength(2)
  })
})
