import { DynamoDB } from 'aws-sdk'
import { DynamoDBStreamEvent } from 'aws-lambda'
import logger from '@nmg/oco-backend-utils/logger'
import { v4 as uuidv4 } from 'uuid'
import { IMediaUpdateMedia, IMediaUpdateMessage } from '../models/mediaUpdateMessage'
import { IProduct } from '../models/product'
import { MessageMapperConfig, RecordMapperConfig } from '../types'
import { isUpdated, getApproximateCreationDateTime } from '../utils/mapHelpers'

export const MEDIA_UPDATE_MESSAGE_TYPE = 'Product media event'

export function mapMediaUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IMediaUpdateMessage[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }
    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        for (const webProductId of productDoc.webProductIDs){   
          mappedRecords.push(mapMediaUpdatesData(productDoc, recordConfig, webProductId))
        }
      }
    }

    return mappedRecords
  }, [] as IMediaUpdateMessage[])
}

/*
export function mapMediaUpdates(event: DynamoDBStreamEvent, config: MessageMapperConfig): IMediaUpdateMessage[] {
  return event.Records.filter((record) => record.eventName === 'INSERT' || record.eventName === 'MODIFY').map(
    (record) => mapMediaUpdatesData(record, config),
  )
}
*/
export function mapMediaUpdatesData(productDoc: IProduct, config: RecordMapperConfig, productId: string): IMediaUpdateMessage {
  logger.debug({ message: 'Unmarshalled Document', data: productDoc })

  const mappedMediaUpdateMessage = {
    eventType: 'MediaUpdated',
    id: productId,
    batchId: config.batchId,
    media: mapMedia(productDoc, config.approximateCreationDateTime, productId),
    originTimestampInfo: {
      MediaUpdated: config.approximateCreationDateTime,
    },
    dataPoints: {
      ProductId: productId,
      DefaultColor : productDoc?.color?.default,
      DispItem : productDoc?.PartitionKey.concat(':').concat(productDoc?.SortKey)
    },
  }
  return mappedMediaUpdateMessage
}

export function mapMedia(
  productDoc: IProduct,
  approximateCreationDateTime: string, productId: string
): { [mediaTag: string]: IMediaUpdateMedia } {
  return productDoc.digitalAssets.reduce((result, digitalAsset) => {
    result[digitalAsset.mediaTag] = {
      id: `${uuidv4()}:${digitalAsset.mediaTag}:${productId}`,
      mediaTag: digitalAsset.mediaTag,
      mediaVersion: digitalAsset.mediaVersion,
      url: digitalAsset.url,
      productId,
      originTimestampInfo: {
        MediaUpdated: approximateCreationDateTime,
      },
      dataPoints: {
        Version: digitalAsset.mediaVersion,
        Tag: digitalAsset.mediaTag,
        Url: digitalAsset.url,
      },
      messageType: MEDIA_UPDATE_MESSAGE_TYPE,
    }
    return result
  }, {} as { [mediaTag: string]: IMediaUpdateMedia })
}
