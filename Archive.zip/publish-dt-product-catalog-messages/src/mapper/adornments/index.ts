import { DynamoDB } from 'aws-sdk'
import { DynamoDBStreamEvent } from 'aws-lambda'
import { IProduct } from '../../models/product'
import { IAdornmentsUpdated } from '../../models/adornmentsUpdatedMessage'
import { MessageMapperConfig } from '../../types'
import { isUpdated, isPriceChanged, getApproximateCreationDateTime } from '../../utils/mapHelpers'
import { mapPriceChangedAdornmentsUpdate } from './adornmentsPriceChangedMapper'
import { mapAdornmentsUpdatedData } from './adornmentsUpdatedMapper'

export function mapAdornmentsUpdated(event: DynamoDBStreamEvent, config: MessageMapperConfig): IAdornmentsUpdated[] {
  return event.Records.reduce((mappedRecords, record) => {
    const recordConfig = {
      ...config,
      approximateCreationDateTime: getApproximateCreationDateTime(record),
    }

    if (isUpdated(record)) {
      const productDoc = DynamoDB.Converter.unmarshall(record.dynamodb.NewImage) as IProduct 

      if(productDoc.webProductIDs && productDoc.webProductIDs.length > 0) {
        for (const webProductId of productDoc.webProductIDs){   
          mappedRecords.push(mapAdornmentsUpdatedData(productDoc, recordConfig, webProductId))
        }
      } 
    }

    /*
    if (isPriceChanged(record)) {
      const mappedOldAdornmentsUpdate = mapAdornmentsUpdatedData(record.dynamodb.OldImage, recordConfig)
      mappedRecords.push(mapPriceChangedAdornmentsUpdate(mappedOldAdornmentsUpdate))
    }
    */
    return mappedRecords
  }, [] as IAdornmentsUpdated[])
}
