import { IAdornmentsUpdated } from '../../models/adornmentsUpdatedMessage'

export function mapPriceChangedAdornmentsUpdate(adornmentsUpdatedMessage: IAdornmentsUpdated): IAdornmentsUpdated {
  return {
    ...adornmentsUpdatedMessage,
    retailPrice: 0,
    priceAdornments: [],
    dataPoints: {
      ...adornmentsUpdatedMessage.dataPoints,
      RetailPrice: 0,
      MaxAdornmentPrice: 0,
    },
  }
}
