import { IAdornmentsUpdated, IPriceAdornment, AdornmentsUpdatedEventType } from '../../models/adornmentsUpdatedMessage'
import { IProduct } from '../../models/product'
import { RecordMapperConfig } from '../../types'

export function mapAdornmentsUpdatedData(productDoc: IProduct, config: RecordMapperConfig, productId: string): IAdornmentsUpdated {

  let eventType: AdornmentsUpdatedEventType;
  if (productDoc.price.original === productDoc.price.retail) {
    eventType =  'AdornmentsRemoved';
  } else {
    eventType =  'AdornmentsUpdated';
  }
  return {
    eventType,
    batchId: config.batchId,
    id: productId,
    retailPrice: productDoc.price.retail,
    priceAdornments: mapPriceAdornments(productDoc, productId),
    dataPoints: {
      RetailPrice: productDoc.price.retail,
      MaxAdornmentPrice: calculateMaxAdornmentPrice(productDoc.price.original, productDoc.price.retail),
    },
    originTimestampInfo: {
      AdornmentsUpdated: config.approximateCreationDateTime,
    },
  }
}

export function mapPriceAdornments(productDoc: IProduct, productId: string): IPriceAdornment[] {
  if (productDoc.price.original === productDoc.price.retail) {
    return []
  }

  return [
    {
      id: null,
      batchId: null,
      label: 'Original',
      price: Number(productDoc.price.original),
      productId,
    },
    {
      id: null,
      batchId: null,
      label: 'NOW',
      price: Number(productDoc.price.retail),
      productId,
    },
  ]
}

export function calculateMaxAdornmentPrice(originalPrice: number, retailPrice: number): number  {
  const originalPriceAsNumber = originalPrice
  return originalPriceAsNumber !== retailPrice ? originalPriceAsNumber : 0
}
