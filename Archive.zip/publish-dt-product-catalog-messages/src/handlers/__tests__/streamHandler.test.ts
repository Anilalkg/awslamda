import logger from '@nmg/oco-backend-utils/logger'
import { buildDynamoDBEvent, mockConnection } from '../../test/testData'
import {
  processAdornmentsUpdates,
  processMediaUpdates,
  processOmniCatalogProductStream,
  processProductUpdates,
  processSkuUpdates,
  processStoreInventoryUpdates,
} from '../streamHandler'
import * as messagePublisher from '../../utils/messagePublisher'
import * as productUpdatesMapper from '../../mapper/product'
import * as mediaUpdatesMapper from '../../mapper/mediaUpdatedMapper'
import * as adornmentsUpdatesMapper from '../../mapper/adornments'
import * as skuUpdatesMapper from '../../mapper/sku'
import * as storeInventoryUpdatesMapper from '../../mapper/mapStoreInventoryUpdates'

describe('streamHandler', () => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const mappedData = [{ id: 1 }, { id: 2 }] as any

  beforeAll(() => {
    jest.spyOn(messagePublisher, 'establishConnection').mockResolvedValue(mockConnection)
    jest.spyOn(messagePublisher, 'closeConnection').mockResolvedValue()
    jest.spyOn(messagePublisher, 'publishToProductExchange').mockResolvedValue()
    jest.spyOn(messagePublisher, 'publishToProductPriceQueue').mockResolvedValue()
    jest.spyOn(messagePublisher, 'publishToProductSkuStoresInventoryQueue').mockResolvedValue()
    jest.spyOn(productUpdatesMapper, 'mapProductUpdates').mockReturnValue(mappedData)
    jest.spyOn(mediaUpdatesMapper, 'mapMediaUpdates').mockReturnValue(mappedData)
    jest.spyOn(adornmentsUpdatesMapper, 'mapAdornmentsUpdated').mockReturnValue(mappedData)
    jest.spyOn(skuUpdatesMapper, 'mapSkuUpdates').mockReturnValue(mappedData)
    jest.spyOn(storeInventoryUpdatesMapper, 'mapStoreInventoryUpdates').mockReturnValue(mappedData)
    jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('mockDate')
  })

  afterAll(() => {
    jest.resetModules()
  })

  const dynamoDBEvent = buildDynamoDBEvent('INSERT')
  const mapperConfig = {
    batchId: 'Auto-mockDate',
  }

  describe('processOmniCatalogProductStream', () => {
    it('does nothing if unable to create connection', async () => {
      jest.spyOn(messagePublisher, 'establishConnection').mockRejectedValueOnce('error')
      await processOmniCatalogProductStream(dynamoDBEvent)
      expect(logger.error).toHaveBeenCalled()
      expect(messagePublisher.publishToProductExchange).not.toHaveBeenCalled()
      expect(messagePublisher.publishToProductPriceQueue).not.toHaveBeenCalled()
      expect(messagePublisher.publishToProductSkuStoresInventoryQueue).not.toHaveBeenCalled()
    })

    it('attempts to publish all messages when connection is established', async () => {
      await processOmniCatalogProductStream(dynamoDBEvent)
      expect(productUpdatesMapper.mapProductUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(mediaUpdatesMapper.mapMediaUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(adornmentsUpdatesMapper.mapAdornmentsUpdated).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(skuUpdatesMapper.mapSkuUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(storeInventoryUpdatesMapper.mapStoreInventoryUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
    })
  })

  describe('processProductUpdates', () => {
    it('processProductUpdates', async () => {
      await processProductUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(productUpdatesMapper.mapProductUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).toHaveBeenCalledWith(mockConnection, mappedData)
    })

    it('does nothing if there are no mapped messages', async () => {
      jest.spyOn(productUpdatesMapper, 'mapProductUpdates').mockReturnValueOnce([])
      await processProductUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).not.toHaveBeenCalled()
    })

    it('logs error if mapping fails', async () => {
      jest.spyOn(productUpdatesMapper, 'mapProductUpdates').mockImplementationOnce(() => {
        throw new Error('error')
      })
      await processProductUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(logger.error).toHaveBeenCalled()
    })
  })

  describe('processMediaUpdates', () => {
    it('publishes mapped media updates to product exchange', async () => {
      await processMediaUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(mediaUpdatesMapper.mapMediaUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).toHaveBeenCalledWith(mockConnection, mappedData)
    })

    it('does nothing if there are no mapped messages', async () => {
      jest.spyOn(mediaUpdatesMapper, 'mapMediaUpdates').mockReturnValueOnce([])
      await processMediaUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).not.toHaveBeenCalled()
    })

    it('logs error if mapping fails', async () => {
      jest.spyOn(mediaUpdatesMapper, 'mapMediaUpdates').mockImplementationOnce(() => {
        throw new Error('error')
      })
      await processMediaUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(logger.error).toHaveBeenCalled()
    })
  })

  describe('processAdornmentsUpdates', () => {
    it('publishes mapped adornments updates to product price queue', async () => {
      await processAdornmentsUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(adornmentsUpdatesMapper.mapAdornmentsUpdated).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductPriceQueue).toHaveBeenCalledWith(mockConnection, mappedData)
    })

    it('does nothing if there are no mapped messages', async () => {
      jest.spyOn(adornmentsUpdatesMapper, 'mapAdornmentsUpdated').mockReturnValueOnce([])
      await processAdornmentsUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductPriceQueue).not.toHaveBeenCalled()
    })

    it('logs error if mapping fails', async () => {
      jest.spyOn(adornmentsUpdatesMapper, 'mapAdornmentsUpdated').mockImplementationOnce(() => {
        throw new Error('error')
      })
      await processAdornmentsUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(logger.error).toHaveBeenCalled()
    })
  })

  describe('processSkuUpdates', () => {
    it('publishes mapped sku updates to product exchange', async () => {
      await processSkuUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(skuUpdatesMapper.mapSkuUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).toHaveBeenCalledWith(mockConnection, mappedData)
    })

    it('does nothing if there are no mapped messages', async () => {
      jest.spyOn(skuUpdatesMapper, 'mapSkuUpdates').mockReturnValueOnce([])
      await processSkuUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductExchange).not.toHaveBeenCalled()
    })

    it('logs error if mapping fails', async () => {
      jest.spyOn(skuUpdatesMapper, 'mapSkuUpdates').mockImplementationOnce(() => {
        throw new Error('error')
      })
      await processSkuUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(logger.error).toHaveBeenCalled()
    })
  })

  describe('processStoreInventoryUpdates', () => {
    it('publishes mapped store inventory updates to product sku stores inventory queue', async () => {
      await processStoreInventoryUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(storeInventoryUpdatesMapper.mapStoreInventoryUpdates).toHaveBeenCalledWith(dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductSkuStoresInventoryQueue).toHaveBeenCalledWith(mockConnection, mappedData)
    })

    it('does nothing if there are no mapped messages', async () => {
      jest.spyOn(storeInventoryUpdatesMapper, 'mapStoreInventoryUpdates').mockReturnValueOnce([])
      await processStoreInventoryUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(messagePublisher.publishToProductSkuStoresInventoryQueue).not.toHaveBeenCalled()
    })

    it('logs error if mapping fails', async () => {
      jest.spyOn(storeInventoryUpdatesMapper, 'mapStoreInventoryUpdates').mockImplementationOnce(() => {
        throw new Error('error')
      })
      await processStoreInventoryUpdates(mockConnection, dynamoDBEvent, mapperConfig)
      expect(logger.error).toHaveBeenCalled()
    })
  })
})
