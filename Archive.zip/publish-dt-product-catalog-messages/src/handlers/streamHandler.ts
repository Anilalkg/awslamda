import rabbit from 'amqplib'
import logger from '@nmg/oco-backend-utils/logger'
import { DynamoDBStreamEvent } from 'aws-lambda'
import { mapAdornmentsUpdated } from '../mapper/adornments'
import { mapMediaUpdates } from '../mapper/mediaUpdatedMapper'
import {mapItemGroupUpdates, mapProductUpdates,mapProductDimensionsUpdates} from '../mapper/product'
import {
  establishConnection,
  closeConnection,
  publishToProductExchange,
  publishToProductPriceQueue,
  publishToProductSkuStoresInventoryQueue,
} from '../utils/messagePublisher'
import { MessageMapperConfig } from '../types'
import { mapSkuUpdates, mapSkuInventoryUpdates } from '../mapper/sku'
import { mapStoreInventoryUpdates } from '../mapper/mapStoreInventoryUpdates'

export const processOmniCatalogProductStream = async (event: DynamoDBStreamEvent): Promise<void> => {
  logger.debug({ message: 'Omni Catalog Product Stream Event', data: event })
  let connection

  try {
    connection = await establishConnection()
  } catch (error) {
    logger.error({ message: `Failed to connect to RabbitMq: ${error}` })
    return
  }

  const currentDateTime = new Date().toISOString().replace('Z', '')
  const mapperConfig = {
    batchId: `Product-Hub-Auto-${currentDateTime}`,
  }

  await processProductUpdates(connection, event, mapperConfig)
  await processProductDimensionsUpdates(connection, event, mapperConfig)
  await processMediaUpdates(connection, event, mapperConfig)
  await processAdornmentsUpdates(connection, event, mapperConfig)
  await processSkuUpdates(connection, event, mapperConfig)
  await processSkuInventoryUpdates(connection, event, mapperConfig)
  await processStoreInventoryUpdates(connection, event, mapperConfig)
  await closeConnection(connection)
}

export const processOmniCatalogItemGroupStream = async (event: DynamoDBStreamEvent): Promise<void> => {
  logger.debug({ message: 'Omni Catalog Product Stream Event', data: event })
  let connection

  try {
    connection = await establishConnection()
  } catch (error) {
    logger.error({ message: `Failed to connect to RabbitMq: ${error}` })
    return
  }

  const currentDateTime = new Date().toISOString().replace('Z', '')
  const mapperConfig = {
    batchId: `Product-Hub-Auto-${currentDateTime}`,
  }

  await processItemGroupUpdates(connection, event, mapperConfig)
  await closeConnection(connection)
}

export async function processItemGroupUpdates(
    connection: rabbit.Connection,
    event: DynamoDBStreamEvent,
    mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    const mappedProductUpdates = mapItemGroupUpdates(event, mapperConfig)
    if (mappedProductUpdates.length > 0) {
      logger.debug({ message: 'Mapped Item Group Updates List', data: mappedProductUpdates })
      await publishToProductExchange(connection, mappedProductUpdates)
    } else {
      logger.debug({ message: 'Item Group Updates List is empty' })
    }
  } catch (error) {
    logger.error(`Error ocurred while processing Item Group ProductUpdated message: ${error}`)
  }
}

export async function processMediaUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    const mappedMediaUpdates = mapMediaUpdates(event, mapperConfig)
    if (mappedMediaUpdates.length > 0 && mappedMediaUpdates[0]?.dataPoints?.DefaultColor) {
      logger.debug({ message: 'Mapped Media Updates List', data: mappedMediaUpdates })
      await publishToProductExchange(connection, mappedMediaUpdates)
    } else {
      logger.info({ message: 'MediaUpdated  List is empty or its not a default sku/color' , MediaNotUpdatedFor : mappedMediaUpdates[0]?.dataPoints?.DispItem })
    }
  } catch (error) {
    logger.error(`Error ocurred while processing MediaUpdate message: ${error}`)
  }
}

export async function processAdornmentsUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    const mappedAdornmentsUpdated = mapAdornmentsUpdated(event, mapperConfig)
    if (mappedAdornmentsUpdated.length > 0) {
      logger.debug({ message: 'Mapped Adornments Updates List', data: mappedAdornmentsUpdated })
      await publishToProductPriceQueue(connection, mappedAdornmentsUpdated)
    } else {
      logger.debug({ message: 'Adornments Updated List is empty' })
    }
  } catch (error) {
    logger.error(`Error ocurred while processing AdornmentsUpdated message: ${error}`)
  }
}

export async function processProductUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    const mappedProductUpdates = await mapProductUpdates(event, mapperConfig)
    if (mappedProductUpdates.length > 0) {
      logger.debug({ message: 'Mapped Product Updates List', data: mappedProductUpdates })
      await publishToProductExchange(connection, mappedProductUpdates)
    } else {
      logger.debug({ message: 'Product Updates List is empty' })
    }
  } catch (error) {
    logger.error(`Error ocurred while processing ProductUpdated message: ${error}`)
  }
}

export async function processProductDimensionsUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    const mappedProductUpdates = mapProductDimensionsUpdates(event, mapperConfig)
    if (mappedProductUpdates.length > 0) {
      logger.debug({ message: 'Mapped Product Dimensions Updates List', data: mappedProductUpdates })
      await publishToProductExchange(connection, mappedProductUpdates)
    } else {
      logger.debug({ message: 'Product Dimensions List is empty' })
    }
  } catch (error) {
    logger.error(`Error ocurred while processing PRODUCT_DIMENSIONS_UPDATED message: ${error}`)
  }
}

export async function processSkuUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    logger.info('Processing SkuUpdates')
    const mappedSkuUpdates = mapSkuUpdates(event, mapperConfig)
    if (mappedSkuUpdates.length > 0) {
      logger.debug({ message: 'Mapped SkuUpdates List', data: mappedSkuUpdates })
      await publishToProductExchange(connection, mappedSkuUpdates)
    } else {
      logger.info('SkuUpdates list is empty')
    }
  } catch (error) {
    logger.error(`Error ocurred while processing SkuUpdates: ${error}`)
  }
}

export async function processSkuInventoryUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    logger.info('Processing SkuInventoryUpdates')
    const mappedSkuUpdates = mapSkuInventoryUpdates(event, mapperConfig)
    if (mappedSkuUpdates.length > 0) {
      logger.debug({ message: 'Mapped SkuInventoryUpdates List', data: mappedSkuUpdates })
      await publishToProductExchange(connection, mappedSkuUpdates)
    } else {
      logger.info('SkuInventoryUpdates list is empty')
    }
  } catch (error) {
    logger.error(`Error ocurred while processing SkuInventoryUpdates: ${error}`)
  }
}

export async function processStoreInventoryUpdates(
  connection: rabbit.Connection,
  event: DynamoDBStreamEvent,
  mapperConfig: MessageMapperConfig,
): Promise<void> {
  try {
    logger.info('Processing StoreInventoryUpdatedMessage')
    const mappedStoreInventoryUpdates = mapStoreInventoryUpdates(event, mapperConfig)
    if (mappedStoreInventoryUpdates.length > 0) {
      logger.info({ message: 'Mapped StoreInventoryUpdates List', data: mappedStoreInventoryUpdates })
      await publishToProductSkuStoresInventoryQueue(connection, mappedStoreInventoryUpdates)
    } else {
      logger.info('StoreInventoryUpdates list is empty')
    }
  } catch (error) {
    logger.error(`Error ocurred while processing StoreInventoryUpdated message: ${error}`)
  }
}
