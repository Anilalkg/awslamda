import { DynamoDBRecord, DynamoDBStreamEvent } from 'aws-lambda'
import cloneDeep from 'lodash/cloneDeep'
import merge from 'lodash/merge'
import { IProduct } from '../models/product'
import { StreamRecord } from '../types'

export const mockChannel = {
  assertQueue: jest.fn(),
  assertExchange: jest.fn(),
  publish: jest.fn(),
  close: jest.fn(),
  sendToQueue: jest.fn(),
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
} as any

export const mockConnection = {
  createChannel: jest.fn().mockResolvedValue(mockChannel),
  close: jest.fn(),
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
} as any

const mockStreamImage = {
  discontinuedCode: {
    NULL: true,
  },
  notes: {
    NULL: true,
  },
  catalogType: {
    NULL: true,
  },
  serviceLevelCodes: {
    L: [],
  },
  sizeLabels: {
    NULL: true,
  },
  vendorId: {
    S: '10001098',
  },
  launchDate: {
    NULL: true,
  },
  shipping: {
    M: {
      deliveryDays: {
        NULL: true,
      },
      shipFromStore: {
        NULL: true,
      },
      expectedShipDate: {
        NULL: true,
      },
      boxedHeightInches: {
        N: '3',
      },
      boxedWidthInches: {
        N: '12',
      },
      boxedDepthInches: {
        N: '20',
      },
    },
  },
  skuNumber: {
    S: '401102429766',
  },
  price: {
    M: {},
  },
  iceFlag: {
    NULL: true,
  },
  designerBoutiqueUrl: {
    NULL: true,
  },
  digitalAssets: {
    L: [
      {
        M: {
          mediaTag: {
            S: 'a0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            NULL: true,
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'sw',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            NULL: true,
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'e0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            NULL: true,
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'l0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_l',
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'a0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_a',
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'e0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            NULL: true,
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 's0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_s',
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'k0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_k',
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'm0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_m',
          },
        },
      },
      {
        M: {
          mediaTag: {
            S: 'e0',
          },
          mediaVersion: {
            S: '1',
          },
          url: {
            S: 'media.neimanmarcus.com/01/nm_2891137_100000_e',
          },
        },
      },
    ],
  },
  productId: {
    S: '2891137#0',
  },
  suggestedInterval: {
    NULL: true,
  },
  displayable: {
    NULL: true,
  },
  sellableDate: {
    NULL: true,
  },
  shortDescription: {
    NULL: true,
  },
  suppressCheckout: {
    NULL: true,
  },
  genderCode: {
    S: 'Unisex',
  },
  variationId: {
    S: '2891137-100178',
  },
  size: {
    M: {
      pimKey: {
        S: '1222100',
      },
      pimCode: {
        S: '109999',
      },
      name: {
        S: 'NO SIZE',
      },
      key: {
        S: '109999',
      },
    },
  },
  intlParentheticalAmount: {
    NULL: true,
  },
  PartitionKey: {
    S: 'nmo#2891137',
  },
  displayItemType: {
    S: 'singlePriceDisplayItem',
  },
  storeInventories: {
    L: [],
  },
  longDescription: {
    // eslint-disable-next-line max-len
    S: '<ul><li>Viscose velvet pillow.</li><li>Reverse: linen/cotton. </li><li>12" x 20". </li><li>Dry clean.</li><li>Imported.</li></ul>',
  },
  swatchPath: {
    NULL: true,
  },
  hideInternationally: {
    BOOL: false,
  },
  color: {
    M: {
      pimKey: {
        S: '47700',
      },
      pimCode: {
        S: '100178',
      },
      name: {
        S: 'SILVER 1',
      },
      facet: {
        S: 'SILVER',
      },
    },
  },
  commodeCode: {
    S: '76256',
  },
  cmosSkuId: {
    NULL: true,
  },
  displayName: {
    S: 'Rivoli Decorative Pillow',
  },
  parentheticalCharge: {
    NULL: true,
  },
  pimStyle: {
    S: '2891137',
  },
  skuSequenceNumber: {
    N: '1',
  },
  flags: {
    M: {
      dynamicImageSkuColor: {
        BOOL: true,
      },
      useSkuAsset: {
        BOOL: false,
      },
      parenthetical: {
        BOOL: false,
      },
      previewSupported: {
        BOOL: false,
      },
      isOnlyAtNM: {
        NULL: true,
      },
      allowBackOrders: {
        NULL: true,
      },
      belongsToGroup: {
        BOOL: false,
      },
      blockOrders: {
        NULL: true,
      },
      hasMoreColors: {
        NULL: true,
      },
      preOrder: {
        NULL: true,
      },
      isEditorial: {
        NULL: true,
      },
      exclusive: {
        NULL: true,
      },
      giftWrappableFlag: {
        BOOL: true,
      },
      onSale: {
        BOOL: false,
      },
      inStock: {
        BOOL: false,
      },
      isEvening: {
        BOOL: false,
      },
      dropshipFlag: {
        BOOL: false,
      },
      isGroup: {
        BOOL: false,
      },
      showMonogramLabel: {
        BOOL: false,
      },
    },
  },
  SortKey: {
    S: '401102429766#1',
  },
  inventory: {
    M: {
      qty: {
        N: '0',
      },
      bossTotalQty: {
        NULL: true,
      },
    },
  },
  offline: {
    NULL: true,
  },
  cmosCatalogId: {
    NULL: true,
  },
  adornDate: {
    NULL: true,
  },
  codeUpc: {
    S: '5051001639510',
  },
  department: {
    M: {
      code: {
        S: '21-202-2009',
      },
      name: {
        S: 'Decorative I',
      },
    },
  },
  displayItem: {
    S: '2891137#0',
  },
  class: {
    M: {
      code: {
        S: '21-202-2009-648',
      },
      name: {
        S: 'Pillows ',
      },
    },
  },
  canonicalUrl: {
    S: '/p/Designers Guild-Rivoli Decorative Pillow-2891137#0',
  },
  hexValue: {
    NULL: true,
  },
  designer: {
    M: {
      descriptionTitle: {
        NULL: true,
      },
      name: {
        S: 'Designers Guild',
      },
      description: {
        NULL: true,
      },
    },
  },
  restrictedStates: {
    NULL: true,
  },
  liveTreeDate: {
    NULL: true,
  },
  cmosItem: {
    S: 'HBY4X',
  },
} as StreamRecord

export const mockUnmarshalledStreamImage = {
  discontinuedCode: null,
  notes: null,
  catalogType: null,
  serviceLevelCodes: [],
  sizeLabels: null,
  vendorId: '10001098',
  launchDate: null,
  shipping: {
    deliveryDays: null,
    shipFromStore: null,
    expectedShipDate: null,
    boxedHeightInches: 3,
    boxedWidthInches: 12,
    boxedDepthInches: 20,
  },
  skuNumber: '401102429766',
  price: {
    retail: '0',
    original: '0',
  },
  iceFlag: null,
  designerBoutiqueUrl: null,
  digitalAssets: [
    { mediaTag: 'a0', mediaVersion: '1', url: null },
    { mediaTag: 'sw', mediaVersion: '1', url: null },
    { mediaTag: 'e0', mediaVersion: '1', url: null },
    { mediaTag: 'l0', mediaVersion: '1', url: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_l' },
    { mediaTag: 'a0', mediaVersion: '1', url: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_a' },
    { mediaTag: 'e0', mediaVersion: '1', url: null },
    { mediaTag: 's0', mediaVersion: '1', url: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_s' },
    { mediaTag: 'k0', mediaVersion: '1', url: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_k' },
    { mediaTag: 'm0', mediaVersion: '1', url: 'media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100178_m' },
    { mediaTag: 'e0', mediaVersion: '1', url: 'media.neimanmarcus.com/01/nm_2891137_100000_e' },
  ],
  productId: '2891137#0',
  suggestedInterval: null,
  displayable: null,
  sellableDate: null,
  shortDescription: null,
  suppressCheckout: null,
  genderCode: 'Unisex',
  variationId: '2891137-100178',
  size: {
    pimKey: '12222100',
    pimCode: '109999',
    name: 'NO SIZE',
    key: '109999',
  },
  intlParentheticalAmount: null,
  PartitionKey: 'nmo#2891137',
  displayItemType: 'singlePriceDisplayItem',
  storeInventories: [],
  longDescription:
    // eslint-disable-next-line max-len
    '<ul><li>Viscose velvet pillow.</li><li>Reverse: linen/cotton. </li><li>12" x 20". </li><li>Dry clean.</li><li>Imported.</li></ul>',
  swatchPath: null,
  hideInternationally: false,
  color: {
    key: null,
    default: null,
    pimKey: '47700',
    pimCode: '100178',
    name: 'SILVER 1',
    facet: 'SILVER',
  },
  commodeCode: '76256',
  cmosSkuId: null,
  displayName: 'Rivoli Decorative Pillow',
  parentheticalCharge: null,
  pimStyle: '2891137',
  skuSequenceNumber: 1,
  flags: {
    dynamicImageSkuColor: true,
    useSkuAsset: false,
    parenthetical: false,
    previewSupported: false,
    isOnlyAtNM: true,
    allowBackOrders: true,
    belongsToGroup: false,
    blockOrders: true,
    hasMoreColors: null,
    preOrder: null,
    isEditorial: null,
    exclusive: null,
    giftWrappableFlag: true,
    onSale: false,
    inStock: false,
    isEvening: false,
    dropshipFlag: false,
    isGroup: false,
    showMonogramLabel: false,
    storeOnly: null,
    perishableFlag: null,
    fedexEligibleFlag: null,
  },
  SortKey: '401102429766#1',
  inventory: {
    qty: 0,
    bossTotalQty: null,
    status: null,
    purchaseOrderQty: null,
  },
  offline: null,
  cmosCatalogId: null,
  adornDate: null,
  codeUpc: '5051001639510',
  department: {
    code: '21-202-2009',
    name: 'Decorative I',
  },
  displayItem: '2891137#0',
  class: {
    code: '21-202-2009-648',
    name: 'Pillows ',
  },
  canonicalUrl: '/p/Designers Guild-Rivoli Decorative Pillow-2891137#0',
  hexValue: null,
  designer: {
    descriptionTitle: null,
    name: 'Designers Guild',
    description: null,
  },
  restrictedStates: null,
  liveTreeDate: null,
  cmosItem: 'HBY4X',
} as IProduct

export function buildStreamImage(recordOverrides: StreamRecord = {}): StreamRecord {
  return merge(cloneDeep(mockStreamImage), recordOverrides)
}

export function buildDynamoDBRecord(
  eventName: 'INSERT' | 'MODIFY' | 'REMOVE',
  recordOverrides: StreamRecord = {},
): DynamoDBRecord {
  const OldImage = eventName === 'MODIFY' ? buildStreamImage() : undefined
  const NewImage = buildStreamImage(recordOverrides)
  return {
    eventID: 'e867dgc32955b4e141b99a1486412a5f',
    eventName,
    eventVersion: '1.1',
    eventSource: 'aws:dynamodb',
    awsRegion: 'us-west-2',
    dynamodb: {
      ApproximateCreationDateTime: 1654779812,
      Keys: {
        PartitionKey: {
          S: 'nmo#2891137',
        },
        SortKey: {
          S: '401102429766#1',
        },
      },
      NewImage,
      OldImage,
      SequenceNumber: '80821100000000001320299411',
      SizeBytes: 2307,
      StreamViewType: 'NEW_AND_OLD_IMAGES',
    },
    eventSourceARN: 'arn:aws:dynamodb:us-west-2:123:table/test/stream/2022-05-23T12:11:05.884',
  }
}

export function buildDynamoDBEvent(
  eventName: 'INSERT' | 'MODIFY' | 'REMOVE',
  recordOverrides: StreamRecord = {},
): DynamoDBStreamEvent {
  return {
    Records: [buildDynamoDBRecord(eventName, recordOverrides)],
  }
}
