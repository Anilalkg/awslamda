export type AdornmentsUpdatedEventType = 'AdornmentsUpdated' | 'AdornmentsRemoved'

export type PriceAdornmentLabel = 'Original' | 'NOW'

export interface IPriceAdornment {
  id: null
  batchId: null
  label: PriceAdornmentLabel
  price: number
  productId: string
}

export interface IAdornmentsUpdated {
  eventType: AdornmentsUpdatedEventType
  batchId: string
  id: string
  retailPrice: number
  priceAdornments: IPriceAdornment[]
  dataPoints: {
    RetailPrice: number
    MaxAdornmentPrice: number | 0
  }
  originTimestampInfo: {
    AdornmentsUpdated: string
  }
}
