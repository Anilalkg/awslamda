export interface IMediaUpdateMedia {
  id: string
  mediaTag: string
  mediaVersion: string
  url: string
  productId: string
  originTimestampInfo: {
    MediaUpdated: string
  }
  dataPoints: {
    Version: string
    Tag: string
    Url: string
  }
  messageType: string
}

export interface IMediaUpdateMessage {
  eventType: string
  batchId: string
  id: string
  media: { [mediaTag: string]: IMediaUpdateMedia }
  originTimestampInfo: {
    MediaUpdated: string
  }
  dataPoints: {
    ProductId: string
    DefaultColor: boolean
    DispItem: string
  }
}
