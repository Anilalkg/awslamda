import { DynamoDBRecord } from 'aws-lambda'

const UPDATE_EVENTS = ['INSERT', 'MODIFY']
const PRICE_CHANGED_EVENTS = ['MODIFY', 'REMOVE']

export function isUpdated(record: DynamoDBRecord): boolean {
  return UPDATE_EVENTS.includes(record.eventName)
}

export function isPriceChanged(record: DynamoDBRecord): boolean {
  return (
    PRICE_CHANGED_EVENTS.includes(record.eventName) &&
    record.dynamodb.NewImage?.productId.S !== record.dynamodb.OldImage?.productId.S
  )
}

export function getApproximateCreationDateTime(record: DynamoDBRecord): string {
  return new Date(record.dynamodb.ApproximateCreationDateTime * 1000).toISOString().replace('Z', '')
}
