import { isPriceChanged, isUpdated, getApproximateCreationDateTime } from '../mapHelpers'
import { buildDynamoDBRecord } from '../../test/testData'

describe('mapHelpers', () => {
  const insertRecord = buildDynamoDBRecord('INSERT')
  const modifyRecord = buildDynamoDBRecord('MODIFY')
  const removeRecord = buildDynamoDBRecord('REMOVE')
  const priceChangedRecord = buildDynamoDBRecord('MODIFY', { productId: { S: '2891137#1000' } })

  beforeAll(() => {
    jest.useFakeTimers('modern')
  })

  afterAll(() => {
    jest.useRealTimers()
  })

  it('isUpdated returns true if records eventName is INSERT or MODIFY', () => {
    expect(isUpdated(insertRecord)).toBe(true)
    expect(isUpdated(modifyRecord)).toBe(true)
    expect(isUpdated(removeRecord)).toBe(false)
  })

  test('isPriceChanged returns true if records eventName is MODIFY or REMOVE and productId changed', () => {
    expect(isPriceChanged(insertRecord)).toBe(false)
    expect(isPriceChanged(modifyRecord)).toBe(false)
    expect(isPriceChanged(removeRecord)).toBe(true)
    expect(isPriceChanged(priceChangedRecord)).toBe(true)
  })

  test('getApproximateCreationDateTime', () => {
    const mockDate = new Date(1466424490000)
    const spy = jest.spyOn(global, 'Date').mockImplementation(() => mockDate as unknown as string)

    expect(getApproximateCreationDateTime(insertRecord)).toEqual('2016-06-20T12:08:10.000Z')
    expect(global.Date).toHaveBeenCalledWith(insertRecord.dynamodb.ApproximateCreationDateTime * 1000)

    spy.mockRestore()
  })
})
