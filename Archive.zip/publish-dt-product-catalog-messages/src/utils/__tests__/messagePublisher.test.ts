import rabbit from 'amqplib'
import logger from '@nmg/oco-backend-utils/logger'
import { mockChannel, mockConnection } from '../../test/testData'
import {
  closeConnection,
  establishConnection,
  publishToExchange,
  publishToInventoryExchange,
  publishToProductExchange,
  publishToProductPriceQueue,
  publishToProductSkuStoresInventoryQueue,
  publishToQueue,
} from '../messagePublisher'

describe('messagePublisher', () => {
  const data = [{ 1: 2 }, { 2: 3 }, { 3: 4 }]

  describe('closeConnection', () => {
    it('closes connection', async () => {
      await closeConnection(mockConnection)
      expect(mockConnection.close).toHaveBeenCalled()
    })

    it('throws if unabled to close connection', async () => {
      mockConnection.close.mockRejectedValueOnce('error')
      expect.assertions(1)
      try {
        await closeConnection(mockConnection)
      } catch (error) {
        expect(error).toBe('error')
      }
    })
  })

  describe('establishConnection', () => {
    it('returns the connection', async () => {
      jest.spyOn(rabbit, 'connect').mockResolvedValue(mockConnection as any)
      const result = await establishConnection()
      expect(result).toEqual(mockConnection)
      expect(rabbit.connect).toHaveBeenCalledWith(
        `amqp://${process.env.RABBITMQ_USERNAME}:${process.env.RABBITMQ_PASSWORD}@${process.env.RABBITMQ_HOST}`,
      )
    })

    it('throws if unable to connect', async () => {
      const error = 'unable to connect'
      jest.spyOn(rabbit, 'connect').mockRejectedValue(error)
      expect.assertions(1)
      try {
        await establishConnection()
      } catch (error) {
        expect(error).toBe(error)
      }
    })
  })

  describe('publish to queue', () => {
    const config = { queueName: 'test', queueOptions: {}, publishOptions: { contentType: 'application/json' } }

    it('publishes a message to queue for each data item', async () => {
      await publishToQueue(mockConnection, data, config)
      expect(mockConnection.createChannel).toHaveBeenCalled()
      expect(mockChannel.assertQueue).toHaveBeenCalledWith(config.queueName, config.queueOptions)
      data.forEach((dataItem) => {
        const message = Buffer.from(JSON.stringify(dataItem))
        expect(mockChannel.sendToQueue).toHaveBeenCalledWith(config.queueName, message, config.publishOptions)
      })
      expect(mockChannel.close).toHaveBeenCalled()
    })

    it('prints an error if publishing fails and closes queue', async () => {
      const error = 'unable to publish'

      mockChannel.assertQueue.mockRejectedValueOnce(error)
      await publishToQueue(mockConnection, data, config)
      expect(logger.error).toHaveBeenCalledWith(`Error occurred while publishing message to queue: ${error}`)
      expect(mockChannel.close).toHaveBeenCalled()
    })
  })

  describe('publish to exchange', () => {
    const config = {
      exchangeName: 'test',
      exchangeType: 'fanout',
      exchangeOptions: { durable: true },
      publishOptions: { contentType: 'application/json' },
    }

    it('publishes a message to exchange for each data item', async () => {
      await publishToExchange(mockConnection, data, config)
      expect(mockConnection.createChannel).toHaveBeenCalled()
      expect(mockChannel.assertExchange).toHaveBeenCalledWith(
        config.exchangeName,
        config.exchangeType,
        config.exchangeOptions,
      )
      data.forEach((dataItem) => {
        const message = Buffer.from(JSON.stringify(dataItem))
        expect(mockChannel.publish).toHaveBeenCalledWith(config.exchangeName, '', message, config.publishOptions)
      })
      expect(mockChannel.close).toHaveBeenCalled()
    })

    it('prints an error if publishing fails and closes queue', async () => {
      const error = 'unable to publish'

      mockChannel.assertExchange.mockRejectedValueOnce(error)
      await publishToExchange(mockConnection, data, config)
      expect(logger.error).toHaveBeenCalledWith(`Error occurred while publishing message to exchange: ${error}`)
      expect(mockChannel.close).toHaveBeenCalled()
    })
  })

  describe('publishToProductExchange', () => {
    it('calls publishToExchange with pre configured information', async () => {
      const config = {
        exchangeName: process.env.PRODUCT_EXCHANGE,
        exchangeType: 'fanout',
        exchangeOptions: { durable: true },
      }
      await publishToProductExchange(mockConnection, data)
      expect(mockChannel.assertExchange).toHaveBeenCalledWith(
        config.exchangeName,
        config.exchangeType,
        config.exchangeOptions,
      )
      expect(mockChannel.publish).toHaveBeenCalledTimes(3)
    })
  })

  describe('publishToInventoryExchange', () => {
    it('calls publishToExchange with pre configured information', async () => {
      const config = {
        exchangeName: process.env.INVENTORY_EXCHANGE,
        exchangeType: 'fanout',
        exchangeOptions: { durable: true },
      }
      await publishToInventoryExchange(mockConnection, data)
      expect(mockChannel.assertExchange).toHaveBeenCalledWith(
        config.exchangeName,
        config.exchangeType,
        config.exchangeOptions,
      )
      expect(mockChannel.publish).toHaveBeenCalledTimes(3)
    })
  })

  describe('publishToProductPriceQueue', () => {
    it('calls publishToQueue with pre configured information', async () => {
      const config = {
        queueName: process.env.PRODUCT_PRICE_QUEUE,
        publishOptions: {
          contentType: 'application/json',
        },
      }
      await publishToProductPriceQueue(mockConnection, data)
      expect(mockChannel.assertQueue).toHaveBeenCalledWith(config.queueName, undefined)
      expect(mockChannel.sendToQueue).toHaveBeenCalledTimes(3)
      expect(mockChannel.sendToQueue).toHaveBeenLastCalledWith(
        config.queueName,
        Buffer.from(JSON.stringify(data[data.length - 1])),
        config.publishOptions,
      )
    })
  })

  describe('publishToProductSkuStoresInventoryQueue', () => {
    it('calls publishToQueue with pre configured information', async () => {
      const config = {
        queueName: process.env.PRODUCT_SKU_STORES_INVENTORY_QUEUE,
        publishOptions: {
          contentType: 'application/json',
        },
      }
      await publishToProductSkuStoresInventoryQueue(mockConnection, data)
      expect(mockChannel.assertQueue).toHaveBeenCalledWith(config.queueName, undefined)
      expect(mockChannel.sendToQueue).toHaveBeenCalledTimes(3)
      expect(mockChannel.sendToQueue).toHaveBeenLastCalledWith(
        config.queueName,
        Buffer.from(JSON.stringify(data[data.length - 1])),
        config.publishOptions,
      )
    })
  })
})
