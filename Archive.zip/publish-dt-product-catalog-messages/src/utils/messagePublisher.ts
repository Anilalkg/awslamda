import rabbit from 'amqplib'
import logger from '@nmg/oco-backend-utils/logger'
import { PublishToExchangeConfig, PublishToQueueConfig } from '../types'

const RABBITMQ_HOST = process.env.RABBITMQ_HOST || ''
const RABBITMQ_USERNAME = process.env.RABBITMQ_USERNAME || ''
const RABBITMQ_PASSWORD = encodeURIComponent(process.env.RABBITMQ_PASSWORD || '')
const PRODUCT_EXCHANGE = process.env.PRODUCT_EXCHANGE || ''
const INVENTORY_EXCHANGE = process.env.INVENTORY_EXCHANGE || ''
const PRODUCT_PRICE_QUEUE = process.env.PRODUCT_PRICE_QUEUE || ''
const PRODUCT_SKU_STORES_INVENTORY_QUEUE = process.env.PRODUCT_SKU_STORES_INVENTORY_QUEUE || ''

export async function establishConnection(): Promise<rabbit.Connection> {
  logger.debug({ message: 'Connecting to RabbitMQ...' })
  const connection = await rabbit.connect(`amqp://${RABBITMQ_USERNAME}:${RABBITMQ_PASSWORD}@${RABBITMQ_HOST}`)
  logger.debug({ message: 'RabbitMQ connection established!'})
  return connection
}

export async function closeConnection(connection: rabbit.Connection): Promise<void> {
  logger.debug({ message: 'Closing connection to RabbitMQ...' })
  await connection.close()
  logger.debug({ message: 'RabbitMq connection closed!' })
}

export async function publishToQueue<T = unknown>(
  connection: rabbit.Connection,
  data: T[],
  config: PublishToQueueConfig,
): Promise<void> {
  let channel: rabbit.Channel
  try {
    logger.debug({ message: 'Creating Channel...' })
    channel = await connection.createChannel()
    logger.debug({ message: 'Channel created, Asserting queue...' })
    await channel.assertQueue(config.queueName, config.queueOptions)
    data.forEach((messageData) => {
      const message = JSON.stringify(messageData)
      logger.info(`Sending message to queue: ${message}`)
      channel.sendToQueue(config.queueName, Buffer.from(message), {...config.publishOptions, headers : {"Product-Hub" : "true"}})
    })
    logger.debug({ message: `Closing Channel ${config.queueName}...` })
  } catch (error) {
    logger.error(`Error occurred while publishing message to queue: ${error}`)
  }

  if (channel) {
    await channel.close()
    logger.debug({ message: `Channel ${config.queueName} closed` })
  }
}

export async function publishToExchange<T = unknown>(
  connection: rabbit.Connection,
  data: T[],
  config: PublishToExchangeConfig,
): Promise<void> {
  let channel: rabbit.Channel
  try {
    logger.debug({ message: 'Creating Channel...' })
    channel = await connection.createChannel()
    const {exchangeName, exchangeType, exchangeOptions} = config;
    logger.debug({ message: 'Channel created, Asserting exchange...', config: { exchangeName, exchangeType, exchangeOptions } });
    await channel.assertExchange(exchangeName, exchangeType, exchangeOptions)
    data.forEach((messageData) => {
      const message = JSON.stringify(messageData)
      // @ts-ignore
      const publishOptions = {...config.publishOptions, type: messageData?.eventType, headers : {"Product-Hub" : "true"}};
      logger.info(`Publishing message to exchange: ${message}`);
      const published = channel.publish(config.exchangeName, '', Buffer.from(message), publishOptions)
      logger.info(`OmniCatalogPublishUpdate="Success", ${published}, ${JSON.stringify(publishOptions)}`)
    })
  } catch (error) {
    logger.error(`Error occurred while publishing message to exchange: ${error}`)
  }
  if (channel) {
    await channel.close();
  }
}
export async function publishToProductExchange<T = unknown>(connection: rabbit.Connection, data: T[]): Promise<void> {
  await publishToExchange(connection, data, {
    exchangeName: PRODUCT_EXCHANGE,
    exchangeType: 'fanout',
    exchangeOptions: { durable: true },
  })
}

export async function publishToInventoryExchange<T = unknown>(connection: rabbit.Connection, data: T[]): Promise<void> {
  await publishToExchange(connection, data, {
    exchangeName: INVENTORY_EXCHANGE,
    exchangeType: 'fanout',
    exchangeOptions: { durable: true },
  })
}

export async function publishToProductPriceQueue<T = unknown>(connection: rabbit.Connection, data: T[]): Promise<void> {
  await publishToQueue(connection, data, {
    queueName: PRODUCT_PRICE_QUEUE,
    publishOptions: {
      contentType: 'application/json',
      type: 'AdornmentsUpdated'
    },
  })
}

export async function publishToProductSkuStoresInventoryQueue<T = unknown>(
  connection: rabbit.Connection,
  data: T[],
): Promise<void> {
  await publishToQueue(connection, data, {
    queueName: PRODUCT_SKU_STORES_INVENTORY_QUEUE,
    publishOptions: {
      contentType: 'application/json',
    },
  })
}
