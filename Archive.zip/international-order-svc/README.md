international-order-svc: Serverless API to store the international order in dynamo DB

Functions in scope:

src/handler.ts: This function accepts an HTTP post and stores the order info into a DYnamo db table
 