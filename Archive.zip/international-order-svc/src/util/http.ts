import { APIGatewayProxyResult } from 'aws-lambda';
import request from 'request';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
  'Access-Control-Allow-Headers,Access-Control-Allow-Origin,Authorization,Content-Type,X-Amz-Date,X-Amz-User-Agent',
  'Access-Control-Allow-Credentials': false,
};

function response(statusCode: number, payload: any): APIGatewayProxyResult {
  return {
    statusCode,
    headers,
    body: JSON.stringify(payload),
  };
}

export async function ok(payload?: any): Promise<APIGatewayProxyResult> {
  let body = payload;
  if (!payload) {
    body = { message: 'No Payload' };
  }
  return response(200, body);
}

export function error(
  statusCode: number,
  message: string,
): APIGatewayProxyResult {
  return response(statusCode, { message });
}
