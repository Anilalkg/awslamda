export class InternationalOrder {
  profileId: string;
  orderId: string;
  orderTotal: string;
  orderStatus: string;
  orderVersion: string;
  lineItems: LineItem[];
  borderFreeOrderId: string;
  creationDate: string;
  lastUpdateDate: string;
  currencyCode: string;
  countryCode: string;
}
export class LineItem {
    skuId: string;
    quantity: string;
    listPrice: string;
    salePrice: string;
    surcharge: string;
}
