import { DataMapper } from '@aws/dynamodb-data-mapper';
import { attribute, hashKey, table, rangeKey } from '@aws/dynamodb-data-mapper-annotations';
import { ConditionExpression, attributeNotExists } from '@aws/dynamodb-expressions';
import { DynamoDB } from 'aws-sdk';
import { property } from '@nmg/osp-backend-utils/config';
import logger from '@nmg/osp-backend-utils/logger';
import moment from 'moment';
import { InternationalOrder, LineItem } from './models';

const ORDER_TABLE = property('ORDER_TABLE');
const ORDER_ID_PREFIX = property('ORDER_ID_PREFIX');

const mapper = new DataMapper({ client: new DynamoDB() });

/*
{
   "orderReq":{
      "profileId":"u123",
      "orderId":"o123",
      "orderTotal":100.99,
      "orderStatus":"Incomplete/Submitted",
      "lineItems":[
         {
            "skuId":"sku123",
            "qty":1,
            "listPrice":99.99,
            "salePrice":90.99,
            "surcharge":10
         },
         {
            "skuId":"sku234",
            "qty":1,
            "listPrice":299.99,
            "salePrice":920.99,
            "surcharge":210
         },
         {
            "skuId":"sku345",
            "qty":1,
            "listPrice":199.99,
            "salePrice":190.99,
            "surcharge":101
         }
      ],
      "borderFreeOrderId":"bfree123"
   }
}
*/
function generateOrderId() {
  let now = Date.now();
  return ORDER_ID_PREFIX + Math.floor(now);
}

@table(ORDER_TABLE)
export class Order {
  @hashKey()
  profileId: string;

  @rangeKey({ defaultProvider: () => generateOrderId() })
  orderId?: string;

  @attribute()
  orderStatus?: string;

  @attribute()
  borderFreeOrderId?: string;

  @attribute()
  orderTotal?: number;

  @attribute()
  lineItems?: LineItem[];

  @attribute()
  orderVersion: number

  @attribute()
  creationDate: string /* TODO needs change */

  @attribute()
  lastUpdateDate: string /* TODO needs change */

  @attribute()
  currencyCode: string /* TODO needs change */

  @attribute()
  countryCode: string /* TODO needs change */

  constructor(profileId?: string, orderId?: string) {
    this.orderId = orderId;
    this.profileId = profileId;
  }
}

export function buildOrder(body: any): Order {
  const { orderReq } = body;
  const order = new Order();
  //  order.orderId = orderReq?.orderId;
  order.orderTotal = orderReq?.orderTotal;
  order.profileId = orderReq?.profileId;
  order.borderFreeOrderId = orderReq?.borderFreeOrderId;
  order.orderStatus = orderReq?.orderStatus;
  order.creationDate = moment().format();
  order.orderVersion = 0;
  order.lineItems = getLineItems(orderReq?.lineItems);
  order.countryCode = orderReq?.countryCode || 'US';
  order.currencyCode = orderReq?.currencyCode || 'USD';
  return order;
}

export function modifyOrder(order: Order, body: any): Order {
  const { orderReq } = body;
  order.orderTotal = orderReq?.orderTotal;
  order.borderFreeOrderId = orderReq?.borderFreeOrderId;
  order.orderStatus = orderReq?.orderStatus;
  order.lastUpdateDate = moment().format();
  order.orderVersion = (order?.orderVersion || 0) + 1;
  order.lineItems = getLineItems(orderReq?.lineItems);
  order.countryCode = orderReq?.countryCode || 'US';
  order.currencyCode = orderReq?.currencyCode || 'USD';
  return order;
}

export const getOrderItemIfExists = async (profileId: string): Promise<Order> => {
  const attributeExistsPredicate = attributeNotExists();
  const attributeExistsExpression: ConditionExpression = {
    ...attributeExistsPredicate,
    subject: 'borderFreeOrderId',
  };

  logger.debug({ query: 'About to query for profile id', profile: profileId });

  const iterator = mapper.query(Order, { profileId }, { filter: attributeExistsExpression });

  // eslint-disable-next-line no-restricted-syntax
  for await (const item of iterator) {
    // return the first item from the list for the given profile's
    // empty order
    logger.debug({ query_reult: 'Found an order for profile:', profile: profileId, orderid: item.orderId });
    return item;
  }
  return undefined;
};

export const getItem = async (profileId: string, orderId: string): Promise<Order> => {
  const order = new Order(profileId, orderId);
  return await mapper.get(order);
};

function getLineItems(items: LineItem[]) {
  return items;
}

export async function upsertOrderItem(body: any): Promise<Order> {
  logger.info({ message: 'Begin upsertOrderItem: ' });
  let order;
  if (body.orderReq.orderId) {
    try {
      order = await getItem(body.orderReq.profileId, body.orderReq.orderId);
    } catch (error) {
      const errMsg = error.message;
      logger.error({
        message: 'Error reading from table!',
        errorMessage: errMsg,
      });
      throw errMsg;
    }
  } else {
    try {
      // check for order with no borderfree id for the given profile id,
      // if so pull it and update the same
      order = await getOrderItemIfExists(body.orderReq.profileId);
    } catch (error) {
      logger.error({
        message: 'Error querying table!',
        errorMessage: error,
      });
    }
  }

  try {
    if (order) {
      logger.info({ message: 'About to update order : ', order });
      order = modifyOrder(order, body);
      logger.info({ message: 'Order is updated : ', order });
      return await mapper.update(order);
    } else {
      logger.debug({ message: 'About to insert order : ', order });
      order = buildOrder(body);
      logger.info({ message: 'Order is created : ', order });
      return await mapper.put(order);
    }
  } catch (error) {
    logger.error({
      message: 'Error occured..',
      errorMessage: error.message,
    });
    throw error;
  }
}
