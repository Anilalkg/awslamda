import logger from '@nmg/osp-backend-utils/logger';
import { APIGatewayProxyEvent, Context } from 'aws-lambda';
import { ok, error } from './util/http';
import { upsertOrderItem } from './storage';

export const upsertOrder = async (event: APIGatewayProxyEvent, context: Context) => {
  logger.info({ message: 'Begin event: ', event });

  if (event.body) {
    const body = JSON.parse(event.body);
    logger.info({ message: 'Body is : ', body });
    const brand: string = event.pathParameters?.brandId?.toUpperCase() || 'NM';

    if (!body.orderReq?.lineItems || !body.orderReq?.lineItems.length) {
      return error(400, 'Missing cart line items in the request');
    }
    return await upsertOrderItem(body).then((response: any) => {
      logger.info({ message: ' result: ', response });
      return ok(response);
    }).catch((err) => {
      logger.error({ message: ' error occured : ', err });
      return error(404, err);
    });
  } else {
    return error(400, 'Bad request - missing body');
  }
};
