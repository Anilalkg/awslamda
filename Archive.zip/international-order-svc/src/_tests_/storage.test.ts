import { buildOrder, modifyOrder, Order } from '../storage';
import { createOrderReq, createdOrder, updatedOrderReq, updatedOrder } from './mocks';

describe('createOrder', () => {
  let orderObj1: Order;

  beforeEach(() => {
    orderObj1 = buildOrder(createOrderReq);
  });

  it('returns matched new order info with existing', () => {
    orderObj1.creationDate = '';
    orderObj1.lastUpdateDate = '';
    orderObj1.orderId = createdOrder.orderId;
    expect(orderObj1).toEqual(createdOrder);
  });
});

describe('updateOrder', () => {
  let orderObj1: Order;

  beforeEach(() => {
    orderObj1 = buildOrder(createOrderReq);
    orderObj1 = modifyOrder(orderObj1, updatedOrderReq);
    orderObj1.orderId = createdOrder.orderId;
  });

  it('returns matched new order info with existing', () => {
    orderObj1.creationDate = '';
    orderObj1.lastUpdateDate = '';
    expect(orderObj1).toEqual(updatedOrder);
  });
});
