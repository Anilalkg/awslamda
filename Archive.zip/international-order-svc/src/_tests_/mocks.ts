import { Order } from '../storage';

export const createOrderReq = {
  orderReq: {
    profileId: 'p100',
    orderId: 'o100',
    orderTotal: 18.98,
    orderStatus: 'Incomplete',
    borderFreeOrderId: 'bf123',
    creationDate: '',
    lastUpdateDate: '',
    orderVersion: 0,
    currencyCode: 'USD',
    countryCode: 'US',
    lineItems: [
      {
        skuId: 'sku100',
        qty: 1,
        listPrice: 9.99,
        salePrice: 8.99,
        surcharge: 1,
      },
      {
        skuId: 'sku101',
        qty: 1,
        listPrice: 8.99,
        salePrice: 7.99,
        surcharge: 2,
      },
    ],
  },
};

export const createdOrder = {
  profileId: 'p100',
  orderId: 'o100',
  orderTotal: 18.98,
  orderStatus: 'Incomplete',
  borderFreeOrderId: 'bf123',
  creationDate: '',
  lastUpdateDate: '',
  orderVersion: 0,
  currencyCode: 'USD',
  countryCode: 'US',
  lineItems: [
    {
      skuId: 'sku100',
      qty: 1,
      listPrice: 9.99,
      salePrice: 8.99,
      surcharge: 1,
    },
    {
      skuId: 'sku101',
      qty: 1,
      listPrice: 8.99,
      salePrice: 7.99,
      surcharge: 2,
    },
  ],
};

export const updatedOrderReq = {
  orderReq: {
    profileId: 'p100',
    orderId: 'o100',
    orderTotal: 18.98,
    orderStatus: 'Incomplete',
    borderFreeOrderId: 'bf123',
    orderVersion: 1,
    currencyCode: 'USD',
    countryCode: 'US',
    lineItems: [
      {
        skuId: 'sku100',
        qty: 1,
        listPrice: 9.99,
        salePrice: 8.99,
        surcharge: 1,
      },
      {
        skuId: 'sku101',
        qty: 1,
        listPrice: 8.99,
        salePrice: 7.99,
        surcharge: 2,
      },
    ],
  },
};

export const updatedOrder = {
  profileId: 'p100',
  orderId: 'o100',
  orderTotal: 18.98,
  orderStatus: 'Incomplete',
  borderFreeOrderId: 'bf123',
  creationDate: '',
  lastUpdateDate: '',
  orderVersion: 1,
  currencyCode: 'USD',
  countryCode: 'US',
  lineItems: [
    {
      skuId: 'sku100',
      qty: 1,
      listPrice: 9.99,
      salePrice: 8.99,
      surcharge: 1,
    },
    {
      skuId: 'sku101',
      qty: 1,
      listPrice: 8.99,
      salePrice: 7.99,
      surcharge: 2,
    },
  ],
};
