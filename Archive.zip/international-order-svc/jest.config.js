module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'node',
    setupFiles: ['<rootDir>/jest/setEnvVars.ts'],
    coveragePathIgnorePatterns: ['storage.*', 'handlerTestData.ts'],
  };