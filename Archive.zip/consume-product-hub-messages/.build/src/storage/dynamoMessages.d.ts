import { IDesigner, IFlags, ITaxonomy, IShipping, IProduct } from '../models/productHubMessage';
import { IComponents } from '../models/data/components';
import { IStoreInventoryData } from '../models/data';
export declare const COMPONENT_ACTION_NEW_OR_UPDATED = 1;
export declare const COMPONENT_ACTION_REMOVED = 2;
export declare class Sku {
    productId: string;
    id: string;
    pimSkuId: string;
}
export declare class DigitalAsset {
    mediaTag: string;
    mediaVersion: string;
    url: string;
}
export declare class Taxonomy {
    code: string;
    name: string;
}
export declare class Designer {
    name: string;
    descriptionTitle: string;
    description: string;
}
export declare class Flags {
    isGroup: boolean;
    belongsToGroup: boolean;
    preOrder: boolean;
    allowBackOrders: boolean;
    blockOrders: boolean;
    dynamicImageSkuColor: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
    storeOnly: boolean;
    exclusive: boolean;
    inStock: boolean;
    useSkuAsset: boolean;
    giftWrappableFlag: boolean;
    perishableFlag: boolean;
    dropshipFlag: boolean;
    fedexEligibleFlag: boolean;
    parenthetical: boolean;
    isOnlyAtNM: string;
    hasMoreColors: string;
    onSale: boolean;
}
export declare class Color {
    key: string;
    name: string;
    pimKey: string;
    pimCode: string;
    facet: string[];
    default: boolean;
}
export declare class Size {
    name: string;
    pimKey: string;
    pimCode: string;
    key: string;
}
export declare class Inventory {
    status: string;
    onHandStatus: string;
    qty: number;
    purchaseOrderQty: number;
    bossTotalQty: number;
}
export declare class Shipping {
    boxedDepthInches: number;
    boxedHeightInches: number;
    boxedWidthInches: number;
    deliveryDays: number;
    shipFromStore?: string;
    expectedShipDate?: string;
}
export declare class StoreInventory {
    storeId: string;
    storeNumber: string;
    locationNumber: string;
    quantity: bigint;
    bopsQuantity: bigint;
    invLevel: bigint;
}
export declare class Price {
    retail: number;
    original: number;
}
export declare class SimpleProduct {
    launchDate: string;
    adornDate: string;
}
export declare class Components {
    componentLevel: string;
    componentNumber: string;
    quantity?: number;
    componentSequence?: number;
    componentDepiction?: string;
    componentDepictionSequence?: number;
}
export declare class Product {
    PartitionKey: string;
    SortKey: string;
    skuNumber: string;
    skuSequenceNumber: number;
    displayItem: string;
    displayItemType: string;
    variationId: string;
    productId: string;
    price: Price;
    color: Color;
    size: Size;
    inventory: Inventory;
    digitalAssets: DigitalAsset[];
    hexValue: string;
    merchandiseType: string;
    swatchPath: string;
    shipping: IShipping;
    suggestedInterval: string;
    displayName: string;
    department: ITaxonomy;
    class: ITaxonomy;
    subclass?: ITaxonomy;
    designer: IDesigner;
    serviceLevelCodes: string[];
    sellableDate: string;
    adornDate: string;
    launchDate: string;
    commodeCode: string;
    genderCode: string;
    flags: IFlags;
    shortDescription: string;
    longDescription: string;
    notes: string;
    cmosCatalogId: string;
    cmosItem: string;
    catalogType?: string;
    pimStyle: string;
    parentheticalCharge: string;
    intlParentheticalAmount: string;
    displayable?: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl?: string;
    hideInternationally: boolean;
    suppressCheckout?: string;
    sizeLabels?: string;
    offline?: string;
    liveTreeDate?: string;
    restrictedStates: string;
    cmosSkuId?: string;
    codeUpc: string;
    discontinuedCode?: string;
    vendorId: string;
    iceFlag?: string;
    storeInventories: StoreInventory[];
    onHandQty?: number;
    onOrderQty?: number;
    displayGroups?: string[];
    webProductIDs?: string[];
    psHierarchy: any;
    psAttributes: any;
    componentsOf?: string[];
    displayAsGroupEligible?: boolean;
    sizeGuide?: string;
    webSkuId: string;
}
export declare class Media {
    id: string;
    mediaTag: string;
    mediaVersion: string;
    url: string;
    productId: string;
    dynamicImageSkuColor: boolean;
}
export declare class ProductFlags {
    isOnlyAtNM: boolean;
    dynamicImageSkuColor: boolean;
    hasMoreColors: boolean;
    isNewArrival: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    inLookBook: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
}
export declare class OriginTimestampInfo {
    ProductUpdated: string;
}
export declare class FilterFacet {
    label: string;
    sortOrder: number;
}
export declare class DataPoints {
    ProductId: string;
}
export declare class ItemGroup {
    PartitionKey: string;
    productId: string;
    childProductIds?: string[];
    description: string;
    media: Media[];
    displayName: string;
    notes: string;
    help: string;
    sizeGuide: string;
    cmosCatalogId: string;
    cmosItem: string;
    merchandiseType: string;
    catalogType: string;
    pimStyle: string;
    departmentDesc: string;
    classDesc: string;
    designerName: string;
    designerDescriptionTitle: string;
    designerDescription: string;
    parentheticalCharge: number;
    intlParentheticalAmount: number;
    personalShopper: boolean;
    exclusive: boolean;
    preOrder: boolean;
    displayable: boolean;
    dynamicImageSkuColor: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl: string;
    serviceLevelCodes: string[];
    productFlags: ProductFlags;
    hideInternationally: boolean;
    onSale: boolean;
    suppressCheckout: boolean;
    aliPay: boolean;
    parenthetical: boolean;
    departmentCode: string;
    commodeCode: string;
    classCode: string;
    metaInfo: string;
    codeSetType: string;
    sizeLabels: FilterFacet[];
    offline: boolean;
    originTimestampInfo: OriginTimestampInfo;
    sellableDate: string;
    liveTreeDate: string;
    adornDate: string;
    isBvd: boolean;
    genderCode: string;
    restrictedStates: string;
    restrictedCodes: string;
    hierarchy: {
        [key: string]: string;
    }[];
    attributes: {
        [key: string]: string[];
    }[];
    dataPoints: DataPoints;
    components?: Components[];
    constructor(partitionKey?: string);
}
export declare const saveProduct: (message: IProduct) => Promise<void>;
export declare const saveItemGroups: (message: ItemGroup) => Promise<void>;
export declare const getItemGroups: (suiteNumber: string) => Promise<ItemGroup[]>;
export declare const getParentGroupIds: (components: string[]) => Promise<string[]>;
export declare const findRemovedComponentsFromTheUpdateMessage: (suiteNumber: string, newComponents: IComponents[]) => Promise<IComponents[]>;
export declare const getDisplayItems: (components: IComponents[]) => Promise<Product[]>;
export declare const updateDisplayItems: (products: Product[], suiteNumber: string, action: number) => Promise<Product[]>;
export declare const updateStoreInventory: (message: IStoreInventoryData) => Promise<Product[]>;
export declare const getProducts: (skuNum: string) => Promise<Product[]>;
export declare const findAtgSkuId: (prodId: string, skuNumber: string) => Promise<string>;
