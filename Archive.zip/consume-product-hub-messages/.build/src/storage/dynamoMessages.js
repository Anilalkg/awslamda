"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.findAtgSkuId = exports.getProducts = exports.updateStoreInventory = exports.updateDisplayItems = exports.getDisplayItems = exports.findRemovedComponentsFromTheUpdateMessage = exports.getParentGroupIds = exports.getItemGroups = exports.saveItemGroups = exports.saveProduct = exports.ItemGroup = exports.DataPoints = exports.FilterFacet = exports.OriginTimestampInfo = exports.ProductFlags = exports.Media = exports.Product = exports.Components = exports.SimpleProduct = exports.Price = exports.StoreInventory = exports.Shipping = exports.Inventory = exports.Size = exports.Color = exports.Flags = exports.Designer = exports.Taxonomy = exports.DigitalAsset = exports.Sku = exports.COMPONENT_ACTION_REMOVED = exports.COMPONENT_ACTION_NEW_OR_UPDATED = void 0;
const dynamodb_data_mapper_annotations_1 = require("@aws/dynamodb-data-mapper-annotations");
const dynamodb_data_mapper_1 = require("@aws/dynamodb-data-mapper");
const dynamodb_expressions_1 = require("@aws/dynamodb-expressions");
const aws_sdk_1 = require("aws-sdk");
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const config_1 = require("../utils/config");
const removeEmptyValues_1 = require("../utils/removeEmptyValues");
const storeInventoryUtils_1 = require("../service/storeInventoryUtils");
exports.COMPONENT_ACTION_NEW_OR_UPDATED = 1;
exports.COMPONENT_ACTION_REMOVED = 2;
const mapper = new dynamodb_data_mapper_1.DataMapper({ client: new aws_sdk_1.DynamoDB() });
const productsTableName = config_1.property('PRODUCTS_TABLE');
const displayItemGroupTableName = config_1.property('DISPLAY_ITEM_GROUP_TABLE');
const locationStoreMapping = config_1.property('MAP_LOCATION_WITH_STORE_ID_AND_ID') || '{}';
const skuTableName = config_1.property('SKU_TABLE');
let Sku = class Sku {
};
__decorate([
    dynamodb_data_mapper_annotations_1.hashKey({ type: 'String' }),
    __metadata("design:type", String)
], Sku.prototype, "productId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.rangeKey(),
    __metadata("design:type", String)
], Sku.prototype, "id", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Sku.prototype, "pimSkuId", void 0);
Sku = __decorate([
    dynamodb_data_mapper_annotations_1.table(skuTableName)
], Sku);
exports.Sku = Sku;
class DigitalAsset {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "mediaTag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "mediaVersion", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DigitalAsset.prototype, "url", void 0);
exports.DigitalAsset = DigitalAsset;
class Taxonomy {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Taxonomy.prototype, "code", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Taxonomy.prototype, "name", void 0);
exports.Taxonomy = Taxonomy;
class Designer {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "descriptionTitle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Designer.prototype, "description", void 0);
exports.Designer = Designer;
class Flags {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isGroup", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "belongsToGroup", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "preOrder", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "allowBackOrders", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "blockOrders", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "dynamicImageSkuColor", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isEditorial", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "isEvening", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "showMonogramLabel", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "previewSupported", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "storeOnly", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "exclusive", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "inStock", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "useSkuAsset", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "giftWrappableFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "perishableFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "dropshipFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "fedexEligibleFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "parenthetical", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Flags.prototype, "isOnlyAtNM", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Flags.prototype, "hasMoreColors", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Flags.prototype, "onSale", void 0);
exports.Flags = Flags;
class Color {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "key", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "pimKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Color.prototype, "pimCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Color.prototype, "facet", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Color.prototype, "default", void 0);
exports.Color = Color;
class Size {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "name", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "pimKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "pimCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Size.prototype, "key", void 0);
exports.Size = Size;
class Inventory {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Inventory.prototype, "status", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Inventory.prototype, "onHandStatus", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "qty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "purchaseOrderQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Inventory.prototype, "bossTotalQty", void 0);
exports.Inventory = Inventory;
class Shipping {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedDepthInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedHeightInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "boxedWidthInches", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Shipping.prototype, "deliveryDays", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Shipping.prototype, "shipFromStore", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Shipping.prototype, "expectedShipDate", void 0);
exports.Shipping = Shipping;
class StoreInventory {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "storeId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "storeNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], StoreInventory.prototype, "locationNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "quantity", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "bopsQuantity", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", typeof BigInt === "function" ? BigInt : Object)
], StoreInventory.prototype, "invLevel", void 0);
exports.StoreInventory = StoreInventory;
class Price {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Price.prototype, "retail", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Price.prototype, "original", void 0);
exports.Price = Price;
class SimpleProduct {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], SimpleProduct.prototype, "launchDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], SimpleProduct.prototype, "adornDate", void 0);
exports.SimpleProduct = SimpleProduct;
class Components {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Components.prototype, "componentLevel", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Components.prototype, "componentNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Components.prototype, "quantity", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Components.prototype, "componentSequence", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Components.prototype, "componentDepiction", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Components.prototype, "componentDepictionSequence", void 0);
exports.Components = Components;
let Product = class Product {
};
__decorate([
    dynamodb_data_mapper_annotations_1.hashKey({ type: 'String' }),
    __metadata("design:type", String)
], Product.prototype, "PartitionKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.rangeKey(),
    __metadata("design:type", String)
], Product.prototype, "SortKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "skuNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "skuSequenceNumber", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayItem", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayItemType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "variationId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "productId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Price) }),
    __metadata("design:type", Price)
], Product.prototype, "price", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Color) }),
    __metadata("design:type", Color)
], Product.prototype, "color", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Size) }),
    __metadata("design:type", Size)
], Product.prototype, "size", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Inventory) }),
    __metadata("design:type", Inventory)
], Product.prototype, "inventory", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(DigitalAsset) }),
    __metadata("design:type", Array)
], Product.prototype, "digitalAssets", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "hexValue", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "merchandiseType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "swatchPath", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Shipping) }),
    __metadata("design:type", Object)
], Product.prototype, "shipping", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "suggestedInterval", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "displayName", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "department", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "class", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Taxonomy) }),
    __metadata("design:type", Object)
], Product.prototype, "subclass", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Designer) }),
    __metadata("design:type", Object)
], Product.prototype, "designer", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "serviceLevelCodes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sellableDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "adornDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "launchDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "commodeCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "genderCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Flags) }),
    __metadata("design:type", Object)
], Product.prototype, "flags", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "shortDescription", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "longDescription", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "notes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosCatalogId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosItem", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "catalogType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "pimStyle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "parentheticalCharge", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "intlParentheticalAmount", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "displayable", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "canonicalUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "designerBoutiqueUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "hideInternationally", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "suppressCheckout", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sizeLabels", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "offline", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "liveTreeDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "restrictedStates", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "cmosSkuId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "codeUpc", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "discontinuedCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "vendorId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "iceFlag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(StoreInventory) }),
    __metadata("design:type", Array)
], Product.prototype, "storeInventories", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "onHandQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], Product.prototype, "onOrderQty", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "displayGroups", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "webProductIDs", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Object)
], Product.prototype, "psHierarchy", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Object)
], Product.prototype, "psAttributes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], Product.prototype, "componentsOf", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Product.prototype, "displayAsGroupEligible", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "sizeGuide", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Product.prototype, "webSkuId", void 0);
Product = __decorate([
    dynamodb_data_mapper_annotations_1.table(productsTableName)
], Product);
exports.Product = Product;
class Media {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Media.prototype, "id", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Media.prototype, "mediaTag", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Media.prototype, "mediaVersion", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Media.prototype, "url", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], Media.prototype, "productId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], Media.prototype, "dynamicImageSkuColor", void 0);
exports.Media = Media;
class ProductFlags {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "isOnlyAtNM", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "dynamicImageSkuColor", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "hasMoreColors", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "isNewArrival", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "isEditorial", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "isEvening", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "inLookBook", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "showMonogramLabel", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ProductFlags.prototype, "previewSupported", void 0);
exports.ProductFlags = ProductFlags;
class OriginTimestampInfo {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], OriginTimestampInfo.prototype, "ProductUpdated", void 0);
exports.OriginTimestampInfo = OriginTimestampInfo;
class FilterFacet {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], FilterFacet.prototype, "label", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], FilterFacet.prototype, "sortOrder", void 0);
exports.FilterFacet = FilterFacet;
class DataPoints {
}
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], DataPoints.prototype, "ProductId", void 0);
exports.DataPoints = DataPoints;
let ItemGroup = class ItemGroup {
    constructor(partitionKey) {
        this.PartitionKey = partitionKey || '';
    }
};
__decorate([
    dynamodb_data_mapper_annotations_1.hashKey({ type: 'String' }),
    __metadata("design:type", String)
], ItemGroup.prototype, "PartitionKey", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "productId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], ItemGroup.prototype, "childProductIds", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "description", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Media) }),
    __metadata("design:type", Array)
], ItemGroup.prototype, "media", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "displayName", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "notes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "help", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "sizeGuide", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "cmosCatalogId", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "cmosItem", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "merchandiseType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "catalogType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "pimStyle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "departmentDesc", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "classDesc", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "designerName", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "designerDescriptionTitle", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "designerDescription", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], ItemGroup.prototype, "parentheticalCharge", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Number)
], ItemGroup.prototype, "intlParentheticalAmount", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "personalShopper", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "exclusive", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "preOrder", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "displayable", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "dynamicImageSkuColor", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "canonicalUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "designerBoutiqueUrl", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], ItemGroup.prototype, "serviceLevelCodes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(ProductFlags) }),
    __metadata("design:type", ProductFlags)
], ItemGroup.prototype, "productFlags", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "hideInternationally", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "onSale", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "suppressCheckout", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "aliPay", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "parenthetical", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "departmentCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "commodeCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "classCode", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "metaInfo", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "codeSetType", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(FilterFacet) }),
    __metadata("design:type", Array)
], ItemGroup.prototype, "sizeLabels", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "offline", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(OriginTimestampInfo) }),
    __metadata("design:type", OriginTimestampInfo)
], ItemGroup.prototype, "originTimestampInfo", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "sellableDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "liveTreeDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "adornDate", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Boolean)
], ItemGroup.prototype, "isBvd", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "restrictedStates", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", String)
], ItemGroup.prototype, "restrictedCodes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], ItemGroup.prototype, "hierarchy", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute(),
    __metadata("design:type", Array)
], ItemGroup.prototype, "attributes", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(DataPoints) }),
    __metadata("design:type", DataPoints)
], ItemGroup.prototype, "dataPoints", void 0);
__decorate([
    dynamodb_data_mapper_annotations_1.attribute({ memberType: dynamodb_data_mapper_1.embed(Components) }),
    __metadata("design:type", Array)
], ItemGroup.prototype, "components", void 0);
ItemGroup = __decorate([
    dynamodb_data_mapper_annotations_1.table(displayItemGroupTableName),
    __metadata("design:paramtypes", [String])
], ItemGroup);
exports.ItemGroup = ItemGroup;
exports.saveProduct = async (message) => {
    logger_1.default.info(`Saving Product: ${JSON.stringify(Object.assign(new Product(), removeEmptyValues_1.removeEmptyValues(message)))}`);
    try {
        await mapper.update(Object.assign(new Product(), removeEmptyValues_1.removeEmptyValues(message)));
        logger_1.default.info('Product was saved');
    }
    catch (error) {
        logger_1.default.error({
            message: `Error persisting Product ${JSON.stringify(message)}, errorMessage: ${error}`,
        });
        throw error;
    }
};
exports.saveItemGroups = async (message) => {
    logger_1.default.info(`Saving Display Item Groups: ${JSON.stringify(message)}`);
    try {
        await mapper.put(Object.assign(new ItemGroup(), removeEmptyValues_1.removeEmptyValues(message)));
        logger_1.default.info('Display Item Groups was saved..');
    }
    catch (error) {
        logger_1.default.error({
            message: `Error persisting Display Item Groups ${JSON.stringify(message)}, errorMessage: ${error}`,
        });
        throw error;
    }
};
exports.getItemGroups = async (suiteNumber) => {
    logger_1.default.debug({ message: 'querying Db for sutte', suiteNumber });
    const iterator = mapper.query(ItemGroup, { PartitionKey: suiteNumber });
    const itemGroups = [];
    for await (const record of iterator) {
        itemGroups.push(record);
    }
    return Promise.resolve(itemGroups);
};
exports.getParentGroupIds = async (components) => {
    logger_1.default.info({ message: 'querying Db for suite', components });
    const itemGrpList = [];
    const parentGroupIds = [];
    for (const component of components) {
        itemGrpList.push(new ItemGroup(component));
    }
    for await (const item of mapper.batchGet(itemGrpList)) {
        if (item) {
            parentGroupIds.push(item.productId);
        }
    }
    return Promise.resolve(parentGroupIds);
};
exports.findRemovedComponentsFromTheUpdateMessage = async (suiteNumber, newComponents) => {
    const suiteProduct = await exports.getItemGroups(suiteNumber);
    logger_1.default.info({ findRemovedComponentsFromTheUpdateMessage: suiteNumber });
    if (suiteProduct && suiteProduct.length) {
        const existingComponents = suiteProduct[0].components;
        logger_1.default.info({ findRemovedComponentsFromTheUpdateMessage: existingComponents });
        if (existingComponents && existingComponents.length) {
            return existingComponents.filter(function (obj) {
                return !newComponents.some(function (obj2) {
                    return obj.componentLevel === obj2.componentLevel && obj.componentNumber === obj2.componentNumber;
                });
            });
        }
    }
    return null;
};
exports.getDisplayItems = async (components) => {
    const products = [];
    for (const component of components) {
        if ((component === null || component === void 0 ? void 0 : component.componentLevel) === 'ITEM') {
            const iterator = mapper.query(Product, { PartitionKey: `${component === null || component === void 0 ? void 0 : component.componentNumber}` });
            for await (const record of iterator) {
                products.push(record);
            }
        }
        else if ((component === null || component === void 0 ? void 0 : component.componentLevel) === 'VARIATION') {
            const iterator = mapper.query(Product, { variationId: `${component === null || component === void 0 ? void 0 : component.componentNumber}` }, { indexName: 'VariationIdIndex' });
            for await (const record of iterator) {
                products.push(record);
            }
        }
        else if ((component === null || component === void 0 ? void 0 : component.componentLevel) === 'SKU') {
            const iterator = mapper.query(Product, { skuNumber: `${component === null || component === void 0 ? void 0 : component.componentNumber}` }, { indexName: 'SkuNumberIndex' });
            for await (const record of iterator) {
                products.push(record);
            }
        }
    }
    return Promise.all(products);
};
exports.updateDisplayItems = async (products, suiteNumber, action) => {
    logger_1.default.debug({ message: "updating display item with suite number", suiteNumber });
    const productPromiseList = [];
    for (const product of products) {
        const displayGroup = product.displayGroups || [];
        if (action === exports.COMPONENT_ACTION_REMOVED) {
            const index = displayGroup.indexOf(suiteNumber);
            if (index >= 0) {
                displayGroup.splice(index, 1);
            }
        }
        else if (!displayGroup.includes(suiteNumber)) {
            displayGroup.push(suiteNumber);
        }
        product.displayGroups = displayGroup;
        const expression = new dynamodb_expressions_1.UpdateExpression();
        expression.set(new dynamodb_expressions_1.AttributePath('displayGroups'), displayGroup);
        const toUpdate = new Product();
        toUpdate.PartitionKey = product.PartitionKey;
        toUpdate.SortKey = product.SortKey;
        logger_1.default.debug({ message: "Product to be updated ", product: toUpdate, displayGroup: JSON.stringify(displayGroup) });
        productPromiseList.push(mapper.executeUpdateExpression(expression, toUpdate, Product));
    }
    return Promise.all(productPromiseList);
};
exports.updateStoreInventory = async (message) => {
    const inv = storeInventoryUtils_1.mapStoreInventories(message);
    const store = JSON.parse(locationStoreMapping).store[inv.locationNumber];
    if (store) {
        inv.storeId = store.id;
        inv.storeNumber = store.sn;
    }
    else {
        logger_1.default.warn({ "missing-ssm-location-store-mapping": inv.locationNumber });
    }
    const products = await exports.getProducts(message.ItemId);
    const productPromiseList = [];
    if (products && products.length) {
        let invList = products[0].storeInventories;
        if (invList && invList.length) {
            invList = invList.filter((inv) => inv.locationNumber !== message.LocationId);
        }
        else {
            invList = [];
        }
        invList.push(inv);
        const expression = new dynamodb_expressions_1.UpdateExpression();
        expression.set(new dynamodb_expressions_1.AttributePath('storeInventories'), invList);
        const toUpdate = new Product();
        toUpdate.PartitionKey = products[0].PartitionKey;
        toUpdate.SortKey = products[0].SortKey;
        productPromiseList.push(mapper.executeUpdateExpression(expression, toUpdate, Product));
        logger_1.default.info({ storeInvUpdate: 'store-inv-update', style: toUpdate, newInvValue: inv });
    }
    return Promise.all(productPromiseList);
};
exports.getProducts = async (skuNum) => {
    logger_1.default.debug({ message: 'querying  for  sku', skuNum });
    const iterator = mapper.query(Product, { skuNumber: skuNum }, { indexName: 'SkuNumberIndex' });
    const products = [];
    for await (const record of iterator) {
        products.push(record);
    }
    logger_1.default.info({ storeInvMessage: `(${products.length}) products fetched for sku ${skuNum}` });
    return Promise.resolve(products);
};
exports.findAtgSkuId = async (prodId, skuNumber) => {
    if (prodId) {
        const iterator = mapper.query(Sku, { productId: prodId });
        for await (const record of iterator) {
            if ((record === null || record === void 0 ? void 0 : record.pimSkuId) === skuNumber && record.id !== skuNumber) {
                logger_1.default.info({ webSkuIdForSkuNum: record === null || record === void 0 ? void 0 : record.pimSkuId, skuNum: skuNumber });
                return Promise.resolve(record.id);
            }
        }
    }
    return Promise.resolve(skuNumber);
};
//# sourceMappingURL=dynamoMessages.js.map