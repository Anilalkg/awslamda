"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveStoreInventoryMessage = exports.saveItemGroupMessage = exports.saveProductHubMessage = void 0;
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const config_1 = require("../utils/config");
const utils_1 = require("./utils");
const dynamoMessages_1 = require("../storage/dynamoMessages");
const storeFrontUtils_1 = require("./storeFrontUtils");
const USE_ATG_PRODUCT_ID = process.env.USE_ATG_PRODUCT_ID || true;
const currentBrand = config_1.property('BRAND');
exports.saveProductHubMessage = async (message) => {
    try {
        const { pal } = message;
        const dynamoMessage = await utils_1.mapPalToProduct(pal, storeFrontUtils_1.brandsAbbrMappings[currentBrand], USE_ATG_PRODUCT_ID);
        if (dynamoMessage && dynamoMessage.forceWebPublish) {
            await dynamoMessages_1.saveProduct(dynamoMessage);
        }
        else if (!dynamoMessage.forceWebPublish) {
            logger_1.default.warn({ style: dynamoMessage.PartitionKey, ignoreMessage: true, forceWebPublish: 'Not-True' });
        }
        return dynamoMessage;
    }
    catch (error) {
        logger_1.default.error({
            message: `Error saving ProductHubMessage ${JSON.stringify(message)}, errorMessage: ${error}`,
        });
        throw error;
    }
};
exports.saveItemGroupMessage = async (message) => {
    try {
        const data = message.pal.suite;
        const { digitalAssets } = message.pal;
        const dynamoMessage = await utils_1.mapDisplayItemGroups(data, digitalAssets, storeFrontUtils_1.brandsAbbrMappings[currentBrand], USE_ATG_PRODUCT_ID);
        if (dynamoMessage) {
            const componentsRemoved = await dynamoMessages_1.findRemovedComponentsFromTheUpdateMessage(data === null || data === void 0 ? void 0 : data.suiteNumber, data === null || data === void 0 ? void 0 : data.components);
            const displayItems = await dynamoMessages_1.getDisplayItems(data === null || data === void 0 ? void 0 : data.components);
            if (displayItems && displayItems.length) {
                dynamoMessage.childProductIds = [...new Set(displayItems.map(obj => obj.productId))];
            }
            else {
                dynamoMessage.childProductIds = [];
            }
            await dynamoMessages_1.saveItemGroups(dynamoMessage);
            await dynamoMessages_1.updateDisplayItems(displayItems, dynamoMessage === null || dynamoMessage === void 0 ? void 0 : dynamoMessage.productId, dynamoMessages_1.COMPONENT_ACTION_NEW_OR_UPDATED);
            if (componentsRemoved && componentsRemoved.length) {
                const displayItems1 = await dynamoMessages_1.getDisplayItems(componentsRemoved);
                logger_1.default.info({ componentRemoved: `These components ${JSON.stringify(componentsRemoved)} removed for suite ${data === null || data === void 0 ? void 0 : data.suiteNumber} - ${dynamoMessage === null || dynamoMessage === void 0 ? void 0 : dynamoMessage.productId}, so updating child product(s) displayGroup` });
                await dynamoMessages_1.updateDisplayItems(displayItems1, dynamoMessage === null || dynamoMessage === void 0 ? void 0 : dynamoMessage.productId, dynamoMessages_1.COMPONENT_ACTION_REMOVED);
            }
        }
        return dynamoMessage;
    }
    catch (error) {
        logger_1.default.error({
            message: `error-save-item-group-message ${JSON.stringify(message)}, errorMessage: ${error}`,
        });
        throw error;
    }
};
exports.saveStoreInventoryMessage = async (message) => {
    try {
        const data = message;
        logger_1.default.debug({ invData: data });
        await dynamoMessages_1.updateStoreInventory(data);
    }
    catch (error) {
        logger_1.default.error({
            message: `error-save-location-message ${JSON.stringify(message)}, errorMessage: ${error}`,
        });
        throw error;
    }
};
//# sourceMappingURL=productHubService.js.map