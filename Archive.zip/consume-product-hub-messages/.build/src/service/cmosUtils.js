"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapCmosItem = exports.mapCmosCatalogId = exports.getCmosByStyleId = void 0;
const config_1 = require("../utils/config");
const currentBrand = config_1.property('BRAND');
exports.getCmosByStyleId = (pal, styleId) => {
    var _a;
    const iPalCmos = (_a = pal.cmos) === null || _a === void 0 ? void 0 : _a.find((cmosStyle) => Object.keys(cmosStyle).includes(styleId));
    return iPalCmos ? iPalCmos[styleId] : null;
};
exports.mapCmosCatalogId = (pal) => {
    var _a;
    const cmos = (_a = exports.getCmosByStyleId(pal, pal.style.itemNumber)) === null || _a === void 0 ? void 0 : _a[0].storeFronts;
    const storeFront = cmos === null || cmos === void 0 ? void 0 : cmos.find((el) => el.storeFrontID === currentBrand);
    if (!storeFront)
        return null;
    switch (currentBrand) {
        case 'NM':
            return storeFront.NMOfferItemId;
        case 'BG':
            return storeFront.BGOfferItemId;
        case 'HC':
            return storeFront.HCOfferItemId;
        default:
            return null;
    }
};
exports.mapCmosItem = (pal, brand) => { var _a, _b, _c, _d; return (_d = (_c = (_b = (_a = pal.variation) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.webProduct) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.webDepiction; };
//# sourceMappingURL=cmosUtils.js.map