"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPSAttributes = exports.mapHierarchy = exports.mapProductSizeGuide = exports.mapProductId = exports.mapWebProductIds = exports.mapGenderCode = exports.mapCommodeCode = exports.mapVendorId = exports.mapCodeUpc = exports.mapCanonicalUrl = exports.mapIntlParentheticalAmount = exports.mapParentheticalCharge = exports.mapPimStyle = exports.mapNotes = exports.mapLongDescription = exports.mapShortDescription = exports.mapVariationId = exports.mapIceFlag = exports.mapDiscontinuedCode = exports.mapCmosSkuId = exports.mapLiveTreeDate = exports.mapOffline = exports.mapSizeLabels = exports.mapSuppressCheckout = exports.mapDesignerBoutiqueUrl = exports.mapDisplayable = exports.mapCatalogType = exports.mapRestrictedStates = exports.mapHideInternationally = exports.mapAdornDate = exports.mapLaunchDate = exports.mapFlags = exports.mapSellableDate = exports.mapServiceLevelCodes = exports.mapDesigner = exports.mapTaxonomyByLevelName = exports.mapDisplayName = exports.mapDisplayItem = void 0;
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const config_1 = require("../utils/config");
const cmosUtils_1 = require("./cmosUtils");
const priceUtils_1 = require("./priceUtils");
const storeFrontUtils_1 = require("./storeFrontUtils");
const digitalAssetsUtils_1 = require("./digitalAssetsUtils");
const skuDetailsUtils_1 = require("./skuDetailsUtils");
const deptCodesForEveWear = config_1.property('DEPT_CODES_FOR_EVE_WEAR');
const classCodeForEveWear = config_1.property('CLASS_CODES_FOR_EVE_WEAR');
const catalogType = config_1.property('UNRESOLVED_CATALOG_TYPE');
const isOnlyAtNM = config_1.property('UNRESOLVED_IS_ONLY_AT_NM');
const hasMoreColors = config_1.property('UNRESOLVED_HAS_MORE_COLORS');
const suppressCheckout = config_1.property('UNRESOLVED_SUPRESS_CHECKOUT');
const cmosSkuId = config_1.property('CMOS_SKU_ID');
const iceFlag = config_1.property('UNRESOLVED_CMOS_SKU_IICE_FLAGD');
const USE_ATG_PRODUCT_ID = process.env.USE_ATG_PRODUCT_ID || true;
const mapDisplayItem = (pal, brand) => {
    const price = priceUtils_1.mapPrice(pal, brand);
    return `${pal.style.itemNumber}#${Number((price === null || price === void 0 ? void 0 : price.retail) || 0)}`;
};
exports.mapDisplayItem = mapDisplayItem;
const mapProductId = (pal, brand) => {
    if (USE_ATG_PRODUCT_ID === "false") {
        return mapDisplayItem(pal, brand);
    }
    const productIdList = mapWebProductIds(pal, brand);
    if (Array.isArray(productIdList) && productIdList.length) {
        return productIdList[0];
    }
    return null;
};
exports.mapProductId = mapProductId;
const mapDisplayName = (pal) => pal.style.copyTitle;
exports.mapDisplayName = mapDisplayName;
const mapTaxonomyByLevelName = (pal, levelName) => {
    var _a;
    const taxonomy = pal.taxonomies.find((el) => el.levelName === levelName);
    return {
        code: (_a = taxonomy.code) === null || _a === void 0 ? void 0 : _a.split('-').pop(),
        name: taxonomy.name,
    };
};
exports.mapTaxonomyByLevelName = mapTaxonomyByLevelName;
const mapDesigner = (pal) => {
    var _a, _b, _c, _d, _e, _f;
    return ({
        name: (_b = (_a = pal.style) === null || _a === void 0 ? void 0 : _a.brandAdvertised) === null || _b === void 0 ? void 0 : _b.name,
        descriptionTitle: null,
        description: (_f = (_e = (_d = (_c = pal.style) === null || _c === void 0 ? void 0 : _c.brandAdvertised) === null || _d === void 0 ? void 0 : _d.copyBrandBio) === null || _e === void 0 ? void 0 : _e.replace(/<html>/g, '')) === null || _f === void 0 ? void 0 : _f.replace(/<\/html>/g, '')
    });
};
exports.mapDesigner = mapDesigner;
const mapServiceLevelCodes = (pal) => {
    return pal.sku.eligibleServiceLevels;
};
exports.mapServiceLevelCodes = mapServiceLevelCodes;
const mapSellableDate = (pal, brand) => { var _a; return (_a = pal.variation.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.launchDate; };
exports.mapSellableDate = mapSellableDate;
const mapLaunchDate = (pal, brand) => { var _a; return (_a = pal.variation.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.launchDate; };
exports.mapLaunchDate = mapLaunchDate;
const mapAdornDate = (pal, brand) => { var _a; return (_a = pal.variation.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.adornDate; };
exports.mapAdornDate = mapAdornDate;
const mapHideInternationally = (pal) => pal.style.invalidCountryGroup.findIndex((el) => el.countryAndState === 'ALL' && el.countryAndStateBlockFlag) !== -1;
exports.mapHideInternationally = mapHideInternationally;
const mapRestrictedStates = (pal) => {
    const blockedStates = pal.style.invalidCountryGroup.filter((el) => el.countryAndStateBlockFlag && el.countryAndState.includes('USA-'));
    return blockedStates.map((el) => el.countryAndState).join(',');
};
exports.mapRestrictedStates = mapRestrictedStates;
const mapOnSale = (pal, brand) => {
    var _a, _b, _c;
    const zone = storeFrontUtils_1.zonesMappings[brand];
    const pricing = (_c = (_b = (_a = pal.sku) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.pricing) === null || _c === void 0 ? void 0 : _c[zone];
    return (!!pricing && !!((pricing === null || pricing === void 0 ? void 0 : pricing.clearanceRetail) || (pricing === null || pricing === void 0 ? void 0 : pricing.promotionRetail)));
};
const mapCatalogType = () => catalogType;
exports.mapCatalogType = mapCatalogType;
const mapDisplayable = (pal, brand) => {
    const discontinuedCode = mapDiscontinuedCode(pal, brand);
    logger_1.default.debug({ method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, discontinuedCode });
    if (discontinuedCode === 'V' || discontinuedCode === 'W') {
        return false;
    }
    const price = priceUtils_1.mapPrice(pal, brand);
    logger_1.default.debug({ method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, price });
    if (!(price && ((price === null || price === void 0 ? void 0 : price.original) > 0 || (price === null || price === void 0 ? void 0 : price.retail) > 0))) {
        return false;
    }
    const inventory = skuDetailsUtils_1.mapInventory(pal, brand);
    logger_1.default.debug({ method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, inventory });
    if (inventory && (inventory === null || inventory === void 0 ? void 0 : inventory.qty) <= 0) {
        return false;
    }
    const digitalAssets = digitalAssetsUtils_1.mapDigitalAssets(pal, brand);
    logger_1.default.debug({ method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, digitalAssets });
    if (!(digitalAssets && digitalAssets.filter(image => image.mediaTag === 'm0').length > 0)) {
        logger_1.default.debug({ method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, missingM0Asset: "Missing m0 asset" });
        return false;
    }
    return true;
};
exports.mapDisplayable = mapDisplayable;
const mapProductSizeGuide = (pal, brand) => {
    var _a, _b, _c, _d, _e;
    if ((_a = pal === null || pal === void 0 ? void 0 : pal.style) === null || _a === void 0 ? void 0 : _a.copyLegacyFlag) {
        return (_c = (_b = pal.style) === null || _b === void 0 ? void 0 : _b.storeFronts[brand]) === null || _c === void 0 ? void 0 : _c.legacyCopySizeGuide;
    }
    return (_e = (_d = pal.style) === null || _d === void 0 ? void 0 : _d.storeFronts[brand]) === null || _e === void 0 ? void 0 : _e.copySizeGuide;
};
exports.mapProductSizeGuide = mapProductSizeGuide;
const mapDesignerBoutiqueUrl = (cm4Data) => (cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.designerBoutiqueUrl) || '';
exports.mapDesignerBoutiqueUrl = mapDesignerBoutiqueUrl;
const mapSuppressCheckout = () => suppressCheckout;
exports.mapSuppressCheckout = mapSuppressCheckout;
const mapSizeLabels = (cm4Data) => { var _a; return ((_a = cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.attributes) === null || _a === void 0 ? void 0 : _a.SizeLabels) || []; };
exports.mapSizeLabels = mapSizeLabels;
const mapOffline = (cm4Data) => !!(cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.offline);
exports.mapOffline = mapOffline;
const mapLiveTreeDate = (cm4Data) => (cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.liveTreeDate) || '';
exports.mapLiveTreeDate = mapLiveTreeDate;
const mapHierarchy = (cm4Data) => (cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.hierarchy) || [];
exports.mapHierarchy = mapHierarchy;
const mapCmosSkuId = () => cmosSkuId;
exports.mapCmosSkuId = mapCmosSkuId;
const mapDiscontinuedCode = (pal, brand) => {
    var _a, _b, _c, _d, _e;
    if ((_b = (_a = pal.sku) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.blockOrders) {
        return 'V';
    }
    const strLaunchDate = (_d = (_c = pal.variation) === null || _c === void 0 ? void 0 : _c.storeFronts[brand]) === null || _d === void 0 ? void 0 : _d.launchDate;
    if (strLaunchDate) {
        const launchDate = new Date(strLaunchDate);
        const now = new Date();
        if (launchDate > now) {
            return 'W';
        }
    }
    if ((_e = pal.sku.storeFronts[brand]) === null || _e === void 0 ? void 0 : _e.allowBackorders) {
        return 'N';
    }
    return 'Y';
};
exports.mapDiscontinuedCode = mapDiscontinuedCode;
const mapIceFlag = (pal) => {
    var _a, _b;
    const result = (_b = (_a = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _a === void 0 ? void 0 : _a.vendors) === null || _b === void 0 ? void 0 : _b.find((vendor) => {
        var _a;
        return (_a = vendor === null || vendor === void 0 ? void 0 : vendor.skuVendorPartNumbers) === null || _a === void 0 ? void 0 : _a.find((partNUmber) => {
            return partNUmber === null || partNUmber === void 0 ? void 0 : partNUmber.vendorPartNumber.startsWith("IC");
        });
    });
    if (result) {
        logger_1.default.debug({ iceflag: "true" });
        return "true";
    }
    logger_1.default.debug({ iceflag: "false" });
    return "false";
};
exports.mapIceFlag = mapIceFlag;
const mapIsEvening = (pal, departmentCode, classCode) => deptCodesForEveWear.includes(departmentCode) && classCodeForEveWear.includes(classCode);
const mapVariationId = (pal) => pal.variation.variationNumber;
exports.mapVariationId = mapVariationId;
const mapShortDescription = (pal) => { var _a; return (_a = pal.style) === null || _a === void 0 ? void 0 : _a.shortDescription; };
exports.mapShortDescription = mapShortDescription;
const mapLongDescription = (pal) => {
    var _a, _b, _c;
    let desc = ((_a = pal.style) === null || _a === void 0 ? void 0 : _a.copyLegacyFlag) ? ((_b = pal.style) === null || _b === void 0 ? void 0 : _b.legacyCopyBlock) || '' : ((_c = pal.style) === null || _c === void 0 ? void 0 : _c.copyBlock) || '';
    desc = desc.replace(/[\r\n\t]/g, ' ');
    return desc;
};
exports.mapLongDescription = mapLongDescription;
const mapNotes = (pal, brand) => { var _a, _b; return (_b = (_a = pal.style) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.cutlineSuiteBottom; };
exports.mapNotes = mapNotes;
const mapPimStyle = (pal) => { var _a; return (_a = pal.style) === null || _a === void 0 ? void 0 : _a.itemNumber; };
exports.mapPimStyle = mapPimStyle;
const mapParentheticalCharge = (pal, brand) => { var _a, _b, _c, _d, _e; return (_e = (_d = (_c = (_b = (_a = pal.variation) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.webProduct) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.parentheticalCharge) === null || _e === void 0 ? void 0 : _e.toString(); };
exports.mapParentheticalCharge = mapParentheticalCharge;
const mapIntlParentheticalAmount = (pal, brand) => { var _a, _b, _c, _d; return (_d = (_c = (_b = (_a = pal.variation) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.webProduct) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.intlParentheticalAmount; };
exports.mapIntlParentheticalAmount = mapIntlParentheticalAmount;
const mapCanonicalUrl = (pal, displayName, productId) => {
    var _a, _b;
    let formattedDisplayName = displayName || '';
    formattedDisplayName = formattedDisplayName.toLocaleLowerCase();
    formattedDisplayName = formattedDisplayName.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    formattedDisplayName = formattedDisplayName.replace(/\u00E6/g, '');
    formattedDisplayName = formattedDisplayName.replace(/\./g, '-');
    formattedDisplayName = formattedDisplayName.replace(/<.*?>/, '');
    formattedDisplayName = formattedDisplayName.replace(/&.*?;/, '');
    formattedDisplayName = formattedDisplayName.replace(/'/g, '');
    formattedDisplayName = formattedDisplayName.replace(/[^a-zA-Z0-9]+/g, '-');
    let formattedDesignerName = ((_b = (_a = pal === null || pal === void 0 ? void 0 : pal.style) === null || _a === void 0 ? void 0 : _a.brandAdvertised) === null || _b === void 0 ? void 0 : _b.name) || '';
    formattedDesignerName = formattedDesignerName.toLocaleLowerCase();
    formattedDesignerName = formattedDesignerName.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    formattedDesignerName = formattedDesignerName.replace(/\u00E6/g, '');
    formattedDesignerName = formattedDesignerName.replace(/\./g, '-');
    formattedDesignerName = formattedDesignerName.replace(/<.*?>/, '');
    formattedDesignerName = formattedDesignerName.replace(/&.*?;/, '');
    formattedDesignerName = formattedDesignerName.replace(/'/g, '');
    formattedDesignerName = formattedDesignerName.replace(/[^a-zA-Z0-9]+/g, '-');
    return `/p/${formattedDesignerName}-${formattedDisplayName}-${productId}`;
};
exports.mapCanonicalUrl = mapCanonicalUrl;
const mapWebProductIds = (pal, brand) => {
    var _a, _b;
    const webProducts = (_b = (_a = pal.variation) === null || _a === void 0 ? void 0 : _a.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.webProduct;
    if (!Array.isArray(webProducts) || !webProducts.length) {
        return null;
    }
    const webProductIds = webProducts.map(webProduct => {
        return webProduct.webProductID;
    });
    return webProductIds;
};
exports.mapWebProductIds = mapWebProductIds;
const mapFlags = (pal, brand, departmentCode, classCode, inventory) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
    const isGroup = pal.style.productSetType;
    const belongsToGroup = !!((_a = pal.style.componentOf) === null || _a === void 0 ? void 0 : _a.length);
    const preOrder = (_b = pal.variation.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.preOrderFlag;
    const allowBackOrders = (_c = pal.sku.storeFronts[brand]) === null || _c === void 0 ? void 0 : _c.allowBackorders;
    const blockOrders = (_d = pal.sku.storeFronts[brand]) === null || _d === void 0 ? void 0 : _d.blockOrders;
    const dynamicImageSkuColor = ((_e = pal.sku.colorId) === null || _e === void 0 ? void 0 : _e.name) !== 'NO COLOR' && digitalAssetsUtils_1.mapDigitalAssets(pal, brand).length > 0;
    const isEditorial = (_f = pal.style.storeFronts[brand]) === null || _f === void 0 ? void 0 : _f.editorialItemSetFlag;
    const isEvening = mapIsEvening(pal, departmentCode, classCode);
    const showMonogramLabel = pal.style.personalizationType.name !== 'Not Personalized';
    const previewSupported = !!((_g = pal.style.personalizationInstructions) === null || _g === void 0 ? void 0 : _g.length);
    const storeOnly = (_h = pal.style.storeFronts[storeFrontUtils_1.storeFrontsMappings[brand]]) === null || _h === void 0 ? void 0 : _h.storeOnly;
    const exclusive = (_k = (_j = pal === null || pal === void 0 ? void 0 : pal.variation) === null || _j === void 0 ? void 0 : _j.storeFronts[brand]) === null || _k === void 0 ? void 0 : _k.exclusiveFlag;
    const inStock = (inventory === null || inventory === void 0 ? void 0 : inventory.status) === 'AVAILABLE' && (inventory === null || inventory === void 0 ? void 0 : inventory.purchaseOrderQty) > 0;
    const useSkuAsset = ((_l = pal.sku.colorId) === null || _l === void 0 ? void 0 : _l.name) !== 'NO COLOR' && ((_p = (_o = (_m = pal === null || pal === void 0 ? void 0 : pal.digitalAssets) === null || _m === void 0 ? void 0 : _m[0]) === null || _o === void 0 ? void 0 : _o.storeFronts[brand]) === null || _p === void 0 ? void 0 : _p.imageClUrl) !== null;
    const giftWrappableFlag = pal.style.giftWrapFlag;
    const perishableFlag = pal.style.perishableFlag || null;
    const dropshipFlag = pal.style.dropshipFlag;
    const fedexEligibleFlag = ((_q = cmosUtils_1.getCmosByStyleId(pal, pal.style.itemNumber)) === null || _q === void 0 ? void 0 : _q.fedexHalEligibleFlag) || null;
    const parenthetical = parseInt((_u = (_t = (_s = (_r = pal.variation) === null || _r === void 0 ? void 0 : _r.storeFronts[brand]) === null || _s === void 0 ? void 0 : _s.webProduct) === null || _t === void 0 ? void 0 : _t[0]) === null || _u === void 0 ? void 0 : _u.parentheticalCharge, 10) > 0;
    const onSale = mapOnSale(pal, brand);
    return {
        isGroup,
        belongsToGroup,
        preOrder,
        allowBackOrders,
        blockOrders,
        dynamicImageSkuColor,
        isEditorial,
        isEvening,
        showMonogramLabel,
        previewSupported,
        storeOnly,
        exclusive,
        inStock,
        useSkuAsset,
        giftWrappableFlag,
        perishableFlag,
        dropshipFlag,
        fedexEligibleFlag,
        parenthetical,
        isOnlyAtNM,
        hasMoreColors,
        onSale,
    };
};
exports.mapFlags = mapFlags;
const mapCodeUpc = (pal) => {
    var _a, _b;
    return (_b = (_a = pal.sku.upcs) === null || _a === void 0 ? void 0 : _a.find((upc) => upc.primaryRmsUpc)) === null || _b === void 0 ? void 0 : _b.nmgUpcCode;
};
exports.mapCodeUpc = mapCodeUpc;
const mapVendorId = (pal) => {
    var _a;
    return (_a = pal.style.vendors) === null || _a === void 0 ? void 0 : _a[0].locations.find((el) => el.primary).locationNumber;
};
exports.mapVendorId = mapVendorId;
const mapCommodeCode = (pal) => { var _a, _b; return (_b = (_a = pal.style) === null || _a === void 0 ? void 0 : _a.taxCategoryId) === null || _b === void 0 ? void 0 : _b.taxSystem2Code; };
exports.mapCommodeCode = mapCommodeCode;
const mapGenderCode = (pal) => { var _a, _b; return (_b = (_a = pal.style) === null || _a === void 0 ? void 0 : _a.gender) === null || _b === void 0 ? void 0 : _b.code; };
exports.mapGenderCode = mapGenderCode;
const mapPSAttributes = (cm4Data) => {
    var _a;
    (_a = cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.attributes) === null || _a === void 0 ? true : delete _a.SizeLabels;
    return (cm4Data === null || cm4Data === void 0 ? void 0 : cm4Data.attributes) || {};
};
exports.mapPSAttributes = mapPSAttributes;
//# sourceMappingURL=productDetailsUtils.js.map