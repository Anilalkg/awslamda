import { IProductHubPal } from "../models/pal";
import { IProductDigitalAsset } from "../models/productHubMessage";
declare const mapDigitalAssets: (pal: IProductHubPal, brand: string) => IProductDigitalAsset[];
export { mapDigitalAssets };
