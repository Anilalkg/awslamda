"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapDigitalAssets = void 0;
const mapDigitalAssets = (pal, brand) => pal.digitalAssets.reduce((result, palDigitalAsset) => {
    var _a;
    if (palDigitalAsset.storeFronts[brand]) {
        const mediaTag = (_a = palDigitalAsset.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.imageShotType;
        let url = palDigitalAsset.storeFronts[brand].imageClUrl || '';
        if (url && !url.startsWith('//')) {
            url = `//${url}`;
        }
        result.push({
            mediaTag: (mediaTag === null || mediaTag === void 0 ? void 0 : mediaTag.length) === 1 ? `${mediaTag}0` : mediaTag,
            mediaVersion: palDigitalAsset.assetName.publicationCount || '1',
            url,
        });
    }
    return result;
}, []);
exports.mapDigitalAssets = mapDigitalAssets;
//# sourceMappingURL=digitalAssetsUtils.js.map