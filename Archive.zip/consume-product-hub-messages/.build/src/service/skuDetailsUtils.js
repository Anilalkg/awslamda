"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapSeasonDeliveryCode = exports.mapSuggestedInterval = exports.mapShipping = exports.mapSwatchPath = exports.mapImageClUrl = exports.mapHexValue = exports.mapSize = exports.mapColor = exports.mapInventory = exports.mapSkuSequenceNumber = exports.mapSkuNumber = void 0;
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const config_1 = require("../utils/config");
const dynamoMessages_1 = require("../storage/dynamoMessages");
const shipFromStore = config_1.property('UNRESOLVED_SHIP_FROM_STORE');
const expectedShipDate = config_1.property('UNRESOLVED_EXPECTED_SHIP_DATE');
const bossTotalQty = 0;
const mapSkuNumber = async (pal, productId, useAtgId) => {
    logger_1.default.info({ useAtgId });
    if (useAtgId === 'false') {
        return Promise.resolve(pal.sku.skuNumber);
    }
    return dynamoMessages_1.findAtgSkuId(productId, pal.sku.skuNumber);
};
exports.mapSkuNumber = mapSkuNumber;
const mapColorFacet = (pal) => {
    var _a, _b, _c, _d, _e;
    if (!((_b = (_a = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _a === void 0 ? void 0 : _a.colorId) === null || _b === void 0 ? void 0 : _b.webFacet)) {
        return [];
    }
    return (_e = (_d = (_c = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _c === void 0 ? void 0 : _c.colorId) === null || _d === void 0 ? void 0 : _d.webFacet) === null || _e === void 0 ? void 0 : _e.map(facet => facet === null || facet === void 0 ? void 0 : facet.name);
};
const mapSkuSequenceNumber = (pal) => 1;
exports.mapSkuSequenceNumber = mapSkuSequenceNumber;
const mapInventory = (pal, storeFront) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    return ({
        status: (_b = (_a = pal.sku.storeFronts[storeFront]) === null || _a === void 0 ? void 0 : _a.inventory) === null || _b === void 0 ? void 0 : _b.status,
        onHandStatus: (_d = (_c = pal.sku.storeFronts[storeFront]) === null || _c === void 0 ? void 0 : _c.inventory) === null || _d === void 0 ? void 0 : _d.onHandStatus,
        qty: ((_f = (_e = pal.sku.storeFronts[storeFront]) === null || _e === void 0 ? void 0 : _e.inventory) === null || _f === void 0 ? void 0 : _f.totalQuantity) || 0,
        purchaseOrderQty: ((_h = (_g = pal.sku.storeFronts[storeFront]) === null || _g === void 0 ? void 0 : _g.inventory) === null || _h === void 0 ? void 0 : _h.futureQuantity) || 0,
        bossTotalQty,
    });
};
exports.mapInventory = mapInventory;
const mapColor = (pal, brand) => {
    var _a, _b, _c, _d, _e, _f;
    return ({
        name: (_b = (_a = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _a === void 0 ? void 0 : _a.colorId) === null || _b === void 0 ? void 0 : _b.name,
        pimKey: String((_d = (_c = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _c === void 0 ? void 0 : _c.colorId) === null || _d === void 0 ? void 0 : _d.sortSequenceId),
        pimCode: (_f = (_e = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _e === void 0 ? void 0 : _e.colorId) === null || _f === void 0 ? void 0 : _f.code,
        facet: mapColorFacet(pal),
        key: pal.sku.colorId.code,
        default: pal.digitalAssets.findIndex((el) => { var _a; return ((_a = el.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.imageCLPrimaryimageFlag) === true; }) !== -1,
    });
};
exports.mapColor = mapColor;
const mapSize = (pal) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    return ({
        name: (_b = (_a = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _a === void 0 ? void 0 : _a.sizeId) === null || _b === void 0 ? void 0 : _b.name,
        pimKey: String((_d = (_c = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _c === void 0 ? void 0 : _c.sizeId) === null || _d === void 0 ? void 0 : _d.sortSequenceId),
        pimCode: (_f = (_e = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _e === void 0 ? void 0 : _e.sizeId) === null || _f === void 0 ? void 0 : _f.code,
        key: (_h = (_g = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _g === void 0 ? void 0 : _g.sizeId) === null || _h === void 0 ? void 0 : _h.code,
    });
};
exports.mapSize = mapSize;
const mapHexValue = (pal) => { var _a; return (_a = pal === null || pal === void 0 ? void 0 : pal.variation) === null || _a === void 0 ? void 0 : _a.hexValue; };
exports.mapHexValue = mapHexValue;
const mapImageClUrl = (pal) => { var _a, _b, _c, _d; return (_d = (_c = (_b = (_a = pal === null || pal === void 0 ? void 0 : pal.digitalAssets) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.storeFronts) === null || _c === void 0 ? void 0 : _c.NMOnline) === null || _d === void 0 ? void 0 : _d.imageClUrl; };
exports.mapImageClUrl = mapImageClUrl;
const mapSwatchPath = (pal, brand) => {
    const asset = pal === null || pal === void 0 ? void 0 : pal.digitalAssets.find(elm => { var _a; return ((_a = elm.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.imageShotType) === 's'; });
    if (asset) {
        let url = asset.storeFronts[brand].imageClUrl || '';
        if (url && !url.startsWith('//')) {
            url = `//${url}`;
        }
        return url;
    }
    return '';
};
exports.mapSwatchPath = mapSwatchPath;
const mapShipping = (pal) => {
    var _a, _b, _c, _d;
    return ({
        boxedDepthInches: (_a = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _a === void 0 ? void 0 : _a.boxedDepthInches,
        boxedHeightInches: (_b = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _b === void 0 ? void 0 : _b.boxedHeightInches,
        boxedWidthInches: (_c = pal === null || pal === void 0 ? void 0 : pal.sku) === null || _c === void 0 ? void 0 : _c.boxedWidthInches,
        deliveryDays: (_d = pal === null || pal === void 0 ? void 0 : pal.style) === null || _d === void 0 ? void 0 : _d.supplierProcessingDays,
        shipFromStore,
        expectedShipDate,
    });
};
exports.mapShipping = mapShipping;
const mapSuggestedInterval = (pal) => { var _a, _b; return (_b = (_a = pal === null || pal === void 0 ? void 0 : pal.style) === null || _a === void 0 ? void 0 : _a.customerReplenishmentSuggInterval) === null || _b === void 0 ? void 0 : _b.code; };
exports.mapSuggestedInterval = mapSuggestedInterval;
const mapSeasonDeliveryCode = (pal) => {
    var _a, _b, _c, _d, _e;
    if (((_a = pal === null || pal === void 0 ? void 0 : pal.variation) === null || _a === void 0 ? void 0 : _a.deliverySeason) && ((_c = (_b = pal === null || pal === void 0 ? void 0 : pal.variation) === null || _b === void 0 ? void 0 : _b.deliverySeason) === null || _c === void 0 ? void 0 : _c.length)) {
        return (_e = (_d = pal === null || pal === void 0 ? void 0 : pal.variation) === null || _d === void 0 ? void 0 : _d.deliverySeason) === null || _e === void 0 ? void 0 : _e[0].delivery;
    }
    return '';
};
exports.mapSeasonDeliveryCode = mapSeasonDeliveryCode;
//# sourceMappingURL=skuDetailsUtils.js.map