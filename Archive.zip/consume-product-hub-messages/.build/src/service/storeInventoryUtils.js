"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapStoreInventories = void 0;
const dynamoMessages_1 = require("../storage/dynamoMessages");
exports.mapStoreInventories = (inv) => {
    const inventory = new dynamoMessages_1.StoreInventory();
    inventory.locationNumber = inv.LocationId;
    inventory.bopsQuantity = inv.Quantity;
    inventory.quantity = inv.Quantity;
    inventory.invLevel = inv.StatusCode;
    return inventory;
};
//# sourceMappingURL=storeInventoryUtils.js.map