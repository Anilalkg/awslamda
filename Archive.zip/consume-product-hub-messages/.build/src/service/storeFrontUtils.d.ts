declare const brandsMappings: {
    [key: string]: string;
};
declare const brandsAbbrMappings: {
    [key: string]: string;
};
declare const storeFrontsMappings: {
    [key: string]: string;
};
declare const zonesMappings: {
    [key: string]: string;
};
export { brandsMappings, brandsAbbrMappings, storeFrontsMappings, zonesMappings };
