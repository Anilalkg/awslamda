import { StoreInventory } from '../storage/dynamoMessages';
import { IStoreInventoryData } from '../models/data';
export declare const mapStoreInventories: (inv: IStoreInventoryData) => StoreInventory;
