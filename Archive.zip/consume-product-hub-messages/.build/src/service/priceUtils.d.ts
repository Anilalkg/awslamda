import { IPrice } from '../models/productHubMessage';
import { IProductHubPal } from '../models/pal';
declare const mapPrice: (pal: IProductHubPal, brand: string) => IPrice;
export { mapPrice };
