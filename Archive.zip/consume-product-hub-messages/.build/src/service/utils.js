"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapDisplayItemGroups = exports.mapPalToProduct = void 0;
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const elastic_builder_1 = __importDefault(require("elastic-builder"));
const digitalAssetsUtils_1 = require("./digitalAssetsUtils");
const priceUtils_1 = require("./priceUtils");
const productDetailsUtils_1 = require("./productDetailsUtils");
const skuDetailsUtils_1 = require("./skuDetailsUtils");
const storeFrontUtils_1 = require("./storeFrontUtils");
const cmosUtils_1 = require("./cmosUtils");
const dynamoMessages_1 = require("../storage/dynamoMessages");
const esClient_1 = require("../client/esClient");
const DEFAULT_DISPLAY_ITEM_TYPE = 'singlePriceDisplayItem';
const EMPTY_STRING = "";
const HYPHEN = "-";
const ES_INDEX = process.env.ES_INDEX || '';
const ES_DOMAIN = process.env.ES_DOMAIN || '';
const ES_REGION = process.env.ES_REGION || '';
const elasticClient = new esClient_1.EsClient(ES_DOMAIN, ES_REGION, ES_INDEX);
const generatePartitionKey = (pal) => `${pal.style.itemNumber}`;
const generateSortKey = (pal) => `${pal.sku.skuNumber}#${skuDetailsUtils_1.mapSkuSequenceNumber(pal)}`;
const emptyNullValues = (obj) => {
    if (Array.isArray(obj)) {
        for (const o of obj) {
            Object.keys(o).forEach(e => {
                if (o[e] === null)
                    o[e] = undefined;
            });
        }
    }
    else {
        Object.keys(obj).forEach(e => {
            if (obj[e] === null)
                obj[e] = undefined;
        });
    }
    return obj;
};
exports.mapPalToProduct = async (pal, brand, useATGProductId) => {
    var _a, _b, _c;
    const brandAbr = storeFrontUtils_1.brandsMappings[brand];
    if (!brandAbr)
        return null;
    const storeFront = storeFrontUtils_1.storeFrontsMappings[brand];
    const inventory = skuDetailsUtils_1.mapInventory(pal, storeFront);
    const productId = productDetailsUtils_1.mapProductId(pal, brand);
    const displayName = productDetailsUtils_1.mapDisplayName(pal);
    const departmentByTaxonomy = productDetailsUtils_1.mapTaxonomyByLevelName(pal, 'Department');
    const classByTaxonomy = productDetailsUtils_1.mapTaxonomyByLevelName(pal, 'Class');
    const subclassByTaxonomy = productDetailsUtils_1.mapTaxonomyByLevelName(pal, 'Sub Class');
    const newProduct = {
        PartitionKey: generatePartitionKey(pal),
        SortKey: generateSortKey(pal),
        skuNumber: pal.sku.skuNumber,
        skuSequenceNumber: skuDetailsUtils_1.mapSkuSequenceNumber(pal),
        displayItem: productDetailsUtils_1.mapDisplayItem(pal, brand),
        displayItemType: DEFAULT_DISPLAY_ITEM_TYPE,
        variationId: productDetailsUtils_1.mapVariationId(pal),
        productId,
        price: priceUtils_1.mapPrice(pal, brand),
        color: emptyNullValues(skuDetailsUtils_1.mapColor(pal, brand)),
        size: emptyNullValues(skuDetailsUtils_1.mapSize(pal)),
        inventory: skuDetailsUtils_1.mapInventory(pal, brand),
        digitalAssets: emptyNullValues(digitalAssetsUtils_1.mapDigitalAssets(pal, brand)),
        hexValue: skuDetailsUtils_1.mapHexValue(pal),
        swatchPath: skuDetailsUtils_1.mapSwatchPath(pal, brand),
        shipping: skuDetailsUtils_1.mapShipping(pal),
        suggestedInterval: skuDetailsUtils_1.mapSuggestedInterval(pal),
        displayName,
        department: departmentByTaxonomy,
        class: classByTaxonomy,
        subclass: emptyNullValues(subclassByTaxonomy),
        designer: productDetailsUtils_1.mapDesigner(pal),
        serviceLevelCodes: productDetailsUtils_1.mapServiceLevelCodes(pal),
        sellableDate: productDetailsUtils_1.mapSellableDate(pal, brand),
        adornDate: productDetailsUtils_1.mapAdornDate(pal, brand),
        launchDate: productDetailsUtils_1.mapLaunchDate(pal, brand),
        commodeCode: productDetailsUtils_1.mapCommodeCode(pal),
        genderCode: productDetailsUtils_1.mapGenderCode(pal),
        flags: productDetailsUtils_1.mapFlags(pal, brand, departmentByTaxonomy.code, classByTaxonomy.code, inventory),
        shortDescription: productDetailsUtils_1.mapShortDescription(pal),
        longDescription: productDetailsUtils_1.mapLongDescription(pal),
        notes: productDetailsUtils_1.mapNotes(pal, brand),
        cmosCatalogId: cmosUtils_1.mapCmosCatalogId(pal),
        cmosItem: cmosUtils_1.mapCmosItem(pal, brand),
        catalogType: productDetailsUtils_1.mapCatalogType(),
        pimStyle: productDetailsUtils_1.mapPimStyle(pal),
        parentheticalCharge: productDetailsUtils_1.mapParentheticalCharge(pal, brand),
        intlParentheticalAmount: productDetailsUtils_1.mapIntlParentheticalAmount(pal, brand),
        displayable: productDetailsUtils_1.mapDisplayable(pal, brand),
        canonicalUrl: productDetailsUtils_1.mapCanonicalUrl(pal, displayName, productId),
        designerBoutiqueUrl: productDetailsUtils_1.mapDesignerBoutiqueUrl(pal === null || pal === void 0 ? void 0 : pal.cm4Data),
        hideInternationally: productDetailsUtils_1.mapHideInternationally(pal),
        suppressCheckout: productDetailsUtils_1.mapSuppressCheckout(),
        sizeLabels: productDetailsUtils_1.mapSizeLabels(pal === null || pal === void 0 ? void 0 : pal.cm4Data),
        offline: productDetailsUtils_1.mapOffline(pal === null || pal === void 0 ? void 0 : pal.cm4Data),
        liveTreeDate: productDetailsUtils_1.mapLiveTreeDate(),
        restrictedStates: productDetailsUtils_1.mapRestrictedStates(pal),
        cmosSkuId: productDetailsUtils_1.mapCmosSkuId(),
        codeUpc: productDetailsUtils_1.mapCodeUpc(pal),
        discontinuedCode: productDetailsUtils_1.mapDiscontinuedCode(pal, brand),
        vendorId: productDetailsUtils_1.mapVendorId(pal),
        iceFlag: productDetailsUtils_1.mapIceFlag(pal),
        deliveryCode: skuDetailsUtils_1.mapSeasonDeliveryCode(pal),
        webProductIDs: productDetailsUtils_1.mapWebProductIds(pal, brand),
        psHierarchy: productDetailsUtils_1.mapHierarchy(pal === null || pal === void 0 ? void 0 : pal.cm4Data),
        psAttributes: productDetailsUtils_1.mapPSAttributes(pal === null || pal === void 0 ? void 0 : pal.cm4Data),
        forceWebPublish: (_a = pal.style.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.forceWebPublish,
        componentsOf: await mapComponentsOf(pal),
        displayAsGroupEligible: (_b = pal.style.storeFronts[brand]) === null || _b === void 0 ? void 0 : _b.editorialItemSetFlag,
        sizeGuide: productDetailsUtils_1.mapProductSizeGuide(pal, brand),
        webSkuId: await skuDetailsUtils_1.mapSkuNumber(pal, productId, useATGProductId),
        merchandiseType: (_c = pal === null || pal === void 0 ? void 0 : pal.style) === null || _c === void 0 ? void 0 : _c.dropshipCategory.code,
    };
    return newProduct;
};
const mapComponentsOf = async (pal) => {
    var _a, _b;
    if (!((_b = (_a = pal === null || pal === void 0 ? void 0 : pal.style) === null || _a === void 0 ? void 0 : _a.componentOf) === null || _b === void 0 ? void 0 : _b.length)) {
        return [];
    }
    return dynamoMessages_1.getParentGroupIds(pal.style.componentOf);
};
const mapGroupItemNotes = (data, brand) => { var _a; return ((_a = data === null || data === void 0 ? void 0 : data.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.cutlineSuiteBottom) || EMPTY_STRING; };
const mapSizeGuide = (data, brand) => { var _a; return ((_a = data === null || data === void 0 ? void 0 : data.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.brandSizeGuide) || EMPTY_STRING; };
const getProductIdFromESByCmosItem = async (cmosItem) => {
    if (cmosItem) {
        try {
            if (!cmosItem.startsWith(HYPHEN)) {
                cmosItem = HYPHEN + cmosItem;
            }
            const searchBody = new elastic_builder_1.default.RequestBodySearch()
                .source(false)
                .query(elastic_builder_1.default.termQuery("cmosItem", cmosItem));
            const resp = await elasticClient.search(searchBody.toJSON());
            logger_1.default.debug({ ESResponse: resp });
            if (resp.body.hits.total > 0) {
                return resp.body.hits.hits[0]._id;
            }
        }
        catch (err) {
            logger_1.default.error({ message: "Error retrieving productID from ES", data: err.message });
        }
    }
    return EMPTY_STRING;
};
exports.mapDisplayItemGroups = async (data, digitalAssets, brand, useATGProductId) => {
    var _a, _b;
    const brandAbr = storeFrontUtils_1.brandsMappings[brand];
    const productId = useATGProductId === "false" ? data.suiteNumber : await getProductIdFromESByCmosItem(data.suiteNumber || EMPTY_STRING);
    const itemGroup = new dynamoMessages_1.ItemGroup();
    if (brandAbr) {
        itemGroup.PartitionKey = data.suiteNumber;
        itemGroup.productId = productId;
        itemGroup.description = data.shortDescription || EMPTY_STRING;
        itemGroup.media = mapDisplayItemGroupMedia(data, digitalAssets, brand);
        itemGroup.displayName = data.copyTitle || EMPTY_STRING;
        itemGroup.notes = mapGroupItemNotes(data, brand);
        itemGroup.help = EMPTY_STRING;
        itemGroup.sizeGuide = mapSizeGuide(data, brand);
        itemGroup.cmosItem = data.suiteNumber || EMPTY_STRING;
        itemGroup.cmosCatalogId = EMPTY_STRING;
        itemGroup.pimStyle = EMPTY_STRING;
        itemGroup.merchandiseType = EMPTY_STRING;
        itemGroup.catalogType = EMPTY_STRING;
        itemGroup.departmentDesc = EMPTY_STRING;
        itemGroup.classDesc = EMPTY_STRING;
        itemGroup.designerName = EMPTY_STRING;
        itemGroup.designerDescriptionTitle = EMPTY_STRING;
        itemGroup.designerDescription = EMPTY_STRING;
        itemGroup.designerBoutiqueUrl = EMPTY_STRING;
        itemGroup.parentheticalCharge = 0.0;
        itemGroup.intlParentheticalAmount = 0.0;
        itemGroup.personalShopper = false;
        itemGroup.exclusive = false;
        itemGroup.preOrder = false;
        itemGroup.dynamicImageSkuColor = false;
        itemGroup.productFlags = {
            isOnlyAtNM: false,
            dynamicImageSkuColor: false,
            hasMoreColors: false,
            isNewArrival: false,
            isEditorial: (data === null || data === void 0 ? void 0 : data.storeFronts[brand]) ? (_a = data === null || data === void 0 ? void 0 : data.storeFronts[brand][0]) === null || _a === void 0 ? void 0 : _a.editorialItemSetFlag : false,
            isEvening: false,
            inLookBook: false,
            showMonogramLabel: false,
            previewSupported: false
        };
        itemGroup.hideInternationally = false;
        itemGroup.onSale = false;
        itemGroup.suppressCheckout = false;
        itemGroup.aliPay = false;
        itemGroup.parenthetical = false;
        itemGroup.departmentCode = EMPTY_STRING;
        itemGroup.commodeCode = EMPTY_STRING;
        itemGroup.classCode = EMPTY_STRING;
        itemGroup.metaInfo = EMPTY_STRING;
        itemGroup.codeSetType = EMPTY_STRING;
        itemGroup.sizeLabels = [];
        itemGroup.offline = false;
        itemGroup.originTimestampInfo = {
            ProductUpdated: data.updatedAt || EMPTY_STRING
        };
        itemGroup.sellableDate = (data === null || data === void 0 ? void 0 : data.launchDate) || EMPTY_STRING;
        const published = (_b = data === null || data === void 0 ? void 0 : data.itemPublishStatus) === null || _b === void 0 ? void 0 : _b.code;
        if (published === 'Published') {
            itemGroup.liveTreeDate = `${new Date()}`;
            itemGroup.displayable = true;
        }
        else {
            itemGroup.displayable = false;
            itemGroup.liveTreeDate = EMPTY_STRING;
        }
        itemGroup.adornDate = EMPTY_STRING;
        itemGroup.isBvd = false;
        itemGroup.genderCode = data.gender || EMPTY_STRING;
        itemGroup.restrictedStates = EMPTY_STRING;
        itemGroup.restrictedCodes = EMPTY_STRING;
        itemGroup.hierarchy = [];
        itemGroup.attributes = [];
        itemGroup.components = emptyNullValues([...data.components]);
    }
    return itemGroup;
};
const mapDisplayItemGroupMedia = (data, digitalAssets, brand) => {
    const media = [];
    digitalAssets.forEach(asset => {
        var _a;
        media.push({
            id: `m${data === null || data === void 0 ? void 0 : data.id}`,
            mediaVersion: ((_a = data === null || data === void 0 ? void 0 : data.publicationCount) === null || _a === void 0 ? void 0 : _a.toString()) || EMPTY_STRING,
            mediaTag: asset.storeFronts[brand].imageShotType || EMPTY_STRING,
            url: asset.storeFronts[brand].imageClUrl || EMPTY_STRING,
            productId: data.suiteNumber || EMPTY_STRING,
            dynamicImageSkuColor: false,
        });
    });
    return media;
};
//# sourceMappingURL=utils.js.map