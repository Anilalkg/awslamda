import { IProduct } from '../models/productHubMessage';
import { ItemGroup } from '../storage/dynamoMessages';
import { IProductHubGroupData, IStoreInventoryData } from "../models/data";
import { IPalDigitalAsset } from "../models/pal/palDigitalAssets";
export declare const saveProductHubMessage: (message: {
    pal: unknown;
}) => Promise<IProduct>;
export declare const saveItemGroupMessage: (message: {
    pal: {
        suite: IProductHubGroupData;
        digitalAssets: IPalDigitalAsset[];
    };
}) => Promise<ItemGroup>;
export declare const saveStoreInventoryMessage: (message: IStoreInventoryData) => Promise<void>;
