import { IProductHubPal } from '../models/pal';
import { IPalCmosStyle } from '../models/pal/palCmos';
export declare const getCmosByStyleId: (pal: IProductHubPal, styleId: string) => IPalCmosStyle;
export declare const mapCmosCatalogId: (pal: IProductHubPal) => string;
export declare const mapCmosItem: (pal: IProductHubPal, brand: string) => string;
