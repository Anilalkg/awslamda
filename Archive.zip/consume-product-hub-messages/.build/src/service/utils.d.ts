import { IProductHubPal } from '../models/pal';
import { IProductHubGroupData } from '../models/data';
import { IProduct } from '../models/productHubMessage';
import { ItemGroup } from "../storage/dynamoMessages";
import { IPalDigitalAsset } from "../models/pal/palDigitalAssets";
export declare const mapPalToProduct: (pal: IProductHubPal, brand: string, useATGProductId: string | true) => Promise<IProduct>;
export declare const mapDisplayItemGroups: (data: IProductHubGroupData, digitalAssets: IPalDigitalAsset[], brand: string, useATGProductId: string | true) => Promise<ItemGroup>;
