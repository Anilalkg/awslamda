"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zonesMappings = exports.storeFrontsMappings = exports.brandsAbbrMappings = exports.brandsMappings = void 0;
const brandsMappings = {
    NMOnline: 'nmo',
    HCOnline: 'hco',
    BGOnline: 'bgo',
};
exports.brandsMappings = brandsMappings;
const brandsAbbrMappings = {
    NM: 'NMOnline',
    HC: 'HCOnline',
    BG: 'BGOnline',
};
exports.brandsAbbrMappings = brandsAbbrMappings;
const storeFrontsMappings = {
    NMOnline: 'NMStores',
    HCOnline: 'HCStores',
    BGOnline: 'BGStores',
};
exports.storeFrontsMappings = storeFrontsMappings;
const zonesMappings = {
    NMOnline: 'zone12',
    HCOnline: 'zone14',
    BGOnline: 'zone15',
};
exports.zonesMappings = zonesMappings;
//# sourceMappingURL=storeFrontUtils.js.map