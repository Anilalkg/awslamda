"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapPrice = void 0;
const storeFrontUtils_1 = require("./storeFrontUtils");
const mapPrice = (pal, brand) => {
    var _a, _b;
    const zone = storeFrontUtils_1.zonesMappings[brand];
    const pricing = (_b = (_a = pal.sku.storeFronts[brand]) === null || _a === void 0 ? void 0 : _a.pricing) === null || _b === void 0 ? void 0 : _b[zone];
    return {
        retail: (pricing === null || pricing === void 0 ? void 0 : pricing.clearanceRetail) || (pricing === null || pricing === void 0 ? void 0 : pricing.promotionRetail) || (pricing === null || pricing === void 0 ? void 0 : pricing.regularRetail),
        original: pricing === null || pricing === void 0 ? void 0 : pricing.regularRetail,
    };
};
exports.mapPrice = mapPrice;
//# sourceMappingURL=priceUtils.js.map