"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsClient = exports.ES_ANALYZE_PATH = exports.ES_SEARCH_PATH = void 0;
const logger_1 = __importDefault(require("@nmg/osp-backend-utils/logger"));
const types_1 = require("./types");
const AWS = require('aws-sdk');
const path = require('path');
exports.ES_SEARCH_PATH = '_search';
exports.ES_ANALYZE_PATH = '_analyze';
const POST = 'POST';
class EsClient {
    constructor(esDomain, esRegion, esIndex) {
        this.httpClient = new AWS.HttpClient();
        this.credentials = new AWS.EnvironmentCredentials('AWS');
        this.esDomain = esDomain;
        this.esRegion = esRegion;
        this.esIndex = esIndex;
        this.endpoint = new AWS.Endpoint(this.esDomain);
    }
    sendRequest(esRequest) {
        const sendReqStart = new Date().getTime();
        const request = new AWS.HttpRequest(this.endpoint, this.esRegion);
        request.method = esRequest.httpMethod;
        let requestPath = path.join(request.path, esRequest.requestPath);
        const qp = esRequest.queryParameters;
        if (qp && Object.keys(qp).length > 0) {
            const queryParametersStr = Object.keys(qp)
                .map((key) => `${key}=${qp[key]}`)
                .join('&');
            requestPath = `${requestPath}?${queryParametersStr}`;
        }
        request.path = requestPath;
        request.body = (typeof esRequest.payload === 'string') ? esRequest.payload : JSON.stringify(esRequest.payload);
        request.headers['Content-Type'] = 'application/json';
        request.headers.Host = this.esDomain;
        logger_1.default.debug({ message: "HTTP request to ES", data: { request, index: this.esIndex } });
        const sendReqEnd = new Date().getTime();
        logger_1.default.debug({ message: "createReqObj", data: { duration: sendReqEnd - sendReqStart } });
        const signStart = new Date().getTime();
        const signer = new AWS.Signers.V4(request, 'es');
        signer.addAuthorization(this.credentials, new Date());
        const signEnd = new Date().getTime();
        logger_1.default.debug({ message: "RequestSigning", data: { duration: signEnd - signStart } });
        const start = process.hrtime();
        const logResponse = (responseCode, responseError) => {
            const [seconds, nanoseconds] = process.hrtime(start);
            const logData = {
                requestUrl: request.path,
                requestMethod: request.method,
                responseCode,
                responseTime: seconds * 1000 + nanoseconds / 1000000,
                responseError,
            };
            if (responseError) {
                logger_1.default.error({ message: "Request failed", data: logData });
            }
            else {
                logger_1.default.debug({ message: "Request succeeded", data: logData });
            }
        };
        return new Promise((resolve, reject) => {
            this.httpClient.handleRequest(request, null, (response) => {
                const handleReqStart = new Date().getTime();
                const { statusCode, statusMessage, headers } = response;
                let body = '';
                response.on('data', (chunk) => {
                    body += chunk;
                });
                response.on('end', () => {
                    const data = {
                        statusCode,
                        statusMessage,
                        headers,
                    };
                    logResponse(statusCode);
                    const handleReqEnd = new Date().getTime();
                    logger_1.default.debug({ message: "handleReqObj", data: { duration: handleReqEnd - handleReqStart } });
                    if (body) {
                        try {
                            const startConvert = new Date().getTime();
                            data.body = JSON.parse(body);
                            const endConvert = new Date().getTime();
                            logger_1.default.debug({ message: "ConvertToObject", data: { duration: endConvert - startConvert } });
                        }
                        catch (error) {
                            logger_1.default.error({ message: "Response body is not a valid JSON", data: body });
                            reject(error);
                        }
                    }
                    if (data.statusCode >= 400) {
                        logger_1.default.error({ message: "ES call failed", data: { method: request.method, path: request.path, data } });
                        reject(new types_1.EsClientError('ES response has status code >= 400', data));
                    }
                    resolve(data);
                });
            }, (error) => {
                const errorMessage = `${error}`;
                logger_1.default.error({ message: "Error sending request to elasticsearch", data: errorMessage });
                logResponse(0, errorMessage);
                return reject(error);
            });
        });
    }
    async search(payload, queryParameters) {
        const start = new Date().getTime();
        const esResponse = await this.sendRequest({
            httpMethod: POST,
            requestPath: path.join(this.esIndex, exports.ES_SEARCH_PATH),
            payload,
            queryParameters,
        });
        const end = new Date().getTime();
        return esResponse;
    }
    async analyze(payload, queryParameters) {
        const start = new Date().getTime();
        const esAnalysisResponse = await this.sendRequest({
            httpMethod: POST,
            requestPath: path.join(this.esIndex, exports.ES_ANALYZE_PATH),
            payload,
            queryParameters,
        });
        const end = new Date().getTime();
        return esAnalysisResponse;
    }
}
exports.EsClient = EsClient;
//# sourceMappingURL=esClient.js.map