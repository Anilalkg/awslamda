export interface EsRequest {
    httpMethod: string;
    requestPath: string;
    payload: any;
    queryParameters?: {
        [key: string]: string;
    };
}
export interface EsResponse {
    statusCode: number;
    statusMessage: string;
    headers: {
        [key: string]: string;
    };
    body?: any;
}
export interface EsSearchResponse extends EsResponse {
    body: {
        took: number;
        hits: {
            total: number;
            hits: EsHit[];
        };
        aggregations?: {
            [aggName: string]: EsTermsAgg;
        };
    };
}
export interface EsHit {
    _id: string;
    _source: any;
    fields?: any;
    highlight?: {
        [filed: string]: string[];
    };
    matched_queries?: string[];
}
export interface EsTermsAgg {
    buckets: EsTermsAggBucket[];
}
export interface EsTermsAggBucket {
    key: string;
    doc_count: number;
}
export declare class EsClientError extends Error {
    data?: any;
    constructor(message: string, data?: any);
    toString: () => string;
}
