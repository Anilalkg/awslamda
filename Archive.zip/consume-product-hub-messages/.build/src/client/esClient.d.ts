import { EsResponse } from './types';
export declare const ES_SEARCH_PATH = "_search";
export declare const ES_ANALYZE_PATH = "_analyze";
export declare class EsClient {
    private readonly esDomain;
    private readonly esRegion;
    private readonly esIndex;
    private readonly endpoint;
    constructor(esDomain: string, esRegion: string, esIndex: string);
    private readonly httpClient;
    private readonly credentials;
    private sendRequest;
    search(payload: any, queryParameters?: {
        [key: string]: string;
    }): Promise<EsResponse>;
    analyze(payload: any, queryParameters?: {
        [key: string]: string;
    }): Promise<EsResponse>;
}
