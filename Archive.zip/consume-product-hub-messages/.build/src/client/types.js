"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EsClientError = void 0;
class EsClientError extends Error {
    constructor(message, data) {
        super(message);
        this.toString = () => `Message: ${this.message}; Data: ${JSON.stringify(this.data)};`;
        this.message = message;
        this.data = data;
    }
}
exports.EsClientError = EsClientError;
//# sourceMappingURL=types.js.map