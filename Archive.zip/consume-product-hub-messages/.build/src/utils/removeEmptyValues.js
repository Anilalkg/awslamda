"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeEmptyValues = void 0;
exports.removeEmptyValues = (obj) => {
    Object.keys(obj).forEach((key) => {
        if (obj[key] === undefined || obj[key] === null) {
            obj[key] = '';
        }
    });
    return obj;
};
//# sourceMappingURL=removeEmptyValues.js.map