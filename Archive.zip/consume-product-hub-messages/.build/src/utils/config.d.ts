export declare const property: (name: string) => string;
