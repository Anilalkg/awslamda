export declare const removeEmptyValues: (obj: Record<string, any>) => Record<string, any>;
