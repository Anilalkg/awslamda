"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.property = void 0;
exports.property = (name) => process.env[name] || '';
//# sourceMappingURL=config.js.map