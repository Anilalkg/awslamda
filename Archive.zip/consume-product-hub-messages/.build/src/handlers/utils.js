"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.consumeStoreInvRecords = exports.consumeDevRecords = exports.consumeRecords = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const productHubService_1 = require("../service/productHubService");
exports.consumeRecords = async (record) => {
    var _a, _b, _c, _d, _e, _f, _g;
    try {
        logger_1.default.info({ message: 'Got new record', record });
        const eventBridgeMessage = JSON.parse(record.body);
        let parsedResponse = eventBridgeMessage;
        if ((_a = eventBridgeMessage === null || eventBridgeMessage === void 0 ? void 0 : eventBridgeMessage.event) === null || _a === void 0 ? void 0 : _a.eventType) {
            parsedResponse = eventBridgeMessage;
        }
        else {
            const params = {
                Bucket: ((_c = (_b = eventBridgeMessage === null || eventBridgeMessage === void 0 ? void 0 : eventBridgeMessage.detail) === null || _b === void 0 ? void 0 : _b.requestParameters) === null || _c === void 0 ? void 0 : _c.bucketName) || '',
                Key: ((_e = (_d = eventBridgeMessage === null || eventBridgeMessage === void 0 ? void 0 : eventBridgeMessage.detail) === null || _d === void 0 ? void 0 : _d.requestParameters) === null || _e === void 0 ? void 0 : _e.key) || '',
            };
            logger_1.default.debug({ message: 'params', data: params });
            const s3 = new aws_sdk_1.default.S3();
            const s3Response = await s3.getObject(params).promise();
            parsedResponse = JSON.parse((_f = s3Response === null || s3Response === void 0 ? void 0 : s3Response.Body) === null || _f === void 0 ? void 0 : _f.toString());
            logger_1.default.debug({ message: 'parsedResponse', data: parsedResponse });
        }
        if (getEventType(parsedResponse) === 'suiteUpdate') {
            await productHubService_1.saveItemGroupMessage(parsedResponse);
        }
        else {
            await productHubService_1.saveProductHubMessage(parsedResponse);
        }
    }
    catch (error) {
        const message = 'Error occurred while processing ProductHubMessage';
        logger_1.default.error({
            message,
            errorMessage: ((_g = error === null || error === void 0 ? void 0 : error.response) === null || _g === void 0 ? void 0 : _g.data) || error.message,
        });
    }
};
exports.consumeDevRecords = async (event) => {
    var _a;
    try {
        const parsedResponse = JSON.parse(event.body);
        if (getEventType(parsedResponse) === 'suiteUpdate') {
            await productHubService_1.saveItemGroupMessage(parsedResponse);
        }
        else {
            await productHubService_1.saveProductHubMessage(parsedResponse);
        }
    }
    catch (error) {
        const message = 'Error occurred while processing ProductHubMessage';
        logger_1.default.error({
            message,
            errorMessage: ((_a = error === null || error === void 0 ? void 0 : error.response) === null || _a === void 0 ? void 0 : _a.data) || error.message,
        });
    }
};
const getEventType = (s3Data) => {
    var _a;
    const eventType = (_a = s3Data === null || s3Data === void 0 ? void 0 : s3Data.event) === null || _a === void 0 ? void 0 : _a.eventType;
    logger_1.default.debug({ eventTypeValue: eventType });
    return eventType;
};
exports.consumeStoreInvRecords = async (record) => {
    var _a, _b, _c, _d, _e, _f;
    try {
        logger_1.default.info({ message: 'Got new Inventory record', record });
        const eventBridgeMessage = JSON.parse(record.body);
        const params = {
            Bucket: ((_b = (_a = eventBridgeMessage === null || eventBridgeMessage === void 0 ? void 0 : eventBridgeMessage.detail) === null || _a === void 0 ? void 0 : _a.requestParameters) === null || _b === void 0 ? void 0 : _b.bucketName) || '',
            Key: ((_d = (_c = eventBridgeMessage === null || eventBridgeMessage === void 0 ? void 0 : eventBridgeMessage.detail) === null || _c === void 0 ? void 0 : _c.requestParameters) === null || _d === void 0 ? void 0 : _d.key) || '',
        };
        logger_1.default.debug({ message: 'params', data: params });
        const s3 = new aws_sdk_1.default.S3();
        const s3Response = await s3.getObject(params).promise();
        const parsedResponse = JSON.parse((_e = s3Response === null || s3Response === void 0 ? void 0 : s3Response.Body) === null || _e === void 0 ? void 0 : _e.toString());
        logger_1.default.debug({ message: 'parsedInventoryResponse', data: parsedResponse });
        await productHubService_1.saveStoreInventoryMessage(parsedResponse);
    }
    catch (error) {
        const message = 'Error occurred while processing inventory records';
        logger_1.default.error({
            message,
            errorMessage: ((_f = error === null || error === void 0 ? void 0 : error.response) === null || _f === void 0 ? void 0 : _f.data) || error.message,
        });
    }
};
//# sourceMappingURL=utils.js.map