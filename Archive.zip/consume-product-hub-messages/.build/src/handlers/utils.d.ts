import { SQSRecord } from 'aws-lambda';
export declare const consumeRecords: (record: SQSRecord) => Promise<void>;
export declare const consumeDevRecords: (event: any) => Promise<void>;
export declare const consumeStoreInvRecords: (record: SQSRecord) => Promise<void>;
