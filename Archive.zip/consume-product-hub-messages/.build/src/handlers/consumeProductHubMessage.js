"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger_1 = __importDefault(require("@nmg/oco-backend-utils/logger"));
const utils_1 = require("./utils");
exports.handler = async function (event) {
    logger_1.default.info({ message: 'Got PAL event', records: event.Records.length });
    for (const record of event.Records) {
        await utils_1.consumeRecords(record);
    }
};
exports.devHandler = async function (event) {
    await utils_1.consumeDevRecords(event);
};
//# sourceMappingURL=consumeProductHubMessage.js.map