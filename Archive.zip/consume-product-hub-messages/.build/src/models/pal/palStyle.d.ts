import { IBasicType } from "./palSku";
export interface INumberLocation {
    number: string;
    name: string;
    type: string;
    contactName: string;
    city: string;
    country: string;
    zip: string;
    status: string;
    bctId: string;
    countryOfSourcing: string;
    updatedSource: string;
    createdAt: string;
    updatedAt: string;
    createdBy: string;
    updatedBy: string;
}
export interface IVendorLocation {
    locationNumber: string;
    primary: boolean;
}
export interface IItemVendorPartNumbers {
    locationNumber: string;
    primary: boolean;
}
export interface IShotType {
    name: string;
    code: string;
}
export interface IVendor {
    number: {
        number: string;
        name: string;
        type: string;
        status: string;
        email: string;
        foreignVendor: string;
        address1: string;
        address2: string;
        address3: string;
        city: string;
        region: string;
        state: string;
        zip: string;
        country: string;
        onTimeDelivery: string;
        quality: string;
        greenScore: string;
        socialScore: string;
        ethicScore: string;
        currency: string;
        taxCode: string;
        taxJurisdiction: string;
        vatRegistrationNumber: string;
        vat: string;
        boothNumber: string;
        createdAt: string;
        updatedAt: string;
        createdBy: string;
        updatedBy: string;
        locations: INumberLocation[];
        contacts: string;
        notes: string;
        fobs: string;
        payments: string;
        agent: string;
        taxonomies: {
            all: boolean;
            partial: any[];
        };
        updatedSource: string;
        vendorAssetType: string;
        VendorImageInstructions: string;
        sampleReturnAddress: string;
        vendorScoring: string;
    };
    primary: boolean;
    locations: IVendorLocation[];
    itemVendorPartNumbers: IItemVendorPartNumbers[];
    countryOfSourcing: string;
    vendorAssetType: string;
}
export interface InvalidCountryGroupItem {
    countryAndState: string;
    countryAndStateBlockFlag: boolean;
    countryAndStateMessage: string;
}
export interface IShipmentRestriction {
    shipmentRestriction: {
        name: string;
        code: string;
        sequence: string;
        isEnabled: boolean;
        updatedSource: string;
        createdBy: string;
        updatedBy: string;
        createdAt: string;
        updatedAt: string;
        commonName: string;
        restrictionCode: string;
        classification: string;
        scientificName: string;
        furFlag: boolean;
    };
    sourceOfFishAndWildlife: string;
}
export interface IPalStyle {
    id: number;
    itemNumber: string;
    createdAt: string;
    createdBy: string;
    expectedDate: string;
    taxonomy: string;
    name: string;
    shortDescription: string;
    startDate: string;
    status: string;
    updatedAt: string;
    componentOf: string[];
    updatedBy: string;
    alternateItemName: string;
    productSetType: boolean;
    classification: {
        levelNumber: number;
        name: string;
        description: string;
        isActive: boolean;
        code: string;
        isDeleted: boolean;
        levelName: string;
        dropshipCategory: string;
    };
    workflowStatus: string[];
    workflowType: {
        name: string;
        code: string;
    };
    currency: {
        name: string;
        code: string;
    };
    updatedSource: string;
    publicationCount: number;
    primaryCategory: string;
    vendors: IVendor[];
    invalidCountryGroup: InvalidCountryGroupItem[];
    shipmentRestriction: IShipmentRestriction[];
    components: any[];
    tags: any[];
    relatedItems: any[];
    mergedItems: any[];
    substitutions: any[];
    advancedPrintOrderDays: string;
    advertisedCountryofManufacture: string;
    allowSplitOrder: boolean;
    alternateShippingMethod: string;
    assemblyRequiredFlag: boolean;
    backplateDimensionsInches: string;
    baseDimensionsInches: string;
    blockBrandNameOnline: string;
    boxedDiscrepancy: boolean;
    brandAdvertised: {
        name: string;
        code: string;
        brandAdvertisedRef: string;
        copyBrandBio: string;
        brand: string;
    };
    brandCollection: string;
    brandName: {
        name: string;
        code: string;
        invalidGroupingCode: string;
        markdownsAllowedOnline: string;
        nmStanleyAppItem: boolean;
        storeOnlyBgStores: boolean;
        storeOnlyNmStores: boolean;
        givesBack: string[];
        diverse: string[];
        parentId: string;
        transparent: string[];
    };
    careInstruction: [];
    casePackQty: number;
    certificateOfAuthenticityFlag: boolean;
    comparativeValue: number;
    consignmentType: string;
    containsLeadFlag: boolean;
    copyBlock: string;
    copyBrandBio: string;
    copyBrandEdited: string;
    copyBrandProvided: string;
    copyBrandSellingPoint: string;
    copyContext: string;
    copyFreeformItemTypeFabrication: string;
    copyFreeformLowerBullet: string;
    copyFreeformMiddleBullet: string;
    copyFreeformTopBullet: string;
    copyGWP: string;
    copyHandbagStrap: string;
    copyItemNotes: string;
    copyKeySellingPoints: string;
    copyLegacyFlag: boolean;
    copyNeckline: string;
    copyRepublishDate: string;
    copyStoneDetails: string;
    copyStoneKind: string;
    copySwimwear: string;
    copyTitle: string;
    copyUpdateRequired: string;
    costUnitOfMeasure: {
        name: string;
        code: string;
    };
    costZoneGroupId: {
        name: string;
        code: string;
    };
    countryOfManufacture: [];
    customerReplenishmentSuggInterval?: IBasicType;
    defaultUnitOfPurchase: {
        name: string;
        code: string;
    };
    deliveryRouting: {
        name: string;
        code: string;
    };
    deliverySignatureRequiredFlag: boolean;
    depictionPrefix: {
        name: string;
        code: string;
    };
    differentiator2Group: string;
    differentiator2SubGroup: string;
    differentiator2Type: string;
    dimensionsObject: {
        name: string;
        code: string;
    };
    diverse: [];
    doNotReturnWithoutTagFlag: boolean;
    dropshipCategory: {
        name: string;
        code: string;
    };
    dropshipFlag: boolean;
    dropshipReturnsSellableFlag: boolean;
    electricalCordLengthFeet: string;
    energyGuide: string;
    energyUse: string;
    fauxFurFiber: [];
    firstMaterial: string;
    FishAndWildlifeScientificNameShipmentRestriction: [];
    furAnimal: [];
    furScientificName: [];
    furTreatment: string;
    gender: {
        name: string;
        code: string;
    };
    giftWrapFlag: boolean;
    givesBack: [];
    gohLengthId: string;
    goldKarat: string;
    handcraftedFlag: boolean;
    hardwareIncluded: string;
    hardwareIncludedHangingMethod: string;
    hi: number;
    htsCode: string;
    imageRepublishDate: string;
    importFlag: boolean;
    indoorOutdoor: string;
    initialCost: number;
    innerDimDepthInches: string;
    innerDimHeightInches: string;
    innerDimLengthWidthInches: string;
    innerPackQty: number;
    insuranceRequiredFlag: boolean;
    internalMonogramColor: string;
    internalMonogramLength: string;
    internalMonogramStyle: string;
    invalidCountryGroupingCode: string;
    invalidShipMethods: [];
    inventoryIndicator: boolean;
    itemEnrichmentInstructions: string;
    itemHeightInches: string;
    itemLegacyFlag: boolean;
    itemNotes: string;
    itemNumberType: {
        name: string;
        code: string;
    };
    itemPublishStatus: {
        name: string;
        code: string;
    };
    itemRepublishDate: string;
    itemSetRepublishDate: string;
    itemSetStorefront: string;
    itemSetStylingNotes: string;
    itemSetType: string;
    itemVariation: {
        name: string;
        code: string;
        transactionLevel: string;
    };
    itemVPNRef: string;
    itemWeightLbs: string;
    keySellingPoints: string;
    launchDate: string;
    legacyCopyBlock: string;
    lightingChainLengthFeet: string;
    lightingType: [];
    markdownsAllowedOnline: string;
    materialId: [];
    mdmCareInstruction: string;
    mdmExclusiveStyleFlag: boolean;
    mdmKeySellingPoints: string;
    mdmMaterialAndFiberContent: string;
    mdmMetalColor: string;
    mdmMetalKind: string;
    mdmModfiedUser: string;
    mdmModifiedDate: string;
    mdmModifiedTime: string;
    mdmPublicationCount: string;
    merchandiseIndicator: boolean;
    midCodeId: string;
    monogramSupplierId: string;
    nmInitialRetail: number;
    numberOfLights: string;
    OLDmdmExclusiveStyleFlag: boolean;
    onHandQty: string;
    onlineMerchandising: string;
    onOrderQty: string;
    orderableIndicator: boolean;
    otherFishAndWildlifeAnimal: [];
    outerDimDepthInches: string;
    outerDimHeightInches: string;
    outerDimLengthWidthInches: string;
    packedBySupplierFlag: boolean;
    packIndicator: boolean;
    perishableFlag: boolean;
    personalizationInstructions: [];
    personalizationType: {
        name: string;
        code: string;
        attribute1: string;
        attribute2: string;
    };
    plugType: string;
    poNotBeforeDate: string;
    productTypes: [];
    prop65: string;
    realOrFauxFurFlag: boolean;
    receiptRouting: {
        name: string;
        code: string;
        attribute1: string;
        attribute2: string;
    };
    reshippableFlag: boolean;
    responsiblyManufactured: [];
    retailUnitOfMeasure: {
        name: string;
        code: string;
    };
    sampleRequestInstructions: string;
    sampleUpdateRequired: string;
    sarEligibile: string;
    secondMaterial: string;
    sellableIndicator: boolean;
    setNumberOfPieces: string;
    shadeDimensions: string;
    shippingMethod: string;
    soldInStoresFlag: boolean;
    soleType: string;
    sourceOfFur: [];
    sourceOfMaterials: [];
    storeOrderMultiple: {
        name: string;
        code: string;
    };
    supplierProcessingDays: number;
    sustainableMaterials: [];
    taxCategoryId: {
        name: string;
        code: string;
        taxSystem2Description: string;
        taxDepartmentDefinition: string;
        taxSystem1Code: string;
        taxSystem4Description: string;
        taxSystem3Description: string;
        taxSystem2Code: string;
        taxSystem3Code: string;
        taxSystem1Description: string;
        taxSystem4Code: string;
    };
    thirdMaterial: string;
    ti: number;
    ticketLevel: {
        name: string;
        code: string;
    };
    ticketType: {
        name: string;
        code: string;
    };
    transactionLevel: number;
    transparent: [];
    udaUPC: boolean;
    ulApprovedFlag: boolean;
    vendorImageInstructions: string;
    vpiImageLink: string;
    warehouseAttributesLockedId: number;
    warranty: string;
    storeFronts: {
        [storeFront: string]: {
            blockOrders: string;
            cloudinaryPersonalizationInstructions: string;
            copyNotes: string;
            copySizeGuide: string;
            cutlineSuiteBottom: string;
            cutlineSuiteTop: string;
            editorialItemSetFlag: boolean;
            forceWebPublish: boolean;
            itemShotTypeCompleteness: string;
            itemSwatchCompleteness: boolean;
            legacyCopyNotes: string;
            legacyCopySizeGuide: string;
            legacycutlineSuiteTop: string;
            legacyFlag: boolean;
            mvpItemShotTypeCompleteness: boolean;
            nmgRequiredShotType: IShotType[];
            nmgShotTypeCompleteness: string;
            storeOnly: boolean;
        };
    };
}
