export interface IDeliverySeason {
    chain: string;
    delivery: string;
    fashionSeason: string;
    fiscalYear: string;
}
export interface IVendor {
    chain: string;
    delivery: string;
    fashionSeason: string;
    fiscalYear: string;
}
export interface IWebProduct {
    webPrice: string;
    webTreed: boolean;
    webDepiction: string;
    webProductID: string;
    webCmosColorCode: string;
    webMarkdownAdornment: boolean;
}
export interface IPalVariation {
    id: number;
    variationNumber: string;
    status: string;
    workflowStatus: string[];
    createdBy: string;
    updatedBy: string;
    createdAt: string;
    updatedAt: string;
    updatedSource: string;
    deliverySeason: IDeliverySeason[];
    tags: any[];
    workflowType: {
        name: string;
        code: string;
    };
    vendors: IVendor[];
    sampleNotes: string;
    endorImageStatusDate: string;
    differentiator1Group: {
        name: string;
        code: string;
    };
    sarCancelWarehouse: string;
    differentiator1SubGroup: {
        name: string;
        code: string;
    };
    onHandQty: string;
    vendorImageApprovedDate: string;
    onOrderQty: string;
    vendorImageRejectedDate: string;
    nmgSARStudioReceivedDateOld: string;
    reportingFreeform: string[];
    initialRetail: string;
    sampleShippedDate: string;
    colorId: {
        name: string;
        code: string;
        nrfParent: string;
        webFacet: string[];
        advertisedDescription: string[];
        shortDescription: string;
        sortSequenceId: number;
        proportionSizeId: string;
        supplierDescription: string;
        group: string;
    };
    brandAdvertisedRef: string;
    sampleReturnAddress: string;
    initialCost: string;
    vendorImageRejectionReason: string;
    nrfColor: string;
    differentiator1Type: {
        name: string;
        code: string;
    };
    sampleReturnTracking: string;
    sampleTrackLicensePlate: string;
    vendorImageRequestedDate: string;
    colorParent: string;
    sampleReceivingTracking: string;
    imageRequestedDate: string;
    sarCancelReason: string;
    markup: string;
    RequestedSampleReturnDate: string;
    reportingTag: [];
    shortDescription: string;
    mtu: string;
    tobedeleted: string;
    sampleReceivedDate: string;
    stylingNotes: string;
    sampleRequestedDate: string;
    vendorImageReceivedDate: string;
    nmgSARStudioReceivedDate: string;
    sampleReturnedDate: string;
    advertisedDescription: string;
    sarRequestedDate: string;
    costDiscount: string;
    nmgSARCancelledDate: string;
    sarCancelledDate: string;
    supplierDescription: string;
    hexValue: string;
    nmgSARCancel: string;
    currentRetail: string;
    imageReceivedDate: string;
    wholesaleCost: string;
    storeFronts: {
        [storeFront: string]: {
            marketingVehicle: [];
            poNotBeforeDate: string;
            preSell: string;
            mainShotTypeCompleteness: boolean;
            launchDate: string;
            adornDate: string;
            mvpVariationShotTypeCompleteness: boolean;
            nmgSARWHSentDate: string;
            actualAssetType: string;
            exclusiveFlag: boolean;
            variationShotTypeCompleteness: boolean;
            nmgSARReturnedtoWHDate: string;
            webMarkdownAdornmentFlag: boolean;
            exclusiveType: string;
            photoComplete: string;
            currentDepiction: string;
            webProduct: [{
                webPrice: string;
                webTreed: boolean;
                webDepiction: string;
                webProductID: string;
                webCmosColorCode: string;
                webMarkdownAdornment: boolean;
                parentheticalCharge?: string;
                intlParentheticalAmount?: string;
            }];
            webTreedFlag: boolean;
            preOrderFlag: boolean;
            digitalReadinessNotes: string;
            maoAvailableFlag: boolean;
            colorCorrectionRequired: string;
            webPrice: string;
            webDepiction: string;
            blockOrders: string;
            variationSwatchCompleteness: boolean;
        };
    };
}
