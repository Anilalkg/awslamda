export declare type Hierarchy = {
    level1: string;
    level2?: string;
    level3?: string;
    level4?: string;
    level5?: string;
};
export declare type ProductAttributes = {
    Type?: string[];
    SizeLabels?: string[];
    Lifestyle?: string[];
    Season?: string[];
};
export interface CM4Data {
    attributes: ProductAttributes;
    hierarchy: Hierarchy[];
    offline: boolean;
    designerBoutiqueUrl: string;
    liveTreeDate?: string;
}
