export interface IPalCmos {
    [styleId: string]: IPalCmosStyle;
}
export interface IStoreFront {
    storeFrontID: string;
    NMOfferItemId?: string;
    BGOfferItemId?: string;
    HCOfferItemId?: string;
}
export interface IPalCmosStyle {
    itemId: string;
    styleId: string;
    SoldOnline: boolean;
    warehouseDescription: string;
    isBackOrderableFlag: boolean;
    CmosSkuID: string;
    CmosAttributeLockCode: boolean;
    boxedDepthInches: string;
    boxedHeightInches: string;
    boxedWeightLbs: string;
    boxedWidthInches: string;
    boxId: string;
    breakableFlag: boolean;
    furFlag: boolean;
    giftWrapFlag: boolean;
    dryIceWeight: string;
    eligibleServiceLevels: string;
    fedexHalEligibleFlag: boolean;
    sameDayEligibleFlag: boolean;
    gohLengthId: string;
    includeFutureInventoryFlag: boolean;
    packedBySupplierFlag: boolean;
    receiptRoutingCode: string;
    reshipperFlag: boolean;
    MerchHierarchy: string;
    storeFronts: IStoreFront[];
}
