interface IBasicType {
    name: string;
    code: string;
}
interface IPalDigitalAssetStoreFront {
    imageClAdditionalArg: string;
    imageClMonogramArg: string;
    imageCLPrimaryimageFlag: boolean;
    imageClUrl: string;
    imageCLblockFlag: boolean;
    imageCLSwatchDisplayFlag: boolean;
    imageClSeoSuffix: string;
    imageClDefaultArg: IBasicType;
    imageCLVariationOverrideFlag: boolean;
    imageShotType: string;
}
export interface IPalDigitalAsset {
    assetName: {
        id: number;
        assetName: string;
        taxonomy: string;
        mediaCategory: string;
        linkURL: string;
        url: string;
        status: string;
        reasonToReject: string;
        reasonToApprove: string;
        height: string;
        width: string;
        tags: any[];
        rating: string;
        description: string;
        notes: string;
        geoLocationName: string;
        geoLocationShortName: string;
        latitude: string;
        longitude: string;
        isCheckedOut: boolean;
        checkedInOutBy: string;
        publicationCount: string;
        createrId: number;
        updaterId: number;
        checkedInAt: string;
        checkedOutAt: string;
    };
    linkURL: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    updatedSource: string;
    primaryAsset: boolean;
    isDeleted: boolean;
    colorID: {
        name: string;
        code: string;
        nrfParent: string;
        webFacet: string[];
        advertisedDescription: string[];
        shortDescription: string;
        sortSequenceId: number;
        proportionSizeId: string;
        supplierDescription: string;
        group: string;
    };
    viewType: string;
    storeFronts: {
        [storeFrontCode: string]: IPalDigitalAssetStoreFront;
    };
}
export {};
