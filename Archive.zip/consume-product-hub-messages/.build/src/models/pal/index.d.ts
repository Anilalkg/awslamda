import { IPalStyle } from './palStyle';
import { IPalVariation } from './palVariation';
import { IPalSku } from './palSku';
import { IPalDigitalAsset } from './palDigitalAssets';
import { IPalTaxonomy } from './palTaxonomies';
import { IPalCmos } from './palCmos';
import { CM4Data } from "./cm4Data";
export interface IProductHubPal {
    style?: IPalStyle;
    variation?: IPalVariation;
    sku?: IPalSku;
    digitalAssets?: IPalDigitalAsset[];
    taxonomies?: IPalTaxonomy[];
    cmos?: IPalCmos[];
    cm4Data?: CM4Data;
}
