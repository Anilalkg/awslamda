export interface ISkuVendorPartNumbers {
    vendorPartNumber: string;
    isPrimary: boolean;
}
export interface IBasicType {
    name: string;
    code: string;
}
interface IInventoryType {
    itemId: string;
    status: string;
    onHandStatus: string;
    statusCode: number;
    nextAvailabilityDate: string;
    viewName: string;
    viewId: string;
    transactionDateTime: string;
    totalQuantity: number;
    totalIncludingSubstituteItems: number;
    substituteItemsAvailable: boolean;
    substitutionDetails: string;
    quantity: {
        distributionCenters: number;
    };
    networkProtectionQuantity: {
        noProtection: number;
    };
    isInfiniteAvailability: string;
    futureQuantity: number;
    onHandQuantity: number;
    nextFutureQuantityETA: string;
}
interface IPricing {
    recordType: string;
    item: string;
    zoneId: string;
    storeFront: string;
    effectiveDate: string;
    regularRetail: number;
    clearanceRetail: number;
    promotionRetail: number;
    sellingUOM: string;
    currencyCode: string;
}
interface IPalSkuStoreFront {
    blockOrders: boolean;
    allowBackorders: boolean;
    inventory: IInventoryType;
    pricing: {
        [zone: string]: IPricing;
    };
}
interface ISkuUpc {
    code: string;
    status: any;
    upcType: string;
    upcRequestedDate: string;
    upcCaptureStatus: string;
    nmgUpcCode: string;
    primaryUdaUpc: boolean;
    primaryRmsUpc: boolean;
    upcCaptureExclude: boolean;
}
export interface IPalSku {
    id: number;
    skuNumber: string;
    createdBy: string;
    updatedBy: string;
    createdAt: string;
    updatedAt: string;
    sequenceNumber: string;
    status: string;
    updatedSource: string;
    upcs: ISkuUpc[];
    vendors: [{
        number: string;
        primary: boolean;
        skuVendorPartNumbers: ISkuVendorPartNumbers[];
    }];
    sizeId: {
        name: string;
        code: string;
        nrfParent: string;
        webFacet: any[];
        advertisedDescription: string[];
        shortDescription: string;
        sortSequenceId: number;
        proportionSizeId: string;
        supplierDescription: string;
        group: string;
    };
    colorId: {
        name: string;
        code: string;
        nrfParent: string;
        webFacet: IBasicType[];
        advertisedDescription: string[];
        shortDescription: string;
        sortSequenceId: number;
        proportionSizeId: string;
        supplierDescription: string;
        group: string;
    };
    advertisedDescription: IBasicType;
    boxedHeightInches: number;
    itemNumberTypeDup: string;
    mdmPublicationCount: string;
    initialCost: number;
    skuRepublishDate: string;
    differentiator2SubGroup: IBasicType;
    mdmModifiedTime: string;
    nrfColor: string;
    supplierDescription: string;
    skuInitialRetail: number;
    skuVPNRef: string;
    boxedDepthInches: number;
    differentiator2Group: IBasicType;
    differentiator2Type: IBasicType;
    comparativeValue: number;
    proportionSize: string;
    itemNumberType: IBasicType;
    shortDescription: string;
    priority: string;
    boxedWidthInches: number;
    nrfSize: string;
    boxedWeightLbs: number;
    skuReflowDate: string;
    mdmModfiedUser: string;
    componentOf: string[];
    mdmModifiedDate: string;
    eligibleServiceLevels: string[];
    storeFronts: {
        [storeFront: string]: IPalSkuStoreFront;
    };
}
export {};
