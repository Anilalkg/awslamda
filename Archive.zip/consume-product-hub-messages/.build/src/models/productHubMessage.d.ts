import { IProductHubEvent } from './palEvent';
import { IProductHubPal } from './pal';
export interface IProductHubMessage {
    pal: IProductHubPal;
    event: IProductHubEvent;
}
export interface IProductDigitalAsset {
    mediaTag: string;
    mediaVersion: string;
    url: string;
}
export interface ITaxonomy {
    code: string;
    name: string;
}
export interface IDesigner {
    name: string;
    descriptionTitle: string;
    description: string;
}
export interface IFlags {
    isGroup: boolean;
    belongsToGroup: boolean;
    preOrder: boolean;
    allowBackOrders: boolean;
    blockOrders: boolean;
    dynamicImageSkuColor: boolean;
    isEditorial: boolean;
    isEvening: boolean;
    showMonogramLabel: boolean;
    previewSupported: boolean;
    storeOnly: boolean;
    exclusive: boolean;
    inStock: boolean;
    useSkuAsset: boolean;
    giftWrappableFlag: boolean;
    perishableFlag: boolean;
    dropshipFlag: boolean;
    fedexEligibleFlag: boolean;
    parenthetical: boolean;
    isOnlyAtNM: string;
    hasMoreColors: string;
    onSale: boolean;
}
export interface IColor {
    name: string;
    pimKey: string;
    pimCode: string;
    facet: string[];
    key: string;
    default: boolean;
}
export interface ISize {
    name: string;
    pimKey: string;
    pimCode: string;
    key: string;
}
export interface IInventory {
    status: string;
    onHandStatus: string;
    qty: number;
    purchaseOrderQty: number;
    bossTotalQty: number;
}
export interface IShipping {
    boxedDepthInches: number;
    boxedHeightInches: number;
    boxedWidthInches: number;
    deliveryDays: number;
    shipFromStore?: string;
    expectedShipDate?: string;
}
export interface IStoreInventory {
    storeId: string;
    storeNumber: string;
    locationNumber: string;
    quantity: bigint;
    bopsQuantity: bigint;
}
export interface IPrice {
    retail: number;
    original: number;
}
export interface IProduct {
    PartitionKey: string;
    SortKey: string;
    skuNumber: string;
    skuSequenceNumber: number;
    displayItem: string;
    displayItemType: string;
    variationId: string;
    productId: string;
    price: IPrice;
    color: IColor;
    size: ISize;
    inventory: IInventory;
    digitalAssets: IProductDigitalAsset[];
    hexValue: string;
    swatchPath: string;
    shipping: IShipping;
    suggestedInterval: string;
    displayName: string;
    department: ITaxonomy;
    class: ITaxonomy;
    subclass: ITaxonomy;
    designer: IDesigner;
    serviceLevelCodes: string[];
    sellableDate: string;
    commodeCode: string;
    genderCode: string;
    flags: IFlags;
    shortDescription: string;
    longDescription: string;
    notes: string;
    cmosCatalogId: string;
    cmosItem: string;
    catalogType: string;
    pimStyle: string;
    parentheticalCharge: string;
    intlParentheticalAmount: string;
    displayable: boolean;
    canonicalUrl: string;
    designerBoutiqueUrl?: string;
    hideInternationally: boolean;
    suppressCheckout?: string;
    sizeLabels?: string[];
    offline?: boolean;
    liveTreeDate?: string;
    restrictedStates: string;
    cmosSkuId?: string;
    codeUpc: string;
    discontinuedCode?: string;
    vendorId: string;
    iceFlag: string;
    launchDate: string;
    adornDate: string;
    storeInventories?: IStoreInventory[];
    deliveryCode?: string;
    displayGroups?: string[];
    webProductIDs?: string[];
    attributes?: Record<string, unknown>;
    psAttributes?: Record<string, unknown>;
    psHierarchy?: unknown[];
    forceWebPublish?: boolean;
    componentsOf?: string[];
    displayAsGroupEligible?: boolean;
    sizeGuide?: string;
    webSkuId?: string;
    merchandiseType?: string;
}
