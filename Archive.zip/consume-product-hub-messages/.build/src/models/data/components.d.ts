export interface IComponents {
    componentLevel: string;
    componentNumber: string;
    quantity?: number;
    componentSequence?: number;
    componentDepiction?: string;
    componentDepictionSequence?: number;
}
