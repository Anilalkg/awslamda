import {attribute, hashKey, rangeKey, table} from '@aws/dynamodb-data-mapper-annotations'
import { DataMapper, embed } from '@aws/dynamodb-data-mapper'
import { AttributePath, UpdateExpression } from "@aws/dynamodb-expressions";
import { DynamoDB } from 'aws-sdk'
import logger from '@nmg/osp-backend-utils/logger'
import { property } from '../utils/config'
import { removeEmptyValues } from '../utils/removeEmptyValues'
import { IDesigner, IFlags, ITaxonomy, IShipping, IProduct } from '../models/productHubMessage'
import { IComponents } from '../models/data/components'
import { IStoreInventoryData } from '../models/data'
import { mapStoreInventories } from '../service/storeInventoryUtils'

export const COMPONENT_ACTION_NEW_OR_UPDATED = 1;
export const COMPONENT_ACTION_REMOVED = 2;

const mapper = new DataMapper({ client: new DynamoDB() })
const productsTableName = property('PRODUCTS_TABLE')
const displayItemGroupTableName = property('DISPLAY_ITEM_GROUP_TABLE')
const locationStoreMapping = property('MAP_LOCATION_WITH_STORE_ID_AND_ID') || '{}'
const skuTableName = property('SKU_TABLE')


@table(skuTableName)
export class Sku {
  @hashKey({ type: 'String' })
  productId: string
  @rangeKey()
  id: string
  @attribute()
  pimSkuId: string
}

export class DigitalAsset {
  @attribute()
  mediaTag: string
  @attribute()
  mediaVersion: string
  @attribute()
  url: string
}

export class Taxonomy {
  @attribute()
  code: string
  @attribute()
  name: string
}

export class Designer {
  @attribute()
  name: string
  @attribute()
  descriptionTitle: string
  @attribute()
  description: string
}

export class Flags {
  @attribute()
  isGroup: boolean
  @attribute()
  belongsToGroup: boolean
  @attribute()
  preOrder: boolean
  @attribute()
  allowBackOrders: boolean
  @attribute()
  blockOrders: boolean
  @attribute()
  dynamicImageSkuColor: boolean
  @attribute()
  isEditorial: boolean
  @attribute()
  isEvening: boolean
  @attribute()
  showMonogramLabel: boolean
  @attribute()
  previewSupported: boolean
  @attribute()
  storeOnly: boolean
  @attribute()
  exclusive: boolean
  @attribute()
  inStock: boolean
  @attribute()
  useSkuAsset: boolean
  @attribute()
  giftWrappableFlag: boolean
  @attribute()
  perishableFlag: boolean
  @attribute()
  dropshipFlag: boolean
  @attribute()
  fedexEligibleFlag: boolean
  @attribute()
  parenthetical: boolean
  @attribute()
  isOnlyAtNM: string
  @attribute()
  hasMoreColors: string
  @attribute()
  onSale: boolean
}

export class Color {
  @attribute()
  key: string
  @attribute()
  name: string
  @attribute()
  pimKey: string
  @attribute()
  pimCode: string
  @attribute()
  facet: string[]
  @attribute()
  default: boolean
}

export class Size {
  @attribute()
  name: string
  @attribute()
  pimKey: string
  @attribute()
  pimCode: string
  @attribute()
  key: string
}

export class Inventory {
  @attribute()
  status: string
  @attribute()
  onHandStatus: string
  @attribute()
  qty: number
  @attribute()
  purchaseOrderQty: number
  @attribute()
  bossTotalQty: number
}

export class Shipping {
  @attribute()
  boxedDepthInches: number
  @attribute()
  boxedHeightInches: number
  @attribute()
  boxedWidthInches: number
  @attribute()
  deliveryDays: number
  @attribute()
  shipFromStore?: string
  @attribute()
  expectedShipDate?: string
}

export class StoreInventory {
  @attribute()
  storeId: string
  @attribute()
  storeNumber: string
  @attribute()
  locationNumber: string
  @attribute()
  quantity: bigint
  @attribute()
  bopsQuantity: bigint
  @attribute()
  invLevel: bigint
}

export class Price {
  @attribute()
  retail: number
  @attribute()
  original: number
}

export class SimpleProduct {
  @attribute()
  launchDate: string
  @attribute()
  adornDate: string
}

export class Components {
  @attribute()
  componentLevel: string
  @attribute()
  componentNumber: string
  @attribute()
  quantity?: number
  @attribute()
  componentSequence?: number
  @attribute()
  componentDepiction?: string
  @attribute()
  componentDepictionSequence?: number
}

@table(productsTableName)
export class Product {
  @hashKey({ type: 'String' })
  PartitionKey: string
  @rangeKey()
  SortKey: string
  @attribute()
  skuNumber: string
  @attribute()
  skuSequenceNumber: number
  @attribute()
  displayItem: string
  @attribute()
  displayItemType: string
  @attribute()
  variationId: string
  @attribute()
  productId: string
  @attribute({ memberType: embed(Price) })
  price: Price
  @attribute({ memberType: embed(Color) })
  color: Color
  @attribute({ memberType: embed(Size) })
  size: Size
  @attribute({ memberType: embed(Inventory) })
  inventory: Inventory
  @attribute({ memberType: embed(DigitalAsset) })
  digitalAssets: DigitalAsset[]
  @attribute()
  hexValue: string
  @attribute()
  merchandiseType: string
  @attribute()
  swatchPath: string
  @attribute({ memberType: embed(Shipping) })
  shipping: IShipping
  @attribute()
  suggestedInterval: string
  @attribute()
  displayName: string
  @attribute({ memberType: embed(Taxonomy) })
  department: ITaxonomy
  @attribute({ memberType: embed(Taxonomy) })
  class: ITaxonomy
  @attribute({ memberType: embed(Taxonomy) })
  subclass?: ITaxonomy
  @attribute({ memberType: embed(Designer) })
  designer: IDesigner
  @attribute()
  serviceLevelCodes: string[]
  @attribute()
  sellableDate: string
  @attribute()
  adornDate: string
  @attribute()
  launchDate: string
  @attribute()
  commodeCode: string
  @attribute()
  genderCode: string
  @attribute({ memberType: embed(Flags) })
  flags: IFlags
  @attribute()
  shortDescription: string
  @attribute()
  longDescription: string
  @attribute()
  notes: string
  @attribute()
  cmosCatalogId: string
  @attribute()
  cmosItem: string
  @attribute()
  catalogType?: string
  @attribute()
  pimStyle: string
  @attribute()
  parentheticalCharge: string
  @attribute()
  intlParentheticalAmount: string
  @attribute()
  displayable?: boolean
  @attribute()
  canonicalUrl: string
  @attribute()
  designerBoutiqueUrl?: string
  @attribute()
  hideInternationally: boolean
  @attribute()
  suppressCheckout?: string
  @attribute()
  sizeLabels?: string
  @attribute()
  offline?: string
  @attribute()
  liveTreeDate?: string
  @attribute()
  restrictedStates: string
  @attribute()
  cmosSkuId?: string
  @attribute()
  codeUpc: string
  @attribute()
  discontinuedCode?: string
  @attribute()
  vendorId: string
  @attribute()
  iceFlag?: string
  @attribute({ memberType: embed(StoreInventory) })
  storeInventories: StoreInventory[]
  @attribute()
  onHandQty?: number
  @attribute()
  onOrderQty?: number
  @attribute()
  displayGroups?: string[]
  @attribute()
  webProductIDs?: string[]
  @attribute()
  psHierarchy: any
  @attribute()
  psAttributes: any
  @attribute()
  componentsOf?: string[]
  @attribute()
  displayAsGroupEligible?: boolean
  @attribute()
  sizeGuide?: string
  @attribute()
  webSkuId: string
}

export class Media {
  @attribute()
  id: string
  @attribute()
  mediaTag: string
  @attribute()
  mediaVersion: string
  @attribute()
  url: string
  @attribute()
  productId: string
  @attribute()
  dynamicImageSkuColor: boolean
}

export class ProductFlags {
  @attribute()
  isOnlyAtNM: boolean
  @attribute()
  dynamicImageSkuColor: boolean
  @attribute()
  hasMoreColors: boolean
  @attribute()
  isNewArrival: boolean
  @attribute()
  isEditorial: boolean
  @attribute()
  isEvening: boolean
  @attribute()
  inLookBook: boolean
  @attribute()
  showMonogramLabel: boolean
  @attribute()
  previewSupported: boolean
}

export class OriginTimestampInfo {
  @attribute()
  ProductUpdated: string
}

export class FilterFacet {
  @attribute()
  label: string
  @attribute()
  sortOrder: number
}

export class DataPoints {
  @attribute()
  ProductId: string
}

@table(displayItemGroupTableName)
export class ItemGroup {

  @hashKey({ type: 'String' })
  PartitionKey: string
  @attribute()
  productId: string
  @attribute()
  childProductIds?: string[]
  @attribute()
  description: string
  @attribute({ memberType: embed(Media) })
  media: Media[]
  @attribute()
  displayName: string
  @attribute()
  notes: string
  @attribute()
  help: string
  @attribute()
  sizeGuide: string
  @attribute()
  cmosCatalogId: string
  @attribute()
  cmosItem: string
  @attribute()
  merchandiseType: string
  @attribute()
  catalogType: string
  @attribute()
  pimStyle: string
  @attribute()
  departmentDesc: string
  @attribute()
  classDesc: string
  @attribute()
  designerName: string
  @attribute()
  designerDescriptionTitle: string
  @attribute()
  designerDescription: string
  @attribute()
  parentheticalCharge: number
  @attribute()
  intlParentheticalAmount: number
  @attribute()
  personalShopper: boolean
  @attribute()
  exclusive: boolean
  @attribute()
  preOrder: boolean
  @attribute()
  displayable: boolean
  @attribute()
  dynamicImageSkuColor: boolean
  @attribute()
  canonicalUrl: string
  @attribute()
  designerBoutiqueUrl: string
  @attribute()
  serviceLevelCodes: string[]
  @attribute({ memberType: embed(ProductFlags) })
  productFlags: ProductFlags
  @attribute()
  hideInternationally: boolean
  @attribute()
  onSale: boolean
  @attribute()
  suppressCheckout: boolean
  @attribute()
  aliPay: boolean
  @attribute()
  parenthetical: boolean
  @attribute()
  departmentCode: string
  @attribute()
  commodeCode: string
  @attribute()
  classCode: string
  @attribute()
  metaInfo: string
  @attribute()
  codeSetType: string
  @attribute({ memberType: embed(FilterFacet) })
  sizeLabels: FilterFacet[]
  @attribute()
  offline: boolean
  @attribute({ memberType: embed(OriginTimestampInfo) })
  originTimestampInfo: OriginTimestampInfo
  @attribute()
  sellableDate: string
  @attribute()
  liveTreeDate: string
  @attribute()
  adornDate: string
  @attribute()
  isBvd: boolean
  genderCode: string
  @attribute()
  restrictedStates: string
  @attribute()
  restrictedCodes: string
  @attribute()
  hierarchy: { [key: string]: string }[]
  @attribute()
  attributes: { [key: string]: string[] }[]
  @attribute({ memberType: embed(DataPoints) })
  dataPoints: DataPoints
  @attribute({ memberType: embed(Components) })
  components?: Components[]

  constructor(partitionKey?: string) {
    this.PartitionKey = partitionKey || '';
  }
}

export const saveProduct = async (message: IProduct): Promise<void> => {
  logger.info(`Saving Product: ${JSON.stringify(Object.assign(new Product(), removeEmptyValues(message)))}`)
  try {
    await mapper.update(Object.assign(new Product(), removeEmptyValues(message)))
    logger.info('Product was saved')
  } catch (error) {
    logger.error({
      message: `Error persisting Product ${JSON.stringify(message)}, errorMessage: ${error}`,
    })
    throw error
  }
}

export const saveItemGroups = async (message: ItemGroup): Promise<void> => {
  logger.info(`Saving Display Item Groups: ${JSON.stringify(message)}`)
  try {
    await mapper.put(Object.assign(new ItemGroup(), removeEmptyValues(message)));
    logger.info('Display Item Groups was saved..')
  } catch (error) {
    logger.error({
      message: `Error persisting Display Item Groups ${JSON.stringify(message)}, errorMessage: ${error}`,
    })
    throw error
  }
}

export const getItemGroups = async (suiteNumber: string): Promise<ItemGroup[]> => {

  logger.debug({message: 'querying Db for sutte' , suiteNumber });

  const iterator = mapper.query(ItemGroup, { PartitionKey: suiteNumber } );
  const itemGroups: ItemGroup[] = [];

  for await (const record of iterator) {
    itemGroups.push(record);
  }
  return Promise.resolve(itemGroups);
}

export const getParentGroupIds = async (components: string[]): Promise<string[]> => {
  logger.info({message: 'querying Db for suite' , components });
  const itemGrpList: ItemGroup[]  = [];
  const parentGroupIds: string[] = [];
  for(const component of components) {
    itemGrpList.push (new ItemGroup(component))
  }

  for await (const item of mapper.batchGet(itemGrpList)){
    if(item){
      parentGroupIds.push(item.productId);
    }
  }
  return Promise.resolve(parentGroupIds);
}

// eslint-disable-next-line max-len
export const findRemovedComponentsFromTheUpdateMessage =  async (suiteNumber: string, newComponents: IComponents[]): Promise<IComponents[]> => {

  const suiteProduct: ItemGroup[]  = await getItemGroups(suiteNumber) 
  logger.info ({findRemovedComponentsFromTheUpdateMessage: suiteNumber })
  if(suiteProduct && suiteProduct.length){
    // means updating te suite product, so get all components from the display item group table
    const existingComponents: IComponents[] = suiteProduct[0].components;

    logger.info ({findRemovedComponentsFromTheUpdateMessage: existingComponents})

    if(existingComponents && existingComponents.length){
      
      return existingComponents.filter(function(obj) {
        return !newComponents.some(function(obj2) {
            return obj.componentLevel === obj2.componentLevel && obj.componentNumber === obj2.componentNumber;
        });
      });
    }
  }

  return null;
}

export const getDisplayItems = async  (components: IComponents[]): Promise<Product[]> => {
  const products: Product[] = [];
  for(const component of components){
    if(component?.componentLevel === 'ITEM'){
      const iterator = mapper.query(Product, { PartitionKey: `${component?.componentNumber}` } );
      for await (const record of iterator) {
        products.push(record);
      } 
    } else if(component?.componentLevel === 'VARIATION'){
      // query variation id
      const iterator = mapper.query(Product,  {variationId : `${component?.componentNumber}`} , { indexName: 'VariationIdIndex'}  );
      for await (const record of iterator) {
        products.push(record);
      }
    } else if(component?.componentLevel === 'SKU'){
      // query based on  skunumber
      const iterator = mapper.query(Product,  {skuNumber : `${component?.componentNumber}`} , { indexName: 'SkuNumberIndex'}  );
      for await (const record of iterator) {
        products.push(record);
      }
    }
  }

  return Promise.all(products);
}

// eslint-disable-next-line max-len
export const updateDisplayItems = async (products: Product[],  suiteNumber: string, action: number): Promise<Product[]> => {

  logger.debug({message: "updating display item with suite number", suiteNumber });

  const productPromiseList: Promise<Product>[]  = [];

  for(const product of products){
    const displayGroup = product.displayGroups || []

    if(action === COMPONENT_ACTION_REMOVED){
      const index: number = displayGroup.indexOf(suiteNumber)

      if(index >= 0){
        displayGroup.splice(index, 1);
      }
      
    } else if(!displayGroup.includes(suiteNumber)){
      displayGroup.push (suiteNumber);
    }
    product.displayGroups = displayGroup;

    const expression = new UpdateExpression();
    expression.set(new AttributePath('displayGroups'), displayGroup);

    const toUpdate = new Product();
    toUpdate.PartitionKey = product.PartitionKey;
    toUpdate.SortKey = product.SortKey;

    logger.debug({message: "Product to be updated ", product : toUpdate, displayGroup : JSON.stringify(displayGroup) });

    productPromiseList.push(mapper.executeUpdateExpression(expression, toUpdate, Product ));
  }
  return Promise.all(productPromiseList);
}

export const updateStoreInventory = async (message: IStoreInventoryData): Promise<Product[]> => {

  const inv:StoreInventory = mapStoreInventories(message);

  const store = JSON.parse(locationStoreMapping).store[inv.locationNumber];
  if(store){
    inv.storeId = store.id;
    inv.storeNumber = store.sn;
  } else {
    logger.warn ({"missing-ssm-location-store-mapping" : inv.locationNumber})
  }

  const products: Product[] = await getProducts(message.ItemId);
  const productPromiseList: Promise<Product>[]  = [];

   if(products && products.length){
     // for(const product of products){
        let invList:StoreInventory[] = products[0].storeInventories;
        if(invList && invList.length){
          invList = invList.filter ((inv) => inv.locationNumber !== message.LocationId);
        } else {
          invList = [];
        }
        invList.push (inv);

        const expression = new UpdateExpression();
        expression.set(new AttributePath('storeInventories'), invList);
        
        const toUpdate = new Product();
        toUpdate.PartitionKey =  products[0].PartitionKey;
        toUpdate.SortKey =  products[0].SortKey;

        productPromiseList.push(mapper.executeUpdateExpression(expression, toUpdate, Product ));
        logger.info({storeInvUpdate: 'store-inv-update', style: toUpdate, newInvValue : inv});

     // }
   }
   return Promise.all(productPromiseList);
}

export const getProducts = async (skuNum: string): Promise<Product[]> => {

  logger.debug({message: 'querying  for  sku' , skuNum });

  const iterator = mapper.query(Product,  {skuNumber : skuNum} , { indexName: 'SkuNumberIndex'}  );
  const products: Product[] = [];

  for await (const record of iterator) {
    products.push(record);
  }

  logger.info ({storeInvMessage: `(${products.length}) products fetched for sku ${skuNum}` });
  return Promise.resolve(products);
}

export const findAtgSkuId = async (prodId: string, skuNumber : string): Promise<string> => {
  if (prodId) {
    const iterator = mapper.query(Sku, { productId: prodId } );
    for await (const record of iterator) {
      if(record?.pimSkuId === skuNumber && record.id !== skuNumber) {
        logger.info({webSkuIdForSkuNum: record?.pimSkuId , skuNum: skuNumber });
        return Promise.resolve(record.id);
      }
    }
  }

  return Promise.resolve (skuNumber);
}