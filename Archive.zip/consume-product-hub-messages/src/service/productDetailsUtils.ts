import logger from '@nmg/osp-backend-utils/logger'
import { property } from '../utils/config'
import { IProductHubPal } from '../models/pal'
import { IDesigner, IFlags, IInventory, IPrice, ITaxonomy, IProductDigitalAsset } from '../models/productHubMessage'
import { getCmosByStyleId } from './cmosUtils'
import { mapPrice } from './priceUtils'
import { storeFrontsMappings, zonesMappings } from './storeFrontUtils'
import { mapDigitalAssets } from './digitalAssetsUtils'
import { IWebProduct } from  '../models/pal/palVariation'
import { mapInventory } from './skuDetailsUtils'
import {CM4Data, Hierarchy} from "../models/pal/cm4Data";

const deptCodesForEveWear: string = property('DEPT_CODES_FOR_EVE_WEAR')
const classCodeForEveWear: string = property('CLASS_CODES_FOR_EVE_WEAR')
const catalogType: string = property('UNRESOLVED_CATALOG_TYPE')
const isOnlyAtNM: string = property('UNRESOLVED_IS_ONLY_AT_NM')
const hasMoreColors: string = property('UNRESOLVED_HAS_MORE_COLORS')
const suppressCheckout: string = property('UNRESOLVED_SUPRESS_CHECKOUT')
const cmosSkuId: string = property('CMOS_SKU_ID')
const iceFlag: string = property('UNRESOLVED_CMOS_SKU_IICE_FLAGD')
const USE_ATG_PRODUCT_ID = process.env.USE_ATG_PRODUCT_ID || true;

const mapDisplayItem = (pal: IProductHubPal, brand: string): string => {
  const price: IPrice = mapPrice(pal, brand)
  return `${pal.style.itemNumber}#${Number(price?.retail || 0)}`
}

const mapProductId = (pal: IProductHubPal, brand: string): string => {
  if(USE_ATG_PRODUCT_ID === "false"){
    return mapDisplayItem(pal, brand);
  }

  const productIdList  = mapWebProductIds(pal,brand);
  if (Array.isArray(productIdList) && productIdList.length) {
    return productIdList[0];
  }
  
  return null;
}
const mapDisplayName = (pal: IProductHubPal): string => pal.style.copyTitle

const mapTaxonomyByLevelName = (pal: IProductHubPal, levelName: string): ITaxonomy => {
  const taxonomy = pal.taxonomies.find((el) => el.levelName === levelName)
  return {
    code: taxonomy.code?.split('-').pop(),
    name: taxonomy.name,
  }
}

const mapDesigner = (pal: IProductHubPal): IDesigner => ({
  name: pal.style?.brandAdvertised?.name,
  descriptionTitle: null,
  description: pal.style?.brandAdvertised?.copyBrandBio?.replace(/<html>/g,'')?.replace(/<\/html>/g,'')
})

const mapServiceLevelCodes = (pal: IProductHubPal): string[] =>{
 // return getCmosByStyleId(pal, pal.style.itemNumber)?.eligibleServiceLevels?.split(',') || []
    return pal.sku.eligibleServiceLevels;
}

const mapSellableDate = (pal: IProductHubPal, brand: string): string => pal.variation.storeFronts[brand]?.launchDate
const mapLaunchDate = (pal: IProductHubPal, brand: string): string => pal.variation.storeFronts[brand]?.launchDate
const mapAdornDate = (pal: IProductHubPal, brand: string): string => pal.variation.storeFronts[brand]?.adornDate

const mapHideInternationally = (pal: IProductHubPal): boolean =>
  pal.style.invalidCountryGroup.findIndex((el) => el.countryAndState === 'ALL' && el.countryAndStateBlockFlag) !== -1

const mapRestrictedStates = (pal: IProductHubPal): string => {
  const blockedStates = pal.style.invalidCountryGroup.filter(
    (el) => el.countryAndStateBlockFlag && el.countryAndState.includes('USA-'),
  )
  return blockedStates.map((el) => el.countryAndState).join(',')
}

const mapOnSale = (pal: IProductHubPal, brand: string): boolean => {
  const zone = zonesMappings[brand]
  const pricing = pal.sku?.storeFronts[brand]?.pricing?.[zone]
  return (
    !!pricing && !!(pricing?.clearanceRetail || pricing?.promotionRetail)
  )
}

const mapCatalogType = (): string => catalogType
const mapDisplayable = (pal: IProductHubPal, brand: string): boolean => {
  const discontinuedCode = mapDiscontinuedCode(pal,brand);
  logger.debug({method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber,  discontinuedCode });
  if(discontinuedCode === 'V' || discontinuedCode === 'W'){
    return false;
  }
  const price: IPrice = mapPrice(pal, brand);
  logger.debug({method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber,  price });
  if(!(price && (price?.original > 0 || price?.retail >0))){
     return false;
  }
  const inventory: IInventory = mapInventory(pal, brand);
  logger.debug({method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber,  inventory });
  if(inventory && inventory?.qty <= 0){
    return false;
  }
  const digitalAssets: IProductDigitalAsset[] = mapDigitalAssets(pal, brand);
  logger.debug({method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber,  digitalAssets });
  if(!(digitalAssets && digitalAssets.filter(image => image.mediaTag === 'm0').length > 0)){
    logger.debug({method: 'mapDisplayable', style: pal.style.id, sku: pal.sku.skuNumber, missingM0Asset : "Missing m0 asset" });
     return false;
  }
  return true;
}
const mapProductSizeGuide =  (pal: IProductHubPal, brand: string): string => {
  if(pal?.style?.copyLegacyFlag){
    return  pal.style?.storeFronts[brand]?.legacyCopySizeGuide;
  }
  return  pal.style?.storeFronts[brand]?.copySizeGuide;
}

const mapDesignerBoutiqueUrl = (cm4Data?: CM4Data): string => cm4Data?.designerBoutiqueUrl || '';
const mapSuppressCheckout = (): string => suppressCheckout
const mapSizeLabels = (cm4Data?: CM4Data): string[] => cm4Data?.attributes?.SizeLabels || []
const mapOffline = (cm4Data?: CM4Data): boolean => !!cm4Data?.offline
const mapLiveTreeDate = (cm4Data?: CM4Data): string => cm4Data?.liveTreeDate || ''
const mapHierarchy = (cm4Data?: CM4Data): Hierarchy[] => cm4Data?.hierarchy || []
const mapCmosSkuId = (): string => cmosSkuId
const mapDiscontinuedCode = (pal: IProductHubPal, brand: string): string => {
  if (pal.sku?.storeFronts[brand]?.blockOrders) {
    return 'V';
  } 
  const strLaunchDate = pal.variation?.storeFronts[brand]?.launchDate;
  if (strLaunchDate) {
    // assumption the date format is YYYY-MM-DD  - sample from pal msg - 2021-04-12
    const launchDate = new Date (strLaunchDate)
    const now = new Date();
    if(launchDate > now){
      return 'W';
    }
  }

  if (pal.sku.storeFronts[brand]?.allowBackorders) {
    return 'N';
  }
  return 'Y';
}
const mapIceFlag = (pal: IProductHubPal): string => {
  const result = pal?.sku?.vendors?.find((vendor) => {
   return vendor?.skuVendorPartNumbers?.find ((partNUmber) => {
     return partNUmber?.vendorPartNumber.startsWith("IC")
   })
 });

 if(result) {
   logger.debug ({iceflag : "true"} );
   return "true";
 }
 logger.debug ({iceflag : "false"} );
 return "false"
}

// @ts-ignore
const mapIsEvening = (pal: IProductHubPal, departmentCode: string, classCode: string): boolean =>
  deptCodesForEveWear.includes(departmentCode) && classCodeForEveWear.includes(classCode)
const mapVariationId = (pal: IProductHubPal): string => pal.variation.variationNumber
const mapShortDescription = (pal: IProductHubPal): string =>
  pal.style?.shortDescription
const mapLongDescription = (pal: IProductHubPal): string =>{
  let desc = pal.style?.copyLegacyFlag ? pal.style?.legacyCopyBlock || '' : pal.style?.copyBlock || ''
  // replace \n \r \t from description
  desc = desc.replace(/[\r\n\t]/g, ' ');
  return desc;
}
const mapNotes = (pal: IProductHubPal, brand: string): string => pal.style?.storeFronts[brand]?.cutlineSuiteBottom
const mapPimStyle = (pal: IProductHubPal): string => pal.style?.itemNumber
const mapParentheticalCharge = (pal: IProductHubPal, brand: string): string =>
  pal.variation?.storeFronts[brand]?.webProduct?.[0]?.parentheticalCharge?.toString()
const mapIntlParentheticalAmount = (pal: IProductHubPal, brand: string): string =>
  pal.variation?.storeFronts[brand]?.webProduct?.[0]?.intlParentheticalAmount
const mapCanonicalUrl = (pal: IProductHubPal, displayName: string, productId: string): string =>{
  let formattedDisplayName: string = displayName || '';
  formattedDisplayName = formattedDisplayName.toLocaleLowerCase();
  formattedDisplayName = formattedDisplayName.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  formattedDisplayName = formattedDisplayName.replace(/\u00E6/g,'');
  formattedDisplayName = formattedDisplayName.replace(/\./g,'-');
  formattedDisplayName = formattedDisplayName.replace(/<.*?>/,'');
  formattedDisplayName = formattedDisplayName.replace(/&.*?;/,'');
  formattedDisplayName = formattedDisplayName.replace(/'/g,'');
  formattedDisplayName = formattedDisplayName.replace(/[^a-zA-Z0-9]+/g,'-');

  
  let formattedDesignerName: string = pal?.style?.brandAdvertised?.name || '';

  formattedDesignerName = formattedDesignerName.toLocaleLowerCase();
  formattedDesignerName = formattedDesignerName.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  formattedDesignerName = formattedDesignerName.replace(/\u00E6/g,'');
  formattedDesignerName = formattedDesignerName.replace(/\./g,'-');
  formattedDesignerName = formattedDesignerName.replace(/<.*?>/,'');
  formattedDesignerName = formattedDesignerName.replace(/&.*?;/,'');
  formattedDesignerName = formattedDesignerName.replace(/'/g,'');
  formattedDesignerName = formattedDesignerName.replace(/[^a-zA-Z0-9]+/g,'-');

  return `/p/${formattedDesignerName}-${formattedDisplayName}-${productId}`
}


const mapWebProductIds = (pal: IProductHubPal, brand: string): string[] => {
  const webProducts: IWebProduct[] = pal.variation?.storeFronts[brand]?.webProduct
  if (!Array.isArray(webProducts) || !webProducts.length) {
    return null;
  }
  const webProductIds: string[] = webProducts.map(webProduct => {
    return webProduct.webProductID;
  });
  return webProductIds;
}

const mapFlags = (
  pal: IProductHubPal,
  brand: string,
  departmentCode: string,
  classCode: string,
  inventory: IInventory,
): IFlags => {
  const isGroup = pal.style.productSetType
  const belongsToGroup = !!pal.style.componentOf?.length
  const preOrder = pal.variation.storeFronts[brand]?.preOrderFlag
  const allowBackOrders = pal.sku.storeFronts[brand]?.allowBackorders
  const blockOrders = pal.sku.storeFronts[brand]?.blockOrders
  const dynamicImageSkuColor = pal.sku.colorId?.name !== 'NO COLOR' && mapDigitalAssets(pal, brand).length > 0
  const isEditorial = pal.style.storeFronts[brand]?.editorialItemSetFlag
  const isEvening = mapIsEvening(pal, departmentCode, classCode)
  const showMonogramLabel = pal.style.personalizationType.name !== 'Not Personalized'
  const previewSupported = !!pal.style.personalizationInstructions?.length
  const storeOnly = pal.style.storeFronts[storeFrontsMappings[brand]]?.storeOnly
  const exclusive = pal?.variation?.storeFronts[brand]?.exclusiveFlag
  const inStock = inventory?.status === 'AVAILABLE' && inventory?.purchaseOrderQty > 0
  const useSkuAsset =
    pal.sku.colorId?.name !== 'NO COLOR' && pal?.digitalAssets?.[0]?.storeFronts[brand]?.imageClUrl !== null
  const giftWrappableFlag = pal.style.giftWrapFlag
  const perishableFlag = pal.style.perishableFlag || null
  const dropshipFlag = pal.style.dropshipFlag
  const fedexEligibleFlag = getCmosByStyleId(pal, pal.style.itemNumber)?.fedexHalEligibleFlag || null
  const parenthetical = parseInt(pal.variation?.storeFronts[brand]?.webProduct?.[0]?.parentheticalCharge, 10) > 0
  const onSale = mapOnSale(pal, brand)

  return {
    isGroup,
    belongsToGroup,
    preOrder,
    allowBackOrders,
    blockOrders,
    dynamicImageSkuColor,
    isEditorial,
    isEvening,
    showMonogramLabel,
    previewSupported,
    storeOnly,
    exclusive,
    inStock,
    useSkuAsset,
    giftWrappableFlag,
    perishableFlag,
    dropshipFlag,
    fedexEligibleFlag,
    parenthetical,
    isOnlyAtNM,
    hasMoreColors,
    onSale,
  }
}

const mapCodeUpc = (pal: IProductHubPal): string => {
  return pal.sku.upcs?.find((upc) => upc.primaryRmsUpc)?.nmgUpcCode
}

const mapVendorId = (pal: IProductHubPal): string => {
  return pal.style.vendors?.[0].locations.find((el) => el.primary).locationNumber
}

const mapCommodeCode = (pal: IProductHubPal): string => pal.style?.taxCategoryId?.taxSystem2Code

const mapGenderCode = (pal: IProductHubPal): string => pal.style?.gender?.code

const mapPSAttributes = (cm4Data: CM4Data): any => {
  delete cm4Data?.attributes?.SizeLabels
  return cm4Data?.attributes || {};
}

export {
  mapDisplayItem,
  mapDisplayName,
  mapTaxonomyByLevelName,
  mapDesigner,
  mapServiceLevelCodes,
  mapSellableDate,
  mapFlags,
  mapLaunchDate,
  mapAdornDate,
  mapHideInternationally,
  mapRestrictedStates,
  mapCatalogType,
  mapDisplayable,
  mapDesignerBoutiqueUrl,
  mapSuppressCheckout,
  mapSizeLabels,
  mapOffline,
  mapLiveTreeDate,
  mapCmosSkuId,
  mapDiscontinuedCode,
  mapIceFlag,
  mapVariationId,
  mapShortDescription,
  mapLongDescription,
  mapNotes,
  mapPimStyle,
  mapParentheticalCharge,
  mapIntlParentheticalAmount,
  mapCanonicalUrl,
  mapCodeUpc,
  mapVendorId,
  mapCommodeCode,
  mapGenderCode,
  mapWebProductIds,
  mapProductId,
  mapProductSizeGuide,
  mapHierarchy,
  mapPSAttributes
}
