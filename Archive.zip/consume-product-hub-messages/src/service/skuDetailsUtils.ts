import logger from '@nmg/osp-backend-utils/logger'
import { property } from '../utils/config'
import { IProductHubPal } from '../models/pal'
import { IColor, ISize, IShipping, IInventory } from '../models/productHubMessage'
import { IPalDigitalAsset } from '../models/pal/palDigitalAssets'
import { findAtgSkuId } from "../storage/dynamoMessages"

const shipFromStore = property('UNRESOLVED_SHIP_FROM_STORE')
const expectedShipDate = property('UNRESOLVED_EXPECTED_SHIP_DATE')
// TODO 
const bossTotalQty = 0

const mapSkuNumber = async (pal: IProductHubPal, productId: string, useAtgId: string | true): Promise<string> => {
 
  logger.info({useAtgId});
  
  if (useAtgId === 'false') {
    return Promise.resolve (pal.sku.skuNumber);
  } 
 
  return findAtgSkuId (productId, pal.sku.skuNumber)
}

const mapColorFacet = (pal: IProductHubPal): string[] => {
  if(!pal?.sku?.colorId?.webFacet) {
    return [];
  } 

  return pal?.sku?.colorId?.webFacet?.map( facet => facet?.name)
}

// @ts-ignore
const mapSkuSequenceNumber = (pal: IProductHubPal): number => 1

const mapInventory = (pal: IProductHubPal, storeFront: string): IInventory => ({
  status: pal.sku.storeFronts[storeFront]?.inventory?.status,
  onHandStatus: pal.sku.storeFronts[storeFront]?.inventory?.onHandStatus,
  qty: pal.sku.storeFronts[storeFront]?.inventory?.totalQuantity || 0,
  purchaseOrderQty: pal.sku.storeFronts[storeFront]?.inventory?.futureQuantity || 0,
  bossTotalQty,
})

const mapColor = (pal: IProductHubPal, brand: string): IColor => ({
  name: pal?.sku?.colorId?.name,
  pimKey: String(pal?.sku?.colorId?.sortSequenceId),
  pimCode: pal?.sku?.colorId?.code,
  facet: mapColorFacet(pal),
  key: pal.sku.colorId.code,
  default: pal.digitalAssets.findIndex((el) => el.storeFronts[brand]?.imageCLPrimaryimageFlag === true) !== -1,
})

const mapSize = (pal: IProductHubPal): ISize => ({
  name: pal?.sku?.sizeId?.name,
  pimKey: String(pal?.sku?.sizeId?.sortSequenceId),
  pimCode: pal?.sku?.sizeId?.code,
  key: pal?.sku?.sizeId?.code,
})

const mapHexValue = (pal: IProductHubPal): string => pal?.variation?.hexValue

const mapImageClUrl = (pal: IProductHubPal): string => pal?.digitalAssets?.[0]?.storeFronts?.NMOnline?.imageClUrl

const mapSwatchPath = (pal: IProductHubPal, brand: string): string => {
  const asset: IPalDigitalAsset  =  pal?.digitalAssets.find (elm => elm.storeFronts[brand]?.imageShotType === 's');
  if(asset) {
    let url = asset.storeFronts[brand].imageClUrl || '';
    if(url && !url.startsWith('//')){
        url = `//${url}`;
    }

    return url;
  }
  return '';
}
const mapShipping = (pal: IProductHubPal): IShipping => ({
  boxedDepthInches: pal?.sku?.boxedDepthInches,
  boxedHeightInches: pal?.sku?.boxedHeightInches,
  boxedWidthInches: pal?.sku?.boxedWidthInches,
  deliveryDays: pal?.style?.supplierProcessingDays,
  shipFromStore,
  expectedShipDate,
})

const mapSuggestedInterval = (pal: IProductHubPal): string => pal?.style?.customerReplenishmentSuggInterval?.code

const mapSeasonDeliveryCode = (pal: IProductHubPal): string => {
  if(pal?.variation?.deliverySeason && pal?.variation?.deliverySeason?.length){
    return pal?.variation?.deliverySeason?.[0].delivery;
  }
  return '';
}

export {
  mapSkuNumber,
  mapSkuSequenceNumber,
  mapInventory,
  mapColor,
  mapSize,
  mapHexValue,
  mapImageClUrl,
  mapSwatchPath,
  mapShipping,
  mapSuggestedInterval,
  mapSeasonDeliveryCode,
}
