const brandsMappings: { [key: string]: string } = {
  NMOnline: 'nmo',
  HCOnline: 'hco',
  BGOnline: 'bgo',
}

const brandsAbbrMappings: { [key: string]: string } = {
  NM: 'NMOnline',
  HC: 'HCOnline',
  BG: 'BGOnline',
}

const storeFrontsMappings: { [key: string]: string } = {
  NMOnline: 'NMStores',
  HCOnline: 'HCStores',
  BGOnline: 'BGStores',
}

const zonesMappings: { [key: string]: string } = {
  NMOnline: 'zone12',
  HCOnline: 'zone14',
  BGOnline: 'zone15',
}

export { brandsMappings, brandsAbbrMappings, storeFrontsMappings, zonesMappings }
