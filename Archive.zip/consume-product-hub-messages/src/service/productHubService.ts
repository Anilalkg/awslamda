import logger from '@nmg/osp-backend-utils/logger'
import { property } from '../utils/config'
import { IProduct } from '../models/productHubMessage'
import { mapPalToProduct, mapDisplayItemGroups } from './utils'
import {
  Product,
  ItemGroup,
  saveItemGroups,
  saveProduct,
  updateDisplayItems,
  updateStoreInventory,
  getDisplayItems,
  findRemovedComponentsFromTheUpdateMessage,
  COMPONENT_ACTION_NEW_OR_UPDATED,
  COMPONENT_ACTION_REMOVED
} from '../storage/dynamoMessages'
import { brandsAbbrMappings } from './storeFrontUtils'
import {IProductHubGroupData, IStoreInventoryData} from "../models/data";
import {IPalDigitalAsset} from "../models/pal/palDigitalAssets";

const USE_ATG_PRODUCT_ID = process.env.USE_ATG_PRODUCT_ID || true;
const currentBrand: string = property('BRAND')

export const saveProductHubMessage = async (message: { pal: unknown }): Promise<IProduct> => {
  try {
    const { pal } = message
    const dynamoMessage: IProduct = await mapPalToProduct(pal, brandsAbbrMappings[currentBrand], USE_ATG_PRODUCT_ID)

    if (dynamoMessage && dynamoMessage.forceWebPublish) {
      await saveProduct(dynamoMessage)
    } else if (!dynamoMessage.forceWebPublish){
      logger.warn ({style: dynamoMessage.PartitionKey, ignoreMessage : true, forceWebPublish : 'Not-True' })
    }

    return dynamoMessage
  } catch (error) {
    logger.error({
      message: `Error saving ProductHubMessage ${JSON.stringify(message)}, errorMessage: ${error}`,
    })
    throw error
  }
}


export const saveItemGroupMessage = async (message: { pal: {suite: IProductHubGroupData, digitalAssets: IPalDigitalAsset[]} }): Promise<ItemGroup> => {
  try {

    const data = message.pal.suite;
    const {digitalAssets} = message.pal;
    const dynamoMessage: ItemGroup = await mapDisplayItemGroups(data, digitalAssets, brandsAbbrMappings[currentBrand], USE_ATG_PRODUCT_ID)

    if (dynamoMessage) {

      const componentsRemoved = await findRemovedComponentsFromTheUpdateMessage(data?.suiteNumber, data?.components);

      const displayItems: Product[] = await getDisplayItems(data?.components);
      if(displayItems && displayItems.length){
        // fetch all the child productids and remove the duplicates
        dynamoMessage.childProductIds = [... new Set(displayItems.map(obj => obj.productId))];
      } else {
        dynamoMessage.childProductIds = [];
      }

      await saveItemGroups(dynamoMessage);

      await updateDisplayItems(displayItems,  dynamoMessage?.productId, COMPONENT_ACTION_NEW_OR_UPDATED );

      // this is for the components that are removed in the updated message
      // in that case we need to remove the suite from  the childs->displayGroups  list
      if(componentsRemoved && componentsRemoved.length){
        const displayItems1: Product[] = await getDisplayItems(componentsRemoved);

        logger.info({componentRemoved: `These components ${JSON.stringify(componentsRemoved)} removed for suite ${data?.suiteNumber} - ${dynamoMessage?.productId}, so updating child product(s) displayGroup`});
        await updateDisplayItems(displayItems1,  dynamoMessage?.productId, COMPONENT_ACTION_REMOVED);
      }
    }

    return dynamoMessage
  } catch (error) {
    logger.error({
      message: `error-save-item-group-message ${JSON.stringify(message)}, errorMessage: ${error}`,
    })
    throw error
  }
}

export const saveStoreInventoryMessage = async (message: IStoreInventoryData): Promise<void> => {
  try {

    const  data  = message;

    logger.debug ({invData: data})

    await updateStoreInventory(data);

  } catch (error) {
    logger.error({
      message: `error-save-location-message ${JSON.stringify(message)}, errorMessage: ${error}`,
    })
    throw error
  }
}