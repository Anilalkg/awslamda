import { property } from '../utils/config'
import { IProductHubPal } from '../models/pal'
import { IPalCmosStyle } from '../models/pal/palCmos'

const currentBrand: string = property('BRAND')

export const getCmosByStyleId = (pal: IProductHubPal, styleId: string): IPalCmosStyle => {
  const iPalCmos = pal.cmos?.find((cmosStyle) => Object.keys(cmosStyle).includes(styleId))
  return iPalCmos ? iPalCmos[styleId] : null
}

export const mapCmosCatalogId = (pal: IProductHubPal): string => {
  // @ts-ignore
  const cmos = getCmosByStyleId(pal, pal.style.itemNumber)?.[0].storeFronts
  const storeFront = cmos?.find((el: { storeFrontID: string }) => el.storeFrontID === currentBrand)

  if (!storeFront) return null

  switch (currentBrand) {
    case 'NM':
      return storeFront.NMOfferItemId
    case 'BG':
      return storeFront.BGOfferItemId
    case 'HC':
      return storeFront.HCOfferItemId
    default:
      return null
  }
}

export const mapCmosItem = (pal: IProductHubPal, brand: string): string =>
  pal.variation?.storeFronts[brand]?.webProduct?.[0]?.webDepiction
