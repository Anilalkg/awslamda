import { IPrice } from '../models/productHubMessage'
import { zonesMappings } from './storeFrontUtils'
import { IProductHubPal } from '../models/pal'

const mapPrice = (pal: IProductHubPal, brand: string): IPrice => {
  const zone = zonesMappings[brand]
  const pricing = pal.sku.storeFronts[brand]?.pricing?.[zone]

  return {
    retail: pricing?.clearanceRetail || pricing?.promotionRetail || pricing?.regularRetail,
    original: pricing?.regularRetail,
  }
}

export { mapPrice }
