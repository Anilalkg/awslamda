import { IProductHubPal } from "../models/pal"
import { IPalDigitalAsset } from "../models/pal/palDigitalAssets"
import { IProductDigitalAsset } from "../models/productHubMessage"

const mapDigitalAssets = (pal: IProductHubPal, brand: string): IProductDigitalAsset[] =>
    pal.digitalAssets.reduce((result: IProductDigitalAsset[], palDigitalAsset: IPalDigitalAsset) => {
        if (palDigitalAsset.storeFronts[brand]) {
            const mediaTag = palDigitalAsset.storeFronts[brand]?.imageShotType
            let url = palDigitalAsset.storeFronts[brand].imageClUrl || '';
            if(url && !url.startsWith('//')){
                url = `//${url}`;
            }
            result.push({
                mediaTag: mediaTag?.length === 1 ? `${mediaTag}0` : mediaTag,
                mediaVersion: palDigitalAsset.assetName.publicationCount || '1',
                url,
            })
        }
        return result
    }, [])

export { mapDigitalAssets }