import logger from '@nmg/osp-backend-utils/logger'
import elasticBuilder, {RequestBodySearch} from 'elastic-builder';
import { IProductHubPal } from '../models/pal'
import { IProductHubGroupData } from '../models/data'
import { IProduct } from '../models/productHubMessage'
import { mapDigitalAssets } from './digitalAssetsUtils'
import { mapPrice } from './priceUtils'
import {
  mapTaxonomyByLevelName,
  mapDesigner,
  mapServiceLevelCodes,
  mapSellableDate,
  mapFlags,
  mapDisplayItem,
  mapHideInternationally,
  mapRestrictedStates,
  mapCatalogType,
  mapDisplayable,
  mapDesignerBoutiqueUrl,
  mapSuppressCheckout,
  mapCmosSkuId,
  mapDiscontinuedCode,
  mapIceFlag,
  mapShortDescription,
  mapLongDescription,
  mapNotes,
  mapPimStyle,
  mapParentheticalCharge,
  mapIntlParentheticalAmount,
  mapCanonicalUrl,
  mapCodeUpc,
  mapVendorId,
  mapVariationId,
  mapAdornDate,
  mapLaunchDate,
  mapDisplayName,
  mapCommodeCode,
  mapGenderCode,
  mapWebProductIds,
  mapProductId,
  mapProductSizeGuide,
  mapSizeLabels,
  mapOffline,
  mapLiveTreeDate,
  mapHierarchy,
  mapPSAttributes
} from './productDetailsUtils'

import {
  mapColor,
  mapHexValue,
  mapInventory,
  mapShipping,
  mapSize,
  mapSkuNumber,
  mapSkuSequenceNumber,
  mapSuggestedInterval,
  mapSwatchPath,
  mapSeasonDeliveryCode,
} from './skuDetailsUtils'
import { brandsMappings, storeFrontsMappings } from './storeFrontUtils'
import { mapCmosCatalogId, mapCmosItem } from './cmosUtils'
import { getParentGroupIds, ItemGroup, Media } from "../storage/dynamoMessages";
import {EsClient} from "../client/esClient";
import {EsSearchResponse} from "../client/types";
import {IPalDigitalAsset} from "../models/pal/palDigitalAssets";

const DEFAULT_DISPLAY_ITEM_TYPE = 'singlePriceDisplayItem'

const EMPTY_STRING = "";

const HYPHEN = "-";

const ES_INDEX = process.env.ES_INDEX || '';
const ES_DOMAIN = process.env.ES_DOMAIN || '';
const ES_REGION = process.env.ES_REGION || '';
const elasticClient = new EsClient(ES_DOMAIN, ES_REGION, ES_INDEX)

const generatePartitionKey = (pal: IProductHubPal): string => `${pal.style.itemNumber}`

const generateSortKey = (pal: IProductHubPal): string => `${pal.sku.skuNumber}#${mapSkuSequenceNumber(pal)}`

// when the value null update the same to empty string
const emptyNullValues = (obj :any): any => {
  if(Array.isArray(obj)){
    for (const o of obj){
      // if its an array then iterate eahe element in the array and look at  
      // the properties and see any props are null then make it as undefined
      Object.keys(o).forEach(e => {
      if(o[e] === null)
        o[e] = undefined;
      });
    }
  }else{
    // if its an object then look at  
    // the properties and see any props are null then make it as undefined
    Object.keys(obj).forEach(e => {
      if(obj[e] === null)
      obj[e] = undefined;
    });         
  }
  return obj;
}

export const mapPalToProduct = async (pal: IProductHubPal, brand: string, useATGProductId: string | true): Promise<IProduct> => {
  const brandAbr = brandsMappings[brand]
  if (!brandAbr) return null
  const storeFront = storeFrontsMappings[brand]
  const inventory = mapInventory(pal, storeFront)
  const productId = mapProductId(pal, brand)
  const displayName = mapDisplayName(pal)

  const departmentByTaxonomy = mapTaxonomyByLevelName(pal, 'Department')
  const classByTaxonomy = mapTaxonomyByLevelName(pal, 'Class')
  const subclassByTaxonomy = mapTaxonomyByLevelName(pal, 'Sub Class')

  const newProduct: IProduct = {
    PartitionKey: generatePartitionKey(pal),
    SortKey: generateSortKey(pal),
    skuNumber: pal.sku.skuNumber,
    skuSequenceNumber: mapSkuSequenceNumber(pal),
    displayItem: mapDisplayItem(pal, brand),
    displayItemType: DEFAULT_DISPLAY_ITEM_TYPE,
    variationId: mapVariationId(pal),
    productId,
    price: mapPrice(pal, brand),
    color: emptyNullValues(mapColor(pal, brand)),
    size: emptyNullValues(mapSize(pal)),
    inventory: mapInventory(pal, brand),
    digitalAssets: emptyNullValues(mapDigitalAssets(pal, brand)),
    hexValue: mapHexValue(pal),
    swatchPath: mapSwatchPath(pal, brand),
    shipping: mapShipping(pal),
    suggestedInterval: mapSuggestedInterval(pal),
    displayName,
    department: departmentByTaxonomy,
    class: classByTaxonomy,
    subclass: emptyNullValues(subclassByTaxonomy),
    designer: mapDesigner(pal),
    serviceLevelCodes: mapServiceLevelCodes(pal),
    sellableDate: mapSellableDate(pal, brand),
    adornDate: mapAdornDate(pal, brand),
    launchDate: mapLaunchDate(pal, brand),
    commodeCode: mapCommodeCode(pal),
    genderCode: mapGenderCode(pal),
    flags: mapFlags(pal, brand, departmentByTaxonomy.code, classByTaxonomy.code, inventory),
    shortDescription: mapShortDescription(pal),
    longDescription: mapLongDescription(pal),
    notes: mapNotes(pal, brand),
    cmosCatalogId: mapCmosCatalogId(pal),
    cmosItem: mapCmosItem(pal, brand),
    catalogType: mapCatalogType(),
    pimStyle: mapPimStyle(pal),
    parentheticalCharge: mapParentheticalCharge(pal, brand),
    intlParentheticalAmount: mapIntlParentheticalAmount(pal, brand),
    displayable: mapDisplayable(pal, brand),
    canonicalUrl: mapCanonicalUrl(pal, displayName, productId),
    designerBoutiqueUrl: mapDesignerBoutiqueUrl(pal?.cm4Data),
    hideInternationally: mapHideInternationally(pal),
    suppressCheckout: mapSuppressCheckout(),
    sizeLabels: mapSizeLabels(pal?.cm4Data),
    offline: mapOffline(pal?.cm4Data),
    liveTreeDate: mapLiveTreeDate(),
    restrictedStates: mapRestrictedStates(pal),
    cmosSkuId: mapCmosSkuId(),
    codeUpc: mapCodeUpc(pal),
    discontinuedCode: mapDiscontinuedCode(pal,brand),
    vendorId: mapVendorId(pal),
    iceFlag: mapIceFlag(pal),
    deliveryCode: mapSeasonDeliveryCode(pal),
    webProductIDs:  mapWebProductIds(pal, brand),
    psHierarchy: mapHierarchy(pal?.cm4Data),
    psAttributes: mapPSAttributes(pal?.cm4Data),
    forceWebPublish: pal.style.storeFronts[brand]?.forceWebPublish,
    componentsOf: await mapComponentsOf(pal),
    displayAsGroupEligible: pal.style.storeFronts[brand]?.editorialItemSetFlag,
    sizeGuide: mapProductSizeGuide(pal, brand),
    webSkuId: await mapSkuNumber(pal, productId, useATGProductId),
    merchandiseType: pal?.style?.dropshipCategory.code,
  }

  return newProduct
}

const mapComponentsOf = async (pal: IProductHubPal): Promise<string[]> => {
  if(!pal?.style?.componentOf?.length) {
    return [];
  }
  return getParentGroupIds(pal.style.componentOf);
}

// eslint-disable-next-line max-len
const mapGroupItemNotes = (data: IProductHubGroupData, brand: string): string => data?.storeFronts[brand]?.cutlineSuiteBottom || EMPTY_STRING
// eslint-disable-next-line max-len
const mapSizeGuide = (data: IProductHubGroupData, brand: string): string => data?.storeFronts[brand]?.brandSizeGuide || EMPTY_STRING

const getProductIdFromESByCmosItem = async (cmosItem?: string): Promise<string> => {
    if (cmosItem){
      try {
        if(!cmosItem.startsWith(HYPHEN)){
          cmosItem = HYPHEN + cmosItem;
        }
        const searchBody: RequestBodySearch = new elasticBuilder.RequestBodySearch()
            .source(false)
            .query(elasticBuilder.termQuery("cmosItem", cmosItem));


        const resp: EsSearchResponse = await elasticClient.search(searchBody.toJSON()) as EsSearchResponse;
        logger.debug ({ESResponse: resp})
        if (resp.body.hits.total > 0) {
          // eslint-disable-next-line no-underscore-dangle
          return resp.body.hits.hits[0]._id;
        }
      }catch (err){
        logger.error({message: "Error retrieving productID from ES", data: err.message})
      }
    }
    return EMPTY_STRING;
}
/*
// TODO - will remove
const getProductIdsListFromESByCmosItems = async (cmosItems?: string[]): Promise<string[]> => {
  if (cmosItems){
    cmosItems = cmosItems.map(item => {
      return item.startsWith(HYPHEN)?item:(HYPHEN + item);
    })
    try {
      const searchBody: RequestBodySearch = new elasticBuilder.RequestBodySearch()
          .source(false)
          .query(elasticBuilder.termsQuery("cmosItem", cmosItems));



      const resp: EsSearchResponse = await elasticClient.search(searchBody.toJSON()) as EsSearchResponse;
      logger.debug ({ESResponse: resp})
      if (resp.body.hits.total > 0) {
        // eslint-disable-next-line no-underscore-dangle
        return resp.body.hits.hits.map(hit => hit._id);
      }
    }catch (err){
      logger.error({message: "Error retrieving productID from ES", data: err.message})
    }
  }
  return [];
}
*/
export const mapDisplayItemGroups = async (data: IProductHubGroupData, digitalAssets: IPalDigitalAsset[], brand: string, useATGProductId: string | true): Promise<ItemGroup> => {
    const brandAbr = brandsMappings[brand]
    const productId: string = useATGProductId === "false" ? data.suiteNumber : await getProductIdFromESByCmosItem(data.suiteNumber || EMPTY_STRING)

    const itemGroup: ItemGroup = new ItemGroup();
    if (brandAbr) {
      itemGroup.PartitionKey = data.suiteNumber;
      itemGroup.productId = productId;
      itemGroup.description = data.shortDescription|| EMPTY_STRING;
      itemGroup.media = mapDisplayItemGroupMedia(data, digitalAssets, brand);
      itemGroup.displayName = data.copyTitle || EMPTY_STRING;
      itemGroup.notes = mapGroupItemNotes(data, brand); // correct?
      itemGroup.help = EMPTY_STRING;
      itemGroup.sizeGuide = mapSizeGuide(data, brand);
      itemGroup.cmosItem = data.suiteNumber || EMPTY_STRING;
      itemGroup.cmosCatalogId = EMPTY_STRING;
      itemGroup.pimStyle = EMPTY_STRING;

      itemGroup.merchandiseType = EMPTY_STRING;
      itemGroup.catalogType = EMPTY_STRING;
      itemGroup.departmentDesc = EMPTY_STRING;
      itemGroup.classDesc = EMPTY_STRING;
      itemGroup.designerName = EMPTY_STRING;
      itemGroup.designerDescriptionTitle = EMPTY_STRING;
      itemGroup.designerDescription = EMPTY_STRING;
      itemGroup.designerBoutiqueUrl = EMPTY_STRING;
      itemGroup.parentheticalCharge = 0.0;
      itemGroup.intlParentheticalAmount = 0.0;
      itemGroup.personalShopper = false;
      itemGroup.exclusive = false;
      itemGroup.preOrder = false;
      itemGroup.dynamicImageSkuColor = false;

      itemGroup.productFlags = {
        isOnlyAtNM: false,
        dynamicImageSkuColor: false,
        hasMoreColors: false,
        isNewArrival: false,
        isEditorial: data?.storeFronts[brand]?data?.storeFronts[brand][0]?.editorialItemSetFlag:false,
        isEvening: false,
        inLookBook: false,
        showMonogramLabel: false,
        previewSupported: false
      };
      itemGroup.hideInternationally = false;
      itemGroup.onSale = false;
      itemGroup.suppressCheckout = false;
      itemGroup.aliPay = false;
      itemGroup.parenthetical = false;
      itemGroup.departmentCode = EMPTY_STRING;
      itemGroup.commodeCode = EMPTY_STRING;
      itemGroup.classCode = EMPTY_STRING;
      itemGroup.metaInfo = EMPTY_STRING;
      itemGroup.codeSetType = EMPTY_STRING;
      itemGroup.sizeLabels = [

      ];

      itemGroup.offline = false;
      itemGroup.originTimestampInfo = {
        ProductUpdated: data.updatedAt || EMPTY_STRING
      };

    //  itemGroup.dataPoints = {
    //    ProductId:"prod199220013"
    //  };
      itemGroup.sellableDate = data?.launchDate || EMPTY_STRING;

      const published = data?.itemPublishStatus?.code;
      if(published === 'Published'){
        itemGroup.liveTreeDate = `${ new Date()}`;
        itemGroup.displayable = true;
      } else {
        itemGroup.displayable = false;
        itemGroup.liveTreeDate = EMPTY_STRING;
      }

      itemGroup.adornDate = EMPTY_STRING;
      itemGroup.isBvd = false;
      itemGroup.genderCode = data.gender || EMPTY_STRING;
      itemGroup.restrictedStates = EMPTY_STRING;
      itemGroup.restrictedCodes = EMPTY_STRING;
      itemGroup.hierarchy = [

      ];
      itemGroup.attributes = [

      ];
      itemGroup.components = emptyNullValues([...data.components]);
    }
    return itemGroup;
}

const mapDisplayItemGroupMedia = (data: IProductHubGroupData, digitalAssets: IPalDigitalAsset[], brand: string): Media[] => {

  const media: Media[] = [];
  digitalAssets.forEach(asset => {
    media.push({
      id: `m${  data?.id}`,
      mediaVersion: data?.publicationCount?.toString() || EMPTY_STRING,
      mediaTag: asset.storeFronts[brand].imageShotType|| EMPTY_STRING,
      // TODO need to decide what we will do when url is null, it causes type error in DynamoDB
      url: asset.storeFronts[brand].imageClUrl || EMPTY_STRING,
      productId: data.suiteNumber|| EMPTY_STRING,
      dynamicImageSkuColor: false,
    });
  });

  return media;
}