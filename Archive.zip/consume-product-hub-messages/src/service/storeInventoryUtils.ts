import { StoreInventory } from '../storage/dynamoMessages'
import { IStoreInventoryData } from '../models/data'

export const mapStoreInventories = (inv: IStoreInventoryData): StoreInventory => {
  const inventory:StoreInventory = new StoreInventory();
  inventory.locationNumber = inv.LocationId;
  inventory.bopsQuantity=inv.Quantity;
  inventory.quantity = inv.Quantity;
  inventory.invLevel = inv.StatusCode
  return inventory;
}
