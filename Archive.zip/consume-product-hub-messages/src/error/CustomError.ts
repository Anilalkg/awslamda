export class ValidationException extends Error {
  public httpCode = 400

  constructor(message: string) {
    super(message)
    this.name = 'ValidationException'
  }
}
export class DummyCustomException extends Error {
  public httpCode = 400

  constructor(message: string) {
    super(message)
    this.name = 'DummyCustomException'
  }
}
