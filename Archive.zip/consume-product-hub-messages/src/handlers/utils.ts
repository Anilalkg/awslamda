import AWS from 'aws-sdk'
import { SQSRecord } from 'aws-lambda'
import logger from '@nmg/oco-backend-utils/logger'
import { saveProductHubMessage, saveItemGroupMessage, saveStoreInventoryMessage } from '../service/productHubService'

export const consumeRecords = async (record: SQSRecord): Promise<void> => {
  try {
    logger.info({ message: 'Got new record', record })
    const eventBridgeMessage = JSON.parse(record.body)


    let parsedResponse = eventBridgeMessage;

    if (eventBridgeMessage?.event?.eventType) {
      parsedResponse = eventBridgeMessage;
    } else {
      const params = {
        Bucket: eventBridgeMessage?.detail?.requestParameters?.bucketName || '',
        Key: eventBridgeMessage?.detail?.requestParameters?.key || '',
      }

      logger.debug({ message: 'params', data: params })

      const s3: AWS.S3 = new AWS.S3()
      const s3Response = await s3.getObject(params).promise()
      parsedResponse = JSON.parse(s3Response?.Body?.toString())
      logger.debug({ message: 'parsedResponse', data: parsedResponse })
    }

    if(getEventType(parsedResponse) === 'suiteUpdate'){
      await saveItemGroupMessage(parsedResponse)
    }else{
      await saveProductHubMessage(parsedResponse)
    }
  } catch (error) {
    const message = 'Error occurred while processing ProductHubMessage'
    logger.error({
      message,
      errorMessage: error?.response?.data || error.message,
    })
  }
}

export const consumeDevRecords = async (event: any): Promise<void> => {

  try {
    const parsedResponse = JSON.parse(event.body)

     if(getEventType(parsedResponse) === 'suiteUpdate'){
       await saveItemGroupMessage(parsedResponse)
     }else{
       await saveProductHubMessage(parsedResponse)
     }
  // await saveStoreInventoryMessage(parsedResponse);
    
  } catch (error) {
    const message = 'Error occurred while processing ProductHubMessage'
    logger.error({
      message,
      errorMessage: error?.response?.data || error.message,
    })
  }
}

const getEventType = (s3Data: any): string => {
  const eventType = s3Data?.event?.eventType;
  logger.debug({eventTypeValue: eventType});
  return eventType;
}


export const consumeStoreInvRecords = async (record: SQSRecord): Promise<void> => {
  try {
    logger.info({ message: 'Got new Inventory record', record })
    const eventBridgeMessage = JSON.parse(record.body)

    const params = {
      Bucket: eventBridgeMessage?.detail?.requestParameters?.bucketName || '',
      Key: eventBridgeMessage?.detail?.requestParameters?.key || '',
    }

    logger.debug({ message: 'params', data: params })

    const s3: AWS.S3 = new AWS.S3()
    const s3Response = await s3.getObject(params).promise()
    const parsedResponse = JSON.parse(s3Response?.Body?.toString())
    
    logger.debug({ message: 'parsedInventoryResponse', data: parsedResponse })

    await saveStoreInventoryMessage(parsedResponse)

  } catch (error) {
    const message = 'Error occurred while processing inventory records'
    logger.error({
      message,
      errorMessage: error?.response?.data || error.message,
    })
  }
}
