import { SQSEvent } from 'aws-lambda'
import logger from '@nmg/oco-backend-utils/logger'
import {consumeStoreInvRecords} from './utils'

exports.handler = async function (event: SQSEvent): Promise<void> {
  logger.info({ message: 'Got-Store-Inv-Event', records: event.Records.length })
  
  for (const record of event.Records) {
    await consumeStoreInvRecords(record)
  }
}
