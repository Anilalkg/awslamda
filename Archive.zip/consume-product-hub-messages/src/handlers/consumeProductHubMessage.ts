import { SQSEvent } from 'aws-lambda'
import logger from '@nmg/oco-backend-utils/logger'
import {consumeDevRecords, consumeRecords} from './utils'

exports.handler = async function (event: SQSEvent): Promise<void> {
  logger.info({ message: 'Got PAL event', records: event.Records.length })
  
  for (const record of event.Records) {
    await consumeRecords(record)
  }
}

exports.devHandler = async function (event: any): Promise<void> {
  await consumeDevRecords(event)
}
