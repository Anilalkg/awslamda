export const property = (name: string): string => process.env[name] || ''
