export const removeEmptyValues = (obj: Record<string, any>): Record<string, any> => {
  Object.keys(obj).forEach((key) => {
    if (obj[key] === undefined || obj[key] === null) {
      obj[key] = ''
    }
  })
  return obj
}
