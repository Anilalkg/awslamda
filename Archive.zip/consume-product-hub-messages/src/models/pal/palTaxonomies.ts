export interface IPalTaxonomy {
  levelNumber: number
  name: string
  description: string
  isActive: boolean
  isDeleted: boolean
  code: string
  levelName: string
  updatedSource: string
  createdBy: string
  updatedBy: string
  createdAt: string
  updatedAt: string
  displayName: string
}
