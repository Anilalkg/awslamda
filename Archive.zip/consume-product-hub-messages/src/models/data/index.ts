import { IComponents } from './components'
import { IPalDigitalAsset } from '../pal/palDigitalAssets'


export interface IProductHubGroupData {
  id?: string
  suiteNumber?: string
  shortDescription?: string
  productSetType?: string
  components?: IComponents[]
  digitalAssets?: IPalDigitalAsset[]
  publicationCount?: number,
  name?: string,
  copyTitle?: string,
  storeFronts: {
    [storeFrontCode: string]: any
  }
  gender: string,
  updatedAt: string
  itemPublishStatus?: ItemPublishStatus
  launchDate?: string
}

interface ItemPublishStatus{
  name?: string
  code?: string
}
export interface IStoreInventoryData {
  ItemId?: string
  LocationId?: string
  Status?: string
  StatusCode?: bigint
  Quantity?: bigint
  NextAvailabilityDate?: string
  TransactionDateTime?: string
  ViewName?: string
  ViewId?: string
  TotalIncludingSubstituteItems?: string
  SubstituteItemsAvailable?: string
  SubstitutionDetails?: string
  IsInfiniteAvailability?: string
  FutureQuantity?: bigint
  OnHandQuantity?: bigint
  NextFutureQuantityETA?: string
}
