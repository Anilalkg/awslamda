export interface IProductHubEvent {
  styleNumber: string
  styleUpdatedAt: string
  variationNumber: string
  variationUpdatedAt: string
  skuNumber: number
  skuUpdatedAt: string
  taxonomy: string
  publicationCount: number
  eventType: string
}
