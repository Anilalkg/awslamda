import {Endpoint} from 'aws-sdk';
import logger from '@nmg/osp-backend-utils/logger'
import {EsClientError, EsRequest, EsResponse} from './types';


// eslint-disable-next-line @typescript-eslint/no-var-requires
const AWS = require('aws-sdk');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');


export const ES_SEARCH_PATH = '_search';
export const ES_ANALYZE_PATH = '_analyze';
const POST = 'POST';

export class EsClient {
    private readonly esDomain: string;

    private readonly esRegion: string;

    private readonly esIndex: string;

    private readonly endpoint: Endpoint;

    constructor(esDomain: string, esRegion: string, esIndex: string) {
        this.esDomain = esDomain;
        this.esRegion = esRegion;
        this.esIndex = esIndex;
        this.endpoint = new AWS.Endpoint(this.esDomain);
    }

    private readonly httpClient = new AWS.HttpClient();

    private readonly credentials = new AWS.EnvironmentCredentials('AWS');

    private sendRequest(esRequest: EsRequest): Promise<any> {
        const sendReqStart = new Date().getTime();
        const request = new AWS.HttpRequest(this.endpoint, this.esRegion);

        request.method = esRequest.httpMethod;
        let requestPath = path.join(request.path, esRequest.requestPath);
        const qp = esRequest.queryParameters;
        if (qp && Object.keys(qp).length > 0) {
            const queryParametersStr: string = Object.keys(qp)
                .map((key) => `${key}=${qp[key]}`)
                .join('&');
            requestPath = `${requestPath}?${queryParametersStr}`;
        }
        request.path = requestPath;
        request.body = (typeof esRequest.payload === 'string') ? esRequest.payload : JSON.stringify(esRequest.payload);
        request.headers['Content-Type'] = 'application/json';
        request.headers.Host = this.esDomain;

        logger.debug({message: "HTTP request to ES", data: {request, index: this.esIndex}})
        const sendReqEnd = new Date().getTime();
        logger.debug({message: "createReqObj", data: {duration: sendReqEnd - sendReqStart}})

        const signStart = new Date().getTime();
        const signer = new AWS.Signers.V4(request, 'es');
        signer.addAuthorization(this.credentials, new Date());
        const signEnd = new Date().getTime();
        logger.debug({message: "RequestSigning", data: {duration: signEnd - signStart}})
        // logging
        const start = process.hrtime();
        const logResponse = (responseCode: number, responseError?: string): void => {
            const [seconds, nanoseconds] = process.hrtime(start);
            const logData = {
                requestUrl: request.path,
                requestMethod: request.method,
                responseCode,
                responseTime: seconds * 1000 + nanoseconds / 1000000,
                responseError,
            };
            if (responseError) {
                logger.error({message: "Request failed", data: logData})
            } else {
                logger.debug({message: "Request succeeded", data: logData})
            }
        };
        // make a call
        return new Promise((resolve, reject) => {
            this.httpClient.handleRequest(request, null,
                (response: any) => {
                    const handleReqStart = new Date().getTime();
                    const {statusCode, statusMessage, headers} = response;
                    let body = '';
                    response.on('data', (chunk: any) => {
                        body += chunk;
                    });
                    response.on('end', () => {
                        const data: EsResponse = {
                            statusCode,
                            statusMessage,
                            headers,
                        };
                        logResponse(statusCode);
                        const handleReqEnd= new Date().getTime();
                        logger.debug({message: "handleReqObj", data: {duration: handleReqEnd - handleReqStart}})
                        if (body) {
                            try {
                                const startConvert = new Date().getTime();
                                data.body = JSON.parse(body);
                                const endConvert = new Date().getTime();
                                logger.debug({message: "ConvertToObject", data: {duration: endConvert - startConvert}})
                            } catch (error) {
                                logger.error({message: "Response body is not a valid JSON", data: body})
                                reject(error);
                            }
                        }
                        if (data.statusCode >= 400) {
                            logger.error({message: "ES call failed", data: {method: request.method, path: request.path, data}})
                            reject(new EsClientError('ES response has status code >= 400', data));
                        }
                        resolve(data);
                    });
                },
                (error: any) => {
                    const errorMessage = `${error}`;
                    logger.error({message: "Error sending request to elasticsearch", data: errorMessage})
                    logResponse(0, errorMessage);
                    return reject(error);
                });
        });
    }

    async search(payload: any, queryParameters?: { [key: string]: string }): Promise<EsResponse> {
        const start = new Date().getTime();
        const esResponse: EsResponse = await this.sendRequest({
            httpMethod: POST,
            requestPath: path.join(this.esIndex, ES_SEARCH_PATH),
            payload,
            queryParameters,
        });
        const end = new Date().getTime();
        // logger.debug('ESClient Search-End', { duration: end - start }, null);
        return esResponse;
    }

    async analyze(payload: any, queryParameters?: { [key: string]: string }): Promise<EsResponse> {
        const start = new Date().getTime();
        const esAnalysisResponse: EsResponse = await this.sendRequest({
            httpMethod: POST,
            requestPath: path.join(this.esIndex, ES_ANALYZE_PATH),
            payload,
            queryParameters,
        });
        const end = new Date().getTime();
        // logger.debug('ESClient Analyze-End', { duration: end - start }, null);
        return esAnalysisResponse;
    }
}
