import * as dummyMessage from './mocks/palMessage.json'
import {
  mapSkuNumber,
  mapSkuSequenceNumber,
  mapInventory,
  mapColor,
  mapSize,
  mapHexValue,
  mapImageClUrl,
  mapSwatchPath,
  mapShipping,
  mapSuggestedInterval,
  mapSeasonDeliveryCode,
} from '../service/skuDetailsUtils'
import {property} from "../utils/config";

describe('test Mapping rules for sku Details ', () => {
  const { pal } = dummyMessage

  it('mapSkuNumber should return  correct mapped value', async () => {
    // @ts-ignore
    expect(await mapSkuNumber(pal, "", 'false')).toEqual('401102429728')
  })

  it('mapSkuSequenceNumber should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapSkuSequenceNumber(pal)).toEqual(1)
  })

  it('mapInventory should return  correct mapped value', async () => {
    const inventory = {
      bossTotalQty: 0,
      purchaseOrderQty: 0,
      qty: 0,
      status: 'AVAILABLE',
    }
    const storeFront = 'NMStores'
    // @ts-ignore
    expect(mapInventory(pal, storeFront)).toEqual(inventory)
  })

  it('mapColor should return  correct mapped value', async () => {
    const color = {
      name: 'BLUE',
      pimKey: '21300',
      pimCode: '100380',
      facet: 'BLUE',
      key: '100380',
      default: false,
    }
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapColor(pal, brand)).toEqual(color)
  })

  it('mapSize should return  correct mapped value', async () => {
    const size = {
      name: 'NO SIZE',
      pimKey: '1222100',
      pimCode: '109999',
      key: '109999',
    }

    // @ts-ignore
    expect(mapSize(pal)).toEqual(size)
  })

  it('mapHexValue should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapHexValue(pal)).toEqual('0h5A3')
  })

  it('mapImageClUrl should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapImageClUrl(pal)).toEqual('imageClUrlValue')
  })

  it('mapSwatchPath should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapSwatchPath(pal, brand)).toEqual('//imageClUrlValue')
  })

  it('mapShipping should return  correct mapped value', async () => {
    const shipping = {
      boxedDepthInches: 20,
      boxedHeightInches: 3,
      boxedWidthInches: 12,
      // @ts-ignore
      deliveryDays: null,
      expectedShipDate: '',
      shipFromStore: '',
    }

    // @ts-ignore
    expect(mapShipping(pal)).toEqual(shipping)
  })

  it('mapSuggestedInterval should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapSuggestedInterval(pal)).toEqual('month')
  })

  it('mapSeasonDeliveryCode should return correct mapped value', async () => {
    // @ts-ignore
    expect(mapSeasonDeliveryCode(pal)).toEqual("126")
  })
})
