import * as dummyMessage from './mocks/palMessage.json'
import { mapPrice } from '../service/priceUtils'

describe('test Mapping rules for Price', () => {
  const { pal } = dummyMessage
  it('mapPrice should return  correct mapped value for HC', async () => {
    const brand = 'HCOnline'
    const price = {
      retail: '1410.0000',
      original: '1210.0000',
    }

    // @ts-ignore
    expect(mapPrice(pal, brand)).toEqual(price)
  })

  it('mapPrice should return  correct mapped value for BG', async () => {
    const brand = 'BGOnline'
    const price = {
      retail: '2410.0000',
      original: '2210.0000',
    }

    // @ts-ignore
    expect(mapPrice(pal, brand)).toEqual(price)
  })
})
