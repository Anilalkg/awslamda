import * as dummyMessage from './mocks/palMessage.json'
import { mapDigitalAssets } from '../service/digitalAssetsUtils'

describe('test Mapping rules for Digital Assets', () => {
  const { pal } = dummyMessage
  it('mapDigitalAssets should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    const digitalAssets = [
      { mediaTag: 's0', mediaVersion: '1', url: '//imageClUrlValue' },
      { mediaTag: 'a0', mediaVersion: '1', url: '' },
      { mediaTag: 'e0', mediaVersion: '1', url: '' },
      { mediaTag: 'l0', mediaVersion: '1', url: '//media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100380_l' },
      { mediaTag: 'a0', mediaVersion: '1', url: '//media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100380_a' },
      { mediaTag: 'e0', mediaVersion: '1', url: '' },
      { mediaTag: 's0', mediaVersion: '1', url: '//media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100380_s' },
      { mediaTag: 'k0', mediaVersion: '1', url: '//media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100380_k' },
      { mediaTag: 'm0', mediaVersion: '1', url: '//media.neimanmarcus.com/f_auto,q_auto/01/nm_2891137_100380_m' },
      { mediaTag: 'e0', mediaVersion: '1', url: '//media.neimanmarcus.com/01/nm_2891137_100000_e' },
    ]

    // @ts-ignore
    expect(mapDigitalAssets(pal, brand)).toEqual(digitalAssets)
  })
})
