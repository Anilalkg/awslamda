import * as dummyMessage from './mocks/palMessage.json'
import { getCmosByStyleId, mapCmosCatalogId, mapCmosItem } from '../service/cmosUtils'

jest.mock('../utils/config', () => ({
  property: jest.fn().mockReturnValue('NM'),
}))

describe('test Mapping rules for Cmos', () => {
  const { pal } = dummyMessage
  it('getCmosByStyleId should return  correct mapped value', async () => {
    const styleId = '2891137'
    // @ts-ignore
    expect(getCmosByStyleId(pal, styleId)[0].itemId).toEqual('401000257352')
  })
  it('mapCmosCatalogId should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapCmosCatalogId(pal)).toEqual(1234)
  })
  it('mapCmosItem should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapCmosItem(pal, 'NMOnline')).toEqual('HBY4X')
  })
})
