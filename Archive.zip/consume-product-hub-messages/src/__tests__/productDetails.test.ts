import * as dummyMessage from './mocks/palMessage.json'
import {
  mapDisplayItem,
  mapDisplayName,
  mapTaxonomyByLevelName,
  mapDesigner,
  mapServiceLevelCodes,
  mapSellableDate,
  mapFlags,
  mapLaunchDate,
  mapAdornDate,
  mapHideInternationally,
  mapRestrictedStates,
  mapCatalogType,
  mapDisplayable,
  mapDesignerBoutiqueUrl,
  mapSuppressCheckout,
  mapSizeLabels,
  mapOffline,
  mapLiveTreeDate,
  mapCmosSkuId,
  mapDiscontinuedCode,
  mapIceFlag,
  mapVariationId,
  mapShortDescription,
  mapLongDescription,
  mapNotes,
  mapPimStyle,
  mapParentheticalCharge,
  mapIntlParentheticalAmount,
  mapCanonicalUrl,
  mapCodeUpc,
  mapVendorId,
  mapCommodeCode,
  mapGenderCode,
  mapWebProductIds,
  mapProductId,
  mapProductSizeGuide,
  mapHierarchy,
  mapPSAttributes
} from '../service/productDetailsUtils'
import {property} from "../utils/config";

describe('test Mapping rules for product Details ', () => {
  const { pal } = dummyMessage
  const brand = 'NMOnline'

  it('mapDisplayItem should return  correct mapped value', async () => {
    // @ts-ignore
    expect(await mapDisplayItem(pal, brand)).toEqual('2891137#0')
  })

  it('mapDisplayName should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapDisplayName(pal)).toEqual("Rivoli Decorative Pillow")
  })

  it('mapServiceLevelCodes should return  correct mapped value', async () => {
    // @ts-ignore
    expect(mapServiceLevelCodes(pal)).toEqual(undefined)
  })

  it('mapSellableDate should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapSellableDate(pal, brand)).toEqual("2021-03-01")
  })

  it('mapLaunchDate should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapLaunchDate(pal, brand)).toEqual("2021-03-01")
  })

  it('mapDiscontinuedCode should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapDiscontinuedCode(pal, brand)).toEqual("Y")
  })

  it('mapIceFlag should return  correct mapped value', async () => {
    const brand = 'NMOnline'
    // @ts-ignore
    expect(mapIceFlag(pal)).toEqual("true")
  })

  

})
