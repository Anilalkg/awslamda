import * as dummyMessage from './mocks/palMessage.json'
import * as itemGroupMessage from './mocks/itemGroupPalMessage.json'
import {mapDisplayItemGroups, mapPalToProduct} from '../service/utils'
import {ItemGroup} from "../storage/dynamoMessages";
import {brandsAbbrMappings} from "../service/storeFrontUtils";

const EMPTY_STRING = "";

jest.mock('../storage/dynamoMessages')

jest.mock('../utils/config', () => ({
    property: jest.fn().mockReturnValue('NM'),
}))

describe('test Mapping rules', () => {
    it('mapPalToProduct should return  correct mapped values', async () => {
        process.env.USE_ATG_PRODUCT_ID = 'false';
        const {pal} = dummyMessage
        // @ts-ignore
        const product = await mapPalToProduct(pal, 'NMOnline', 'false')

        expect(product.PartitionKey).toEqual('2891137')
        expect(product.SortKey).toEqual('401102429728#1')
        expect(product.skuNumber).toEqual('401102429728')
        expect(product.skuSequenceNumber).toEqual(1)
        expect(product.displayItem).toEqual('2891137#0')
        expect(product.displayItemType).toEqual('singlePriceDisplayItem')
        expect(product.variationId).toEqual('2891137-100380')
        expect(product.productId).toEqual('prod217090337')
        expect(product.hexValue).toEqual('0h5A3')
        expect(product.displayName).toEqual('Rivoli Decorative Pillow')
        expect(product.department).toMatchObject({
            code: "2009",
            name: "Decorative I"
        })
        expect(product.class).toMatchObject({
            code: "648",
            name: "Pillows"
        })
        expect(product.subclass).toMatchObject({
            code: "648",
            name: "Pillows Sub"
        })
        expect(product.deliveryCode).toEqual("126");
    })

    it('mapDisplayItemGroups should return  correct mapped values', async () => {
        process.env.USE_ATG_PRODUCT_ID = 'false';
        const data = itemGroupMessage.pal.suite;
        const {digitalAssets} = itemGroupMessage.pal;
        // @ts-ignore
        const dynamoMessage: ItemGroup = await mapDisplayItemGroups(data, digitalAssets, brandsAbbrMappings.NM, 'false')

        expect(dynamoMessage.PartitionKey).toEqual('5025969')
        expect(dynamoMessage.productId).toEqual('5025969')
        expect(dynamoMessage.description).toEqual('Short test description')
        expect(dynamoMessage.displayName).toEqual('Liquid Facial Soap')
        expect(dynamoMessage.notes).toEqual(EMPTY_STRING)
        expect(dynamoMessage.help).toEqual(EMPTY_STRING)
        expect(dynamoMessage.sizeGuide).toEqual(EMPTY_STRING)
        expect(dynamoMessage.cmosItem).toEqual('5025969')
        expect(dynamoMessage.cmosCatalogId).toEqual(EMPTY_STRING)
        expect(dynamoMessage.pimStyle).toEqual(EMPTY_STRING)
        expect(dynamoMessage.merchandiseType).toEqual(EMPTY_STRING)
        expect(dynamoMessage.catalogType).toEqual(EMPTY_STRING)
        expect(dynamoMessage.departmentDesc).toEqual(EMPTY_STRING)
        expect(dynamoMessage.classDesc).toEqual(EMPTY_STRING)
        expect(dynamoMessage.designerName).toEqual(EMPTY_STRING)
        expect(dynamoMessage.designerDescriptionTitle).toEqual(EMPTY_STRING)
        expect(dynamoMessage.designerBoutiqueUrl).toEqual(EMPTY_STRING)
        expect(dynamoMessage.pimStyle).toEqual(EMPTY_STRING)
        expect(dynamoMessage.parentheticalCharge).toEqual(0.0)
        expect(dynamoMessage.intlParentheticalAmount).toEqual(0.0)
        expect(dynamoMessage.personalShopper).toEqual(false)
        expect(dynamoMessage.exclusive).toEqual(false)
        expect(dynamoMessage.preOrder).toEqual(false)
        expect(dynamoMessage.dynamicImageSkuColor).toEqual(false)
        expect(dynamoMessage.productFlags).toEqual({
            isOnlyAtNM: false,
            dynamicImageSkuColor: false,
            hasMoreColors: false,
            isNewArrival: false,
            isEditorial: false,
            isEvening: false,
            inLookBook: false,
            showMonogramLabel: false,
            previewSupported: false
        })

        expect(dynamoMessage.media).toEqual([
            {
                "dynamicImageSkuColor": false,
                "id": "m2191316",
                "mediaTag": "m",
                "mediaVersion": "1",
                "productId": "5025969",
                "url": "",
            }
        ])

        expect(dynamoMessage.hideInternationally).toEqual(false)
        expect(dynamoMessage.onSale).toEqual(false)
        expect(dynamoMessage.suppressCheckout).toEqual(false)
        expect(dynamoMessage.aliPay).toEqual(false)
        expect(dynamoMessage.parenthetical).toEqual(false)
        expect(dynamoMessage.departmentCode).toEqual(EMPTY_STRING)
        expect(dynamoMessage.commodeCode).toEqual(EMPTY_STRING)
        expect(dynamoMessage.classCode).toEqual(EMPTY_STRING)
        expect(dynamoMessage.metaInfo).toEqual(EMPTY_STRING)
        expect(dynamoMessage.codeSetType).toEqual(EMPTY_STRING)
        expect(dynamoMessage.sizeLabels).toEqual([])
        expect(dynamoMessage.offline).toEqual(false)

        expect(dynamoMessage.hierarchy).toEqual([])
        expect(dynamoMessage.attributes).toEqual([])
        expect(dynamoMessage.isBvd).toEqual(false)
        expect(dynamoMessage.adornDate).toEqual(EMPTY_STRING)
        expect(dynamoMessage.restrictedStates).toEqual(EMPTY_STRING)
        expect(dynamoMessage.restrictedCodes).toEqual(EMPTY_STRING)
        expect(dynamoMessage.originTimestampInfo).toEqual({
            ProductUpdated: "2022-09-13T17:08:33.000+0000"
        })
        expect(dynamoMessage.sellableDate).toEqual("25.05.2022")
        expect(dynamoMessage.displayable).toEqual(true)
        expect(dynamoMessage.genderCode).toEqual("Male")
        expect(dynamoMessage.components).toEqual([
            {
                "componentLevel": "ITEM",
                "componentNumber": "10022",
                "quantity": 0,
                "componentSequence": 0,
                "componentDepiction": undefined,
                "componentDepictionSequence": undefined
            },
            {
                "componentLevel": "ITEM",
                "componentNumber": "10045",
                "quantity": 0,
                "componentSequence": 0,
                "componentDepiction": undefined,
                "componentDepictionSequence": undefined
            },
            {
                "componentLevel": "ITEM",
                "componentNumber": "10129",
                "quantity": 0,
                "componentSequence": 0,
                "componentDepiction": undefined,
                "componentDepictionSequence": undefined
            },
            {
                "componentLevel": "ITEM",
                "componentNumber": "10150",
                "quantity": 0,
                "componentSequence": 0,
                "componentDepiction": undefined,
                "componentDepictionSequence": undefined
            },
            {
                "componentLevel": "ITEM",
                "componentNumber": "10179",
                "quantity": 0,
                "componentSequence": 0,
                "componentDepiction": undefined,
                "componentDepictionSequence": undefined
            }
        ])
    })
})
