import * as dummyMessage from './mocks/palMessageWithCM4Data.json'
import {mapDesignerBoutiqueUrl, mapHierarchy, mapOffline, mapPSAttributes} from '../service/productDetailsUtils'

describe('test cm4 data mapping', () => {
    const { pal } = dummyMessage
    it('map designer boutique url', async () => {
        expect(mapDesignerBoutiqueUrl(pal?.cm4Data)).toEqual('/c/boutique-url-cat123')
    });

    it('map offline flag', async () => {
        expect(mapOffline(pal?.cm4Data)).toEqual(true)
    });

    it('map attributes', async () => {
        expect(mapPSAttributes(pal?.cm4Data)).toEqual({
            "Lifestyle": ["cool"]
        });
    });

    it('map hierarchy', async () => {
        expect(mapHierarchy(pal?.cm4Data)).toEqual([{"level1": "Women's clothing", "level2": "Dresses"}]);
    });
})
